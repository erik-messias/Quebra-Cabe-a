# Quebra-Cabeça (Android)

Escolha uma imagem da galeria, defina a quantidade de peças (6 a ~500) e o app gera o quebra-cabeça com peças de encaixe reais.

## Como compilar
1. Instale o **Android Studio** (versão recente) e abra a pasta `QuebraCabeca`.
2. Aguarde o Gradle sincronizar (precisa de internet na primeira vez).
3. Conecte o celular (depuração USB) ou use um emulador e clique em **Run**.
4. Para gerar o APK: *Build > Build Bundle(s) / APK(s) > Build APK(s)*.

Requisitos: Android 10+ (minSdk 29), JDK 17 (já vem no Android Studio).

## O que o app faz
- Seletor de fotos do sistema (sem pedir permissão), com correção de rotação EXIF.
- Tela inicial com **3 formatos de peça** (Regular, Irregular, Selvagem), barra de quantidade (6 a ~500) e **prévia ao vivo**: a imagem aparece com o contorno exato das peças, igual ao que vai para o jogo.
- Grade se adapta à proporção da foto; peças com formato único (curvas de Bézier).
- **Peças já começam arrumadas em anéis ao redor do tabuleiro**. O botão de moldura na barra superior arruma de novo (blocos já montados e peças já encaixadas não são mexidos).
- Arrastar peças, arrastar a mesa com 1 dedo no vazio, zoom com pinça, rolagem automática ao arrastar na borda.
- Encaixe automático entre vizinhas (viram um bloco) e no tabuleiro (travam).
- Menu: ver imagem completa, imagem de fundo no tabuleiro, destacar só bordas, arrumar peças ao redor, ajustar zoom.
- **Dificuldade**: até 2000 peças e modo **peças giradas** (toque numa peça ou bloco para girar 90°; só encaixa na orientação certa).
- **Tela travada ao segurar uma peça**: a tela só se move se você bater 2 vezes na mesma borda com a peça na mão (a primeira batida acende um aviso na borda).
- **Tela cheia**: o ícone de setas na barra esconde toda a interface; um botão discreto no canto volta ao normal (o botão Voltar também).
- **Aparência**: cor da mesa (10 opções) e opacidade da imagem original no tabuleiro. Também no menu: **Jogar na horizontal**.
- Mais espaço em volta do tabuleiro e folga extra ao arrastar a mesa.
- Cronômetro, barra de progresso e progresso salvo automaticamente ("Continuar puzzle salvo").
- **Vídeo da montagem**: o app grava seus movimentos e, ao completar, gera um MP4 acelerado (12 a 45 s) com a montagem do início ao fim, mais 2,5 s do resultado final. Fica em Filmes/QuebraCabeca na galeria, com botões Assistir e Compartilhar.

## Código
| Arquivo | Função |
|---|---|
| `MainActivity.kt` | Tela inicial: escolher imagem e nº de peças |
| `PuzzleActivity.kt` | Tela do jogo: cronômetro, menu, salvar/restaurar |
| `PuzzleView.kt` | Mesa: desenho, gestos, encaixe, vitória |
| `JigsawGeometry.kt` | Formato das peças (3 estilos) e cálculo da grade |
| `PuzzlePreviewView.kt` / `ShapeIconView.kt` | Prévia com contornos e ícones de formato |
| `ImageStore.kt` | Importar imagem e salvar progresso |
| `ReplayRecorder.kt` | Grava os movimentos durante o jogo |
| `ReplayRenderer.kt` | Reproduz os movimentos e codifica o MP4 (MediaCodec) |
