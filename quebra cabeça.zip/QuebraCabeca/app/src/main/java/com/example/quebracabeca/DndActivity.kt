package com.example.quebracabeca

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

/** Mesa de D&D: a mesma página (dnd.html) usada no PC, dentro de um WebView. */
class DndActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null

    private val pick = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        val uris = if (r.resultCode == RESULT_OK && data != null) WebChromeClient.FileChooserParams.parseResult(r.resultCode, data) else null
        chooser?.onReceiveValue(uris)
        chooser = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?): Boolean {
                chooser?.onReceiveValue(null)
                chooser = cb
                return try { pick.launch(p!!.createIntent()); true } catch (_: Throwable) { chooser = null; false }
            }
        }
        // o gamertag do quebra-cabeça é reaproveitado
        val tag = Cloud.creatorName(this) ?: ""
        web.loadUrl("file:///android_asset/dnd.html")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, url: String?) {
                v?.evaluateJavascript("window.nativeTag=" + org.json.JSONObject.quote(tag) + ";window.onNativeTag&&window.onNativeTag();", null)
            }
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.dndBack&&window.dndBack())||false") { r ->
                    if (r == "true") return@evaluateJavascript
                    isEnabled = false; onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
