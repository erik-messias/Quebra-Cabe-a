package com.example.quebracabeca

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import android.util.LruCache
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

/** Busca de fotos no Pexels (precisa de uma chave grátis em pexels.com/api). */
class PexelsActivity : AppCompatActivity() {

    private class Photo(val thumb: String, val full: String, val author: String)

    private val prefs by lazy { getSharedPreferences("puzzle_prefs", MODE_PRIVATE) }
    private val pool = Executors.newFixedThreadPool(4)
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private var photos: List<Photo> = emptyList()
    private lateinit var search: EditText
    private lateinit var status: TextView
    private lateinit var list: RecyclerView

    private class VH(v: View) : RecyclerView.ViewHolder(v) {
        val img: ImageView = v.findViewById(R.id.img)
        val credit: TextView = v.findViewById(R.id.credit)
    }

    private val adapter = object : RecyclerView.Adapter<VH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_image, parent, false))

        override fun getItemCount() = photos.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val p = photos[position]
            h.credit.visibility = View.VISIBLE
            h.credit.text = getString(R.string.pexels_credit, p.author)
            h.img.tag = p.thumb
            val c = cache.get(p.thumb)
            if (c != null) { h.img.setImageBitmap(c) } else {
                h.img.setImageDrawable(null)
                pool.execute {
                    val bmp = try { URL(p.thumb).openStream().use { BitmapFactory.decodeStream(it) } } catch (e: Exception) { null }
                    if (bmp != null) cache.put(p.thumb, bmp)
                    runOnUiThread { if (h.img.tag == p.thumb) h.img.setImageBitmap(bmp) }
                }
            }
            h.itemView.setOnClickListener { choose(p) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pexels)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        findViewById<MaterialToolbar>(R.id.toolbar).apply {
            setNavigationIcon(R.drawable.ic_back)
            setNavigationOnClickListener { finish() }
            inflateMenu(R.menu.pexels_menu)
            setOnMenuItemClickListener { askKey(); true }
        }
        search = findViewById(R.id.search)
        status = findViewById(R.id.status)
        list = findViewById(R.id.list)
        list.layoutManager = GridLayoutManager(this, 2)
        list.adapter = adapter
        search.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEARCH) { load(search.text.toString().trim()); true } else false
        }
        if (key().isEmpty()) askKey() else load("")
    }

    private fun key() = prefs.getString("pexels_key", "")?.trim() ?: ""

    private fun askKey() {
        val et = EditText(this).apply {
            setText(key()); hint = "Cole a chave aqui"; setSingleLine()
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = android.widget.FrameLayout(this).apply { setPadding(pad, pad / 2, pad, 0); addView(et) }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.pexels_key_title)
            .setMessage(R.string.pexels_key_msg)
            .setView(box)
            .setPositiveButton(R.string.pexels_key_save) { _, _ ->
                prefs.edit().putString("pexels_key", et.text.toString().trim()).apply()
                if (key().isNotEmpty()) load(search.text.toString().trim())
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("Authorization", key())
        c.connectTimeout = 15000
        c.readTimeout = 20000
        val code = c.responseCode
        if (code == 401 || code == 403) throw SecurityException()
        if (code == 429) throw IllegalStateException("limite")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun load(q: String) {
        if (key().isEmpty()) { askKey(); return }
        status.visibility = View.VISIBLE
        status.setText(R.string.loading)
        pool.execute {
            var msg: Int? = null
            var res: List<Photo> = emptyList()
            try {
                val url = if (q.isEmpty()) "https://api.pexels.com/v1/curated?per_page=30"
                else "https://api.pexels.com/v1/search?query=" + URLEncoder.encode(q, "UTF-8") +
                    "&per_page=30&locale=pt-BR"
                val arr = JSONObject(get(url)).getJSONArray("photos")
                res = (0 until arr.length()).map {
                    val o = arr.getJSONObject(it)
                    val src = o.getJSONObject("src")
                    Photo(src.getString("medium"), src.getString("large2x"), o.optString("photographer"))
                }
                msg = if (res.isEmpty()) R.string.pexels_empty else null
            } catch (e: SecurityException) {
                msg = R.string.pexels_bad_key
            } catch (e: IllegalStateException) {
                msg = R.string.pexels_limit
            } catch (e: Exception) {
                msg = R.string.pexels_error
            }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                photos = res
                adapter.notifyDataSetChanged()
                if (msg == null) status.visibility = View.GONE else { status.visibility = View.VISIBLE; status.setText(msg) }
            }
        }
    }

    private fun choose(p: Photo) {
        Toast.makeText(this, R.string.pexels_downloading, Toast.LENGTH_SHORT).show()
        pool.execute {
            val ok = try {
                val f = File(cacheDir, "pexels_pick.jpg")
                URL(p.full).openStream().use { i -> f.outputStream().use { i.copyTo(it) } }
                ImageStore.importPending(this, Uri.fromFile(f))
            } catch (e: Throwable) { false }
            runOnUiThread {
                if (ok) { setResult(Activity.RESULT_OK); finish() }
                else Toast.makeText(this, R.string.load_error, Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroy() {
        pool.shutdown()
        super.onDestroy()
    }
}
