package com.example.quebracabeca

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/** Toca o vídeo da montagem guardado no app; dá pra salvar na galeria, compartilhar ou apagar. */
class VideoPlayerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ID = "id"
    }

    private lateinit var id: String
    private lateinit var video: VideoView

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        id = intent.getStringExtra(EXTRA_ID) ?: return finish()
        if (!ImageStore.hasVideo(this, id)) {
            Toast.makeText(this, R.string.video_missing, Toast.LENGTH_SHORT).show()
            return finish()
        }
        setContentView(R.layout.activity_video)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById<View>(R.id.root)) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        findViewById<MaterialToolbar>(R.id.toolbar).apply {
            setNavigationIcon(R.drawable.ic_back)
            setNavigationOnClickListener { finish() }
        }
        video = findViewById(R.id.video)
        video.setMediaController(MediaController(this).also { it.setAnchorView(video) })
        video.setVideoURI(Uri.fromFile(ImageStore.videoFile(this, id)))
        video.setOnPreparedListener { it.isLooping = true; video.start() }

        findViewById<MaterialButton>(R.id.btn_save).setOnClickListener { saveThen(share = false) }
        findViewById<MaterialButton>(R.id.btn_share).setOnClickListener { saveThen(share = true) }
        findViewById<MaterialButton>(R.id.btn_delete).setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.video_delete)
                .setMessage(R.string.video_delete_msg)
                .setPositiveButton(R.string.library_delete) { _, _ ->
                    video.stopPlayback()
                    ImageStore.deleteVideo(this, id)
                    finish()
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }
    }

    private fun saveThen(share: Boolean) {
        val app = applicationContext
        Thread {
            val uri = ImageStore.saveVideoToGallery(app, id)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                if (uri == null) {
                    Toast.makeText(this, R.string.video_save_error, Toast.LENGTH_LONG).show()
                } else if (share) {
                    val send = Intent(Intent.ACTION_SEND)
                        .setType("video/mp4")
                        .putExtra(Intent.EXTRA_STREAM, uri)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    startActivity(Intent.createChooser(send, null))
                } else {
                    Toast.makeText(this, R.string.video_saved, Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }
}
