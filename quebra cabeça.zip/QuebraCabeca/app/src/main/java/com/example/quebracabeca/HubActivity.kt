package com.example.quebracabeca

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

/** Tela inicial: escolher qual jogo abrir. */
class HubActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#1B1F2A"))
            setPadding((20 * dp).toInt(), (56 * dp).toInt(), (20 * dp).toInt(), (24 * dp).toInt())
        }
        root.addView(TextView(this).apply {
            text = "Mesa de Jogos"; textSize = 30f; setTextColor(Color.WHITE); setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Escolha o que jogar hoje"; textSize = 15f; setTextColor(Color.parseColor("#AEB6C6"))
            setPadding(0, (4 * dp).toInt(), 0, (24 * dp).toInt())
        })
        fun card(title: String, sub: String, color: String, go: () -> Unit) {
            val c = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
                background = GradientDrawable().apply { cornerRadius = 22 * dp; setColor(Color.parseColor(color)) }
                setPadding((22 * dp).toInt(), (20 * dp).toInt(), (22 * dp).toInt(), (20 * dp).toInt())
                isClickable = true; isFocusable = true
                setOnClickListener { go() }
            }
            c.addView(TextView(this).apply { text = title; textSize = 24f; setTextColor(Color.WHITE); setTypeface(typeface, android.graphics.Typeface.BOLD) })
            c.addView(TextView(this).apply { text = sub; textSize = 14f; setTextColor(Color.parseColor("#E8ECF5")); setPadding(0, (4 * dp).toInt(), 0, 0) })
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            lp.bottomMargin = (16 * dp).toInt()
            root.addView(c, lp)
        }
        card("Quebra-Cabeça", "Imagens prontas ou suas, mesa decorada, loja, salas com amigos", "#2F6B5E") {
            startActivity(Intent(this, MainActivity::class.java))
        }
        card("Mesa de D&D", "Mapa, fichas guiadas, personagens e login para o mestre e os jogadores", "#7A2F3B") {
            startActivity(Intent(this, DndActivity::class.java))
        }
        setContentView(root)
    }
}
