package com.example.quebracabeca

import android.graphics.Path
import java.util.Random
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Gera o formato das peças. Cada aresta interna é uma curva de Bézier (3 segmentos cúbicos,
 * 10 pontos) com "pino" para um lado e "furo" para o outro. As bordas externas são retas.
 * Todas as coordenadas estão em pixels de renderização (a célula tem [cell] de lado).
 */
class JigsawGeometry(
    private val rows: Int,
    private val cols: Int,
    private val cell: Float,
    seed: Long
) {
    // h[r][c]: aresta horizontal entre as peças (r-1,c) e (r,c); vai da esquerda para a direita.
    private val h = Array(rows + 1) { arrayOfNulls<FloatArray>(cols) }

    // v[r][c]: aresta vertical entre as peças (r,c-1) e (r,c); vai de cima para baixo.
    private val v = Array(rows) { arrayOfNulls<FloatArray>(cols + 1) }

    init {
        val rnd = Random(seed)
        for (r in 1 until rows) for (c in 0 until cols) {
            h[r][c] = makeEdge(rnd, c * cell, r * cell, (c + 1) * cell, r * cell, 0f, 1f)
        }
        for (r in 0 until rows) for (c in 1 until cols) {
            v[r][c] = makeEdge(rnd, c * cell, r * cell, c * cell, (r + 1) * cell, 1f, 0f)
        }
    }

    /** Caminho fechado da peça (r,c) em coordenadas globais do quebra-cabeça. */
    fun pathFor(r: Int, c: Int): Path {
        val p = Path()
        val x0 = c * cell
        val y0 = r * cell
        p.moveTo(x0, y0)
        // topo (esq -> dir)
        if (r == 0) p.lineTo(x0 + cell, y0) else forward(p, h[r][c]!!)
        // direita (cima -> baixo)
        if (c == cols - 1) p.lineTo(x0 + cell, y0 + cell) else forward(p, v[r][c + 1]!!)
        // base (dir -> esq)
        if (r == rows - 1) p.lineTo(x0, y0 + cell) else backward(p, h[r + 1][c]!!)
        // esquerda (baixo -> cima)
        if (c == 0) p.lineTo(x0, y0) else backward(p, v[r][c]!!)
        p.close()
        return p
    }

    private fun forward(p: Path, e: FloatArray) {
        p.cubicTo(e[2], e[3], e[4], e[5], e[6], e[7])
        p.cubicTo(e[8], e[9], e[10], e[11], e[12], e[13])
        p.cubicTo(e[14], e[15], e[16], e[17], e[18], e[19])
    }

    private fun backward(p: Path, e: FloatArray) {
        p.cubicTo(e[16], e[17], e[14], e[15], e[12], e[13])
        p.cubicTo(e[10], e[11], e[8], e[9], e[6], e[7])
        p.cubicTo(e[4], e[5], e[2], e[3], e[0], e[1])
    }

    /**
     * Pontos de controle (x,y) da aresta de (x0,y0) a (x1,y1). (nx,ny) é a normal unitária
     * para onde o pino aponta quando sign = +1.
     */
    private fun makeEdge(
        rnd: Random, x0: Float, y0: Float, x1: Float, y1: Float, nx: Float, ny: Float
    ): FloatArray {
        val sign = if (rnd.nextBoolean()) 1f else -1f
        val j = 0.04f
        fun jit() = (rnd.nextFloat() * 2f - 1f) * j
        val a = jit()
        val b = jit()
        val c = jit()
        val d = jit()
        val e = jit()
        val t = 0.10f + (rnd.nextFloat() * 2f - 1f) * 0.01f

        val out = FloatArray(20)
        fun put(i: Int, u: Float, w: Float) {
            out[i * 2] = x0 + (x1 - x0) * u + nx * sign * w * cell
            out[i * 2 + 1] = y0 + (y1 - y0) * u + ny * sign * w * cell
        }
        put(0, 0f, 0f)
        put(1, 0.2f, a)
        put(2, 0.5f + b + d, -t + c)
        put(3, 0.5f - t + b, t + c)
        put(4, 0.5f - 2 * t + b - d, 3 * t + c)
        put(5, 0.5f + 2 * t + b - d, 3 * t + c)
        put(6, 0.5f + t + b, t + c)
        put(7, 0.5f + b + d, -t + c)
        put(8, 0.8f, e)
        put(9, 1f, 0f)
        return out
    }

    companion object {
        /** Escolhe linhas x colunas para ficar perto de [target] peças, com peças quase quadradas. */
        fun grid(target: Int, w: Int, h: Int): Pair<Int, Int> {
            val aspect = w.toFloat() / h.toFloat()
            val cols = max(2, sqrt(target * aspect).roundToInt())
            val rows = max(2, (target.toFloat() / cols).roundToInt())
            return rows to cols
        }
    }
}
