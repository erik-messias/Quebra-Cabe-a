package com.example.quebracabeca

import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.materialswitch.MaterialSwitch

/** Configurações do jogo (guardadas nas preferências do app). */
class SettingsActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences("puzzle_prefs", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        findViewById<MaterialToolbar>(R.id.toolbar).apply {
            setNavigationIcon(R.drawable.ic_back)
            setNavigationOnClickListener { finish() }
        }
        val list = findViewById<LinearLayout>(R.id.list)
        add(list, "lock_pieces", true, R.string.set_lock, R.string.set_lock_desc)
        add(list, "one_finger", true, R.string.set_one_finger, R.string.set_one_finger_desc)
        add(list, "arrange_edge", true, R.string.set_arrange, R.string.set_arrange_desc)
        add(list, "sound", true, R.string.set_sound, R.string.set_sound_desc)
        add(list, "vibration", true, R.string.set_vibration, R.string.set_vibration_desc)
        add(list, "fullscreen", false, R.string.set_fullscreen, R.string.set_fullscreen_desc)
    }

    private fun add(list: LinearLayout, key: String, def: Boolean, title: Int, desc: Int) {
        val v = layoutInflater.inflate(R.layout.item_setting, list, false)
        v.findViewById<TextView>(R.id.set_title).setText(title)
        v.findViewById<TextView>(R.id.set_desc).setText(desc)
        val sw = v.findViewById<MaterialSwitch>(R.id.set_switch)
        sw.isChecked = prefs.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(key, on).apply() }
        v.setOnClickListener { sw.toggle() }
        list.addView(v)
    }
}
