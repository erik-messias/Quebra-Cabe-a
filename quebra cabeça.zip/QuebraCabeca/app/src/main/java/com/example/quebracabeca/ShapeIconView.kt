package com.example.quebracabeca

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/** Ícone de uma peça no formato escolhido (Regular / Irregular / Selvagem), com destaque se selecionado. */
class ShapeIconView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var shapeStyle = JigsawGeometry.STYLE_IRREGULAR
        set(value) { field = value; buildPath(); invalidate() }

    var chosen = false
        set(value) { field = value; invalidate() }

    private val density = resources.displayMetrics.density
    private var piece: Path? = null
    private val bounds = RectF()
    private val shown = Path()

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFBDBDBD.toInt() }
    private val bgOn = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2B2B2B.toInt() }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFFD4D02A.toInt()
        strokeWidth = 2.5f * density
    }

    private fun buildPath() {
        // peça do meio de um puzzle 3x3, com 2 pinos e 2 furos
        val g = JigsawGeometry(3, 3, 100f, 11L + shapeStyle, shapeStyle, uniformSign = true)
        val p = g.pathFor(1, 1)
        p.computeBounds(bounds, true)
        piece = p
        buildShown()
    }

    private fun buildShown() {
        val p = piece ?: return
        if (width == 0 || height == 0) return
        val pad = 0.2f * minOf(width, height)
        val s = minOf((width - 2 * pad) / bounds.width(), (height - 2 * pad) / bounds.height())
        shown.reset()
        shown.addPath(p)
        shown.offset(-bounds.centerX(), -bounds.centerY())
        val m = android.graphics.Matrix()
        m.setScale(s, s)
        m.postTranslate(width / 2f, height / 2f)
        shown.transform(m)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (piece == null) buildPath() else buildShown()
    }

    override fun onDraw(canvas: Canvas) {
        if (piece == null) buildPath()
        val r = 10f * density
        val inset = border.strokeWidth / 2f
        if (chosen) {
            canvas.drawRoundRect(inset, inset, width - inset, height - inset, r, r, bgOn)
            canvas.drawRoundRect(inset, inset, width - inset, height - inset, r, r, border)
        }
        canvas.drawPath(shown, fill)
    }
}
