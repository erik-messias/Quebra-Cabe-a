package com.example.quebracabeca

import android.os.SystemClock
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.math.min

/** Eventos gravados durante o jogo. Posições são normalizadas: (pos - tabuleiro) / tamanho da célula. */
sealed class ReplayEvent {
    abstract val dt: Int

    class Snapshot(
        override val dt: Int,
        val x: FloatArray, val y: FloatArray, val gid: IntArray, val locked: BooleanArray,
        val rot: IntArray
    ) : ReplayEvent()

    class Down(override val dt: Int, val idx: Int) : ReplayEvent()

    class Move(override val dt: Int, val x: Float, val y: Float) : ReplayEvent()

    class Up(
        override val dt: Int,
        val idx: IntArray, val x: FloatArray, val y: FloatArray, val locked: BooleanArray,
        val rot: IntArray
    ) : ReplayEvent()
}

/** Grava os eventos em arquivo, de forma incremental (sobrevive a pausar/fechar o app). */
class ReplayRecorder(file: File, append: Boolean) {
    private var out: DataOutputStream? = try {
        DataOutputStream(BufferedOutputStream(FileOutputStream(file, append), 1 shl 16))
    } catch (e: Exception) {
        null
    }
    private var last = SystemClock.uptimeMillis()

    private inline fun write(type: Int, body: DataOutputStream.() -> Unit) {
        val o = out ?: return
        try {
            val now = SystemClock.uptimeMillis()
            val dt = min(now - last, 5000L).toInt()
            last = now
            o.writeByte(type)
            o.writeInt(dt)
            o.body()
        } catch (e: Exception) {
            out = null
        }
    }

    fun snapshot(x: FloatArray, y: FloatArray, gid: IntArray, locked: BooleanArray, rot: IntArray) =
        write(0) {
            writeInt(x.size)
            for (i in x.indices) {
                writeFloat(x[i]); writeFloat(y[i]); writeInt(gid[i]); writeBoolean(locked[i])
                writeByte(rot[i])
            }
        }

    fun down(idx: Int) = write(1) { writeInt(idx) }

    fun move(x: Float, y: Float) = write(2) { writeFloat(x); writeFloat(y) }

    fun up(idx: IntArray, x: FloatArray, y: FloatArray, locked: BooleanArray, rot: IntArray) =
        write(3) {
            writeInt(idx.size)
            for (i in idx.indices) {
                writeInt(idx[i]); writeFloat(x[i]); writeFloat(y[i]); writeBoolean(locked[i])
                writeByte(rot[i])
            }
        }

    fun flush() {
        try { out?.flush() } catch (e: Exception) { out = null }
    }

    fun close() {
        try { out?.flush(); out?.close() } catch (_: Exception) { }
        out = null
    }

    companion object {
        /** Lê todos os eventos; um arquivo truncado devolve o que foi possível ler. */
        fun readAll(file: File): List<ReplayEvent> {
            val list = ArrayList<ReplayEvent>()
            if (!file.exists()) return list
            try {
                DataInputStream(BufferedInputStream(FileInputStream(file), 1 shl 16)).use { d ->
                    while (true) {
                        val type = try { d.readByte().toInt() } catch (e: java.io.EOFException) { break }
                        val dt = d.readInt()
                        when (type) {
                            0 -> {
                                val n = d.readInt()
                                val x = FloatArray(n); val y = FloatArray(n)
                                val g = IntArray(n); val l = BooleanArray(n); val rt = IntArray(n)
                                for (i in 0 until n) {
                                    x[i] = d.readFloat(); y[i] = d.readFloat()
                                    g[i] = d.readInt(); l[i] = d.readBoolean()
                                    rt[i] = d.readByte().toInt()
                                }
                                list.add(ReplayEvent.Snapshot(dt, x, y, g, l, rt))
                            }
                            1 -> list.add(ReplayEvent.Down(dt, d.readInt()))
                            2 -> list.add(ReplayEvent.Move(dt, d.readFloat(), d.readFloat()))
                            3 -> {
                                val k = d.readInt()
                                val idx = IntArray(k); val x = FloatArray(k); val y = FloatArray(k)
                                val l = BooleanArray(k); val rt = IntArray(k)
                                for (i in 0 until k) {
                                    idx[i] = d.readInt(); x[i] = d.readFloat()
                                    y[i] = d.readFloat(); l[i] = d.readBoolean()
                                    rt[i] = d.readByte().toInt()
                                }
                                list.add(ReplayEvent.Up(dt, idx, x, y, l, rt))
                            }
                            else -> break
                        }
                    }
                }
            } catch (e: Exception) {
                // arquivo truncado: usa o que já foi lido
            }
            return list
        }
    }
}
