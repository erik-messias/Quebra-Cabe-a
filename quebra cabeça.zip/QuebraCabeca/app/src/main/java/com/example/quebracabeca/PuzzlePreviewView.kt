package com.example.quebracabeca

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.min

/**
 * Mostra a imagem com o contorno exato das peças por cima, para ver como o quebra-cabeça
 * vai ficar com a quantidade e o formato escolhidos (usa a mesma geometria e semente do jogo).
 */
class PuzzlePreviewView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var bitmap: Bitmap? = null
    private var rows = 0
    private var cols = 0
    private var style = JigsawGeometry.STYLE_IRREGULAR
    private var seed = 1L

    private var gridPath: Path? = null
    private val src = Rect()
    private val dst = RectF()
    private val density = resources.displayMetrics.density

    private val imagePaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFFFFFFFF.toInt()
        strokeWidth = 3f * density
    }
    private val lineDark = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0x99000000.toInt()
        strokeJoin = Paint.Join.ROUND
    }
    private val lineLight = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xDDFFFFFF.toInt()
        strokeJoin = Paint.Join.ROUND
    }

    fun setPuzzle(bmp: Bitmap?, rows: Int, cols: Int, style: Int, seed: Long) {
        bitmap = bmp
        this.rows = rows
        this.cols = cols
        this.style = style
        this.seed = seed
        rebuild()
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rebuild()
    }

    private fun rebuild() {
        val bmp = bitmap
        if (bmp == null || rows < 2 || cols < 2 || width == 0 || height == 0) {
            gridPath = null
            return
        }
        // mesmo recorte do jogo: células quadradas, centralizado
        val cellSrc = min(bmp.width / cols, bmp.height / rows).coerceAtLeast(1)
        val cropW = cellSrc * cols
        val cropH = cellSrc * rows
        val left = (bmp.width - cropW) / 2
        val top = (bmp.height - cropH) / 2
        src.set(left, top, left + cropW, top + cropH)

        val pad = 12f * density
        val s = min((width - 2 * pad) / cropW, (height - 2 * pad) / cropH)
        val w = cropW * s
        val h = cropH * s
        val x0 = (width - w) / 2f
        val y0 = (height - h) / 2f
        dst.set(x0, y0, x0 + w, y0 + h)

        val cell = w / cols
        val p = JigsawGeometry(rows, cols, cell, seed, style).gridPath()
        p.offset(x0, y0)
        gridPath = p

        // linhas mais finas quando há muitas peças
        val thin = (cell / (20f * density)).coerceIn(0.35f, 1f)
        lineLight.strokeWidth = 1.6f * density * thin
        lineDark.strokeWidth = lineLight.strokeWidth + 1.6f * density * thin
    }

    override fun onDraw(canvas: Canvas) {
        val bmp = bitmap ?: return
        canvas.drawBitmap(bmp, src, dst, imagePaint)
        gridPath?.let {
            canvas.drawPath(it, lineDark)
            canvas.drawPath(it, lineLight)
        }
        canvas.drawRect(dst, frame)
    }
}
