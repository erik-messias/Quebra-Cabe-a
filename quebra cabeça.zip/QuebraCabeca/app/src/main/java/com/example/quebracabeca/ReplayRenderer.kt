package com.example.quebracabeca

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RectF
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.provider.MediaStore
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/** Tudo que o renderizador precisa saber do puzzle (somente leitura). */
class ReplayAssets(
    val bitmaps: Array<Bitmap>,
    val image: Bitmap,
    val cell: Float,
    val margin: Float,
    val boardX: Float,
    val boardY: Float,
    val boardW: Float,
    val boardH: Float,
    val worldW: Float,
    val worldH: Float
)

object ReplayRenderer {

    private const val FPS = 30

    /**
     * Reproduz os eventos gravados e codifica um MP4 (H.264). A montagem é acelerada para
     * durar entre 12 e 45 segundos, seguida de ~2,5 s mostrando o resultado final.
     */
    fun render(
        a: ReplayAssets,
        events: List<ReplayEvent>,
        outFile: File,
        timeLabel: String,
        onProgress: (Int) -> Unit,
        isCancelled: () -> Boolean
    ): Boolean {
        if (events.isEmpty() || events[0] !is ReplayEvent.Snapshot) return false
        val n = a.bitmaps.size

        // ---- linha do tempo (pausas longas são comprimidas)
        val te = LongArray(events.size)
        var acc = 0L
        for ((i, e) in events.withIndex()) {
            acc += when (e) {
                is ReplayEvent.Snapshot -> 0
                is ReplayEvent.Move -> min(e.dt, 100)
                is ReplayEvent.Down -> min(e.dt, 400)
                is ReplayEvent.Up -> min(e.dt, 300)
            }
            te[i] = acc
        }
        val durMs = max(acc, 1500L)
        val videoSec = (durMs / 1000.0 / 3.0).coerceIn(12.0, 45.0)
        val mainFrames = (videoSec * FPS).toInt()
        val holdFrames = (2.5 * FPS).toInt()
        val totalFrames = mainFrames + holdFrames

        // ---- dimensões do vídeo (múltiplos de 16)
        val sc0 = 1080f / max(a.worldW, a.worldH)
        val vw = max(16, ((a.worldW * sc0).toInt() / 16) * 16)
        val vh = max(16, ((a.worldH * sc0).toInt() / 16) * 16)
        val fit = min(vw / a.worldW, vh / a.worldH)
        val offX = (vw - a.worldW * fit) / 2f
        val offY = (vh - a.worldH * fit) / 2f

        // ---- estado da reprodução
        val px = FloatArray(n)
        val py = FloatArray(n)
        val gid = IntArray(n)
        val locked = BooleanArray(n)
        val z = IntArray(n)
        val inDrag = BooleanArray(n)
        var zc = 0
        var nextGid = 1_000_000
        var anchor = -1
        var members = IntArray(0)
        var dragging = false
        var applied = 0 // quantos eventos já aplicados
        var lastApplyT = 0L

        fun applyEvent(e: ReplayEvent) {
            when (e) {
                is ReplayEvent.Snapshot -> {
                    for (i in 0 until n) {
                        px[i] = e.x[i]; py[i] = e.y[i]; gid[i] = e.gid[i]; locked[i] = e.locked[i]
                        inDrag[i] = false
                    }
                    dragging = false
                }
                is ReplayEvent.Down -> {
                    anchor = e.idx
                    val g = gid[anchor]
                    members = (0 until n).filter { gid[it] == g }.toIntArray()
                    zc++
                    for (m in members) { inDrag[m] = true; z[m] = zc }
                    dragging = true
                }
                is ReplayEvent.Move -> {
                    if (dragging && anchor >= 0) {
                        val dx = e.x - px[anchor]
                        val dy = e.y - py[anchor]
                        for (m in members) { px[m] += dx; py[m] += dy }
                    }
                }
                is ReplayEvent.Up -> {
                    for (m in members) inDrag[m] = false
                    dragging = false
                    zc++
                    val g = nextGid++
                    for (k in e.idx.indices) {
                        val i = e.idx[k]
                        px[i] = e.x[k]; py[i] = e.y[k]; locked[i] = e.locked[k]
                        gid[i] = g; z[i] = zc
                    }
                }
            }
        }

        // ---- pincéis
        val bg = Paint().apply { color = 0xFF1E2227.toInt() }
        val table = Paint().apply { color = 0xFF353B45.toInt() }
        val board = Paint().apply { color = 0xFF262B33.toInt() }
        val boardStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; color = 0x66FFFFFF; strokeWidth = 2f / fit
        }
        val ghost = Paint(Paint.FILTER_BITMAP_FLAG).apply { alpha = 46 }
        val piece = Paint(Paint.FILTER_BITMAP_FLAG)
        val shadow = Paint(Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = PorterDuffColorFilter(Color.argb(120, 0, 0, 0), PorterDuff.Mode.SRC_IN)
        }
        val band = Paint().apply { color = 0xB3000000.toInt() }
        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            textSize = vw * 0.055f
            isFakeBoldText = true
        }

        fun drawFrame(c: Canvas, ox: Float, oy: Float, showText: Boolean) {
            c.drawRect(0f, 0f, vw.toFloat(), vh.toFloat(), bg)
            c.save()
            c.translate(offX, offY)
            c.scale(fit, fit)
            c.drawRect(0f, 0f, a.worldW, a.worldH, table)
            c.drawRect(a.boardX, a.boardY, a.boardX + a.boardW, a.boardY + a.boardH, board)
            c.drawBitmap(
                a.image, null,
                RectF(a.boardX, a.boardY, a.boardX + a.boardW, a.boardY + a.boardH), ghost
            )
            c.drawRect(a.boardX, a.boardY, a.boardX + a.boardW, a.boardY + a.boardH, boardStroke)

            fun drawPiece(i: Int, dx: Float, dy: Float, p: Paint) {
                c.drawBitmap(
                    a.bitmaps[i],
                    a.boardX + px[i] * a.cell - a.margin + dx,
                    a.boardY + py[i] * a.cell - a.margin + dy, p
                )
            }
            for (i in 0 until n) if (locked[i] && !inDrag[i]) drawPiece(i, 0f, 0f, piece)
            val loose = (0 until n).filter { !locked[it] && !inDrag[it] }.sortedBy { z[it] }
            for (i in loose) drawPiece(i, 0f, 0f, piece)
            if (dragging) {
                val off = a.cell * 0.06f
                for (m in members) drawPiece(m, ox + off, oy + off * 1.5f, shadow)
                for (m in members) drawPiece(m, ox, oy, piece)
            }
            c.restore()

            if (showText) {
                val h = vh * 0.12f
                c.drawRect(0f, vh - h, vw.toFloat(), vh.toFloat(), band)
                c.drawText(timeLabel, vw / 2f, vh - h / 2f + text.textSize / 3f, text)
            }
        }

        // ---- codificador
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, vw, vh).apply {
            setInteger(
                MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface
            )
            setInteger(MediaFormat.KEY_BIT_RATE, 6_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        var enc: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var surface: android.view.Surface? = null
        var started = false
        var track = -1
        var outCount = 0L
        var ok = false
        val info = MediaCodec.BufferInfo()

        fun drain(eos: Boolean) {
            val e = enc ?: return
            val m = muxer ?: return
            var tries = 0
            while (true) {
                val idx = e.dequeueOutputBuffer(info, if (eos) 10_000L else 0L)
                if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (!eos || ++tries > 500) return
                    continue
                }
                if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = m.addTrack(e.outputFormat)
                    m.start()
                    started = true
                    continue
                }
                if (idx < 0) continue
                val buf = e.getOutputBuffer(idx)
                if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                if (info.size > 0 && started && buf != null) {
                    // o tempo real de renderização não importa: usamos 30 fps exatos
                    info.presentationTimeUs = outCount * 1_000_000L / FPS
                    outCount++
                    buf.position(info.offset)
                    buf.limit(info.offset + info.size)
                    m.writeSampleData(track, buf, info)
                }
                e.releaseOutputBuffer(idx, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
            }
        }

        try {
            outFile.parentFile?.mkdirs()
            enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            surface = enc.createInputSurface()
            enc.start()
            muxer = MediaMuxer(outFile.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            for (f in 0 until totalFrames) {
                if (isCancelled()) return false
                val inHold = f >= mainFrames
                val ts = if (inHold) durMs.toDouble() else f * durMs.toDouble() / mainFrames

                while (applied < events.size && te[applied] <= ts) {
                    applyEvent(events[applied])
                    lastApplyT = te[applied]
                    applied++
                }
                if (inHold) while (applied < events.size) { applyEvent(events[applied]); applied++ }

                // interpolação suave do arrasto entre dois eventos de movimento
                var ox = 0f
                var oy = 0f
                if (dragging && !inHold && applied < events.size) {
                    val nx = events[applied]
                    if (nx is ReplayEvent.Move && anchor >= 0 && te[applied] > lastApplyT) {
                        val frac = ((ts - lastApplyT) / (te[applied] - lastApplyT)).toFloat()
                        ox = (nx.x - px[anchor]) * a.cell * frac
                        oy = (nx.y - py[anchor]) * a.cell * frac
                    }
                }

                val canvas = surface.lockHardwareCanvas()
                try {
                    drawFrame(canvas, ox, oy, inHold && f >= mainFrames + FPS / 2)
                } finally {
                    surface.unlockCanvasAndPost(canvas)
                }
                drain(false)
                if (f % 10 == 0) onProgress(f * 100 / totalFrames)
            }
            enc.signalEndOfInputStream()
            drain(true)
            ok = started && outCount > 0
            onProgress(100)
        } catch (t: Throwable) {
            ok = false
        } finally {
            try { enc?.stop() } catch (_: Throwable) { }
            try { enc?.release() } catch (_: Throwable) { }
            try { surface?.release() } catch (_: Throwable) { }
            try { if (started) muxer?.stop() } catch (_: Throwable) { ok = false }
            try { muxer?.release() } catch (_: Throwable) { }
        }
        return ok
    }

}

object VideoSaver {
    /** Copia o MP4 para a galeria (Filmes/QuebraCabeca). Devolve o Uri ou null. */
    fun saveToGallery(ctx: Context, file: File): Uri? {
        return try {
            val name = "quebra-cabeca_" +
                SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/QuebraCabeca")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = ctx.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: return null
            resolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                ?: return null
            val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
            uri
        } catch (e: Exception) {
            null
        }
    }
}
