package com.example.quebracabeca

import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/** Coloca o WebView dentro de um quadro que respeita barra de status, recorte da câmera, barra de navegação e teclado. */
object WebInsets {
    fun wrap(act: AppCompatActivity, web: View, bg: String) {
        val f = FrameLayout(act)
        f.setBackgroundColor(Color.parseColor(bg))
        f.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        act.setContentView(f)
        ViewCompat.setOnApplyWindowInsetsListener(f) { v, ins ->
            val b = ins.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.ime()
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsetsCompat.CONSUMED
        }
        ViewCompat.requestApplyInsets(f)
    }
}
