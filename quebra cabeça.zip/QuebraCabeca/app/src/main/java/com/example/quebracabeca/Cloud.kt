package com.example.quebracabeca

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Comunidade online (Firebase Realtime Database via REST, sem SDK). */
object Cloud {
    private const val DB = "https://quebra-cabeca-d14c9-default-rtdb.firebaseio.com"
    private const val KEY = "AIzaSyBU7Ax1oSGuUrOSi3Uy7ZlRaOYKxDpzjoo"

    class Deco(val id: String, val name: String, val price: Int, val author: String, val authorUid: String, val sales: Int, val img: String)

    private var idToken: String? = null
    private var tokenExp = 0L

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("puzzle_prefs", Context.MODE_PRIVATE)

    private fun http(method: String, url: String, body: String? = null): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 12000; c.readTimeout = 20000
        if (body != null) { c.doOutput = true; c.setRequestProperty("Content-Type", "application/json"); c.outputStream.use { it.write(body.toByteArray()) } }
        val code = c.responseCode
        val s = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (code !in 200..299) throw java.io.IOException("HTTP $code $s")
        return s
    }

    /** Identidade anônima. Se o login falhar, usa um id local (o banco em modo de teste aceita). */
    @Synchronized
    fun uid(ctx: Context): String {
        val p = prefs(ctx)
        var uid = p.getString("cloud_uid", null)
        if (uid == null) {
            uid = try {
                val r = JSONObject(http("POST", "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$KEY", "{\"returnSecureToken\":true}"))
                idToken = r.getString("idToken"); tokenExp = System.currentTimeMillis() + 3300_000
                p.edit().putString("cloud_refresh", r.getString("refreshToken")).apply()
                r.getString("localId")
            } catch (_: Exception) { "local_" + java.util.UUID.randomUUID().toString().take(12) }
            p.edit().putString("cloud_uid", uid).apply()
        }
        return uid
    }

    @Synchronized
    private fun auth(ctx: Context): String {
        uid(ctx)
        if (idToken != null && System.currentTimeMillis() < tokenExp) return "?auth=$idToken"
        val rt = prefs(ctx).getString("cloud_refresh", null) ?: return ""
        return try {
            val r = JSONObject(http("POST", "https://securetoken.googleapis.com/v1/token?key=$KEY", "{\"grant_type\":\"refresh_token\",\"refresh_token\":\"$rt\"}"))
            idToken = r.getString("id_token"); tokenExp = System.currentTimeMillis() + 3300_000
            "?auth=$idToken"
        } catch (_: Exception) { "" }
    }

    fun db(ctx: Context, method: String, path: String, body: String? = null, extra: String = ""): String {
        val a = auth(ctx)
        val q = if (a.isEmpty()) (if (extra.isEmpty()) "" else "?$extra") else a + (if (extra.isEmpty()) "" else "&$extra")
        return http(method, "$DB/$path.json$q", body)
    }

    fun toBase64(bmp: Bitmap): String {
        var b = bmp
        if (maxOf(b.width, b.height) > 320) { val k = 320f / maxOf(b.width, b.height); b = Bitmap.createScaledBitmap(b, (b.width * k).toInt().coerceAtLeast(1), (b.height * k).toInt().coerceAtLeast(1), true) }
        val o = ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.PNG, 100, o)
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }

    fun fromBase64(s: String): Bitmap? = try {
        val b = Base64.decode(s, Base64.DEFAULT); android.graphics.BitmapFactory.decodeByteArray(b, 0, b.size)
    } catch (_: Exception) { null }

    /** Publica uma decoração. Devolve o id na nuvem. */
    fun publish(ctx: Context, name: String, price: Int, author: String, bmp: Bitmap): String {
        val o = JSONObject().put("name", name).put("price", price).put("author", author).put("authorUid", uid(ctx))
            .put("created", System.currentTimeMillis()).put("sales", 0).put("img", toBase64(bmp))
        return JSONObject(db(ctx, "POST", "decos", o.toString())).getString("name")
    }

    fun list(ctx: Context): List<Deco> {
        val s = db(ctx, "GET", "decos", null, "orderBy=%22\$key%22&limitToLast=60")
        if (s == "null" || s.isBlank()) return emptyList()
        val o = JSONObject(s)
        val out = ArrayList<Deco>()
        for (k in o.keys()) {
            val d = o.optJSONObject(k) ?: continue
            out.add(Deco(k, d.optString("name"), d.optInt("price"), d.optString("author"), d.optString("authorUid"), d.optInt("sales"), d.optString("img")))
        }
        out.sortByDescending { it.id }
        return out
    }

    /** Registra a venda: o autor recebe as moedas na próxima vez que abrir a loja. */
    fun recordSale(ctx: Context, d: Deco) {
        if (d.price > 0 && d.authorUid.isNotEmpty())
            db(ctx, "POST", "earnings/${d.authorUid}", JSONObject().put("amount", d.price).put("deco", d.id).put("t", System.currentTimeMillis()).toString())
        db(ctx, "PUT", "decos/${d.id}/sales", "{\".sv\":{\"increment\":1}}")
    }

    /** Recolhe as moedas de vendas pendentes. Devolve o total. */
    fun claimEarnings(ctx: Context): Int {
        val path = "earnings/${uid(ctx)}"
        val s = db(ctx, "GET", path)
        if (s == "null" || s.isBlank()) return 0
        val o = JSONObject(s); var total = 0
        val keys = ArrayList<String>()
        for (k in o.keys()) { total += o.optJSONObject(k)?.optInt("amount") ?: 0; keys.add(k) }
        for (k in keys) db(ctx, "DELETE", "$path/$k")
        if (total > 0) Wallet.add(ctx, total)
        return total
    }

    fun creatorName(ctx: Context): String? = prefs(ctx).getString("creator_name", null)
    fun setCreatorName(ctx: Context, n: String) { prefs(ctx).edit().putString("creator_name", n).apply() }
}

fun bg(block: () -> Unit) { Thread { try { block() } catch (_: Throwable) {} }.start() }
