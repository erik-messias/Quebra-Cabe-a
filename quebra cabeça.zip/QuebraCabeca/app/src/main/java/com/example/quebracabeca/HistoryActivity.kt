package com.example.quebracabeca

import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.DateFormat
import java.util.Date
import java.util.Locale

/** Galeria: histórico dos quebra-cabeças que você já montou, do mais recente para o mais antigo. */
class HistoryActivity : AppCompatActivity() {

    private lateinit var empty: View
    private var items: List<ImageStore.Entry> = emptyList()
    private val dateFmt = DateFormat.getDateInstance(DateFormat.LONG, Locale("pt", "BR"))

    private class VH(v: View) : RecyclerView.ViewHolder(v) {
        val img: ImageView = v.findViewById(R.id.hist_img)
        val label: TextView = v.findViewById(R.id.hist_label)
        val date: TextView = v.findViewById(R.id.hist_date)
    }

    private val adapter = object : RecyclerView.Adapter<VH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_history, parent, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val e = items[position]
            val tf = ImageStore.thumbFile(this@HistoryActivity, e.id)
            h.img.setImageBitmap(if (tf.exists()) BitmapFactory.decodeFile(tf.path) else null)
            h.date.text = dateFmt.format(Date(e.updated))
            h.label.text = getString(
                R.string.gallery_item, "", e.count, formatTime(e.elapsed)
            ).removePrefix(" · ").trim()
            h.itemView.setOnClickListener { open(e) }
            h.itemView.setOnLongClickListener { confirmDelete(e); true }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_library)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        findViewById<MaterialToolbar>(R.id.toolbar).apply {
            setTitle(R.string.gallery_title)
            setNavigationIcon(R.drawable.ic_back)
            setNavigationOnClickListener { finish() }
        }
        empty = findViewById(R.id.empty)
        (empty as TextView).setText(R.string.gallery_empty)
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@HistoryActivity)
            adapter = this@HistoryActivity.adapter
        }
    }

    override fun onResume() {
        super.onResume()
        Thread {
            val l = ImageStore.list(this).filter { it.completed }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                items = l
                adapter.notifyDataSetChanged()
                empty.visibility = if (l.isEmpty()) View.VISIBLE else View.GONE
            }
        }.start()
    }

    private fun open(e: ImageStore.Entry) {
        val hasVideo = ImageStore.hasVideo(this, e.id)
        val labels = ArrayList<String>()
        if (hasVideo) labels.add(getString(R.string.library_watch))
        labels.add(getString(R.string.library_again))
        MaterialAlertDialogBuilder(this)
            .setItems(labels.toTypedArray()) { _, which ->
                if (hasVideo && which == 0) {
                    startActivity(
                        Intent(this, VideoPlayerActivity::class.java)
                            .putExtra(VideoPlayerActivity.EXTRA_ID, e.id)
                    )
                } else {
                    val n = ImageStore.replayFrom(this, e.id, System.nanoTime()) ?: return@setItems
                    startActivity(
                        Intent(this, PuzzleActivity::class.java)
                            .putExtra(PuzzleActivity.EXTRA_ID, n.id)
                            .putExtra(PuzzleActivity.EXTRA_COUNT, n.count)
                            .putExtra(PuzzleActivity.EXTRA_STYLE, n.style)
                            .putExtra(PuzzleActivity.EXTRA_SEED, n.seed)
                            .putExtra(PuzzleActivity.EXTRA_ROTATION, n.rotation)
                    )
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun confirmDelete(e: ImageStore.Entry) {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.library_delete_title)
            .setMessage(R.string.library_delete_msg)
            .setPositiveButton(R.string.library_delete) { _, _ ->
                ImageStore.delete(this, e.id)
                onResume()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun formatTime(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%02d:%02d", m, sec)
    }
}
