package com.example.quebracabeca

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

/** Leitor de HQ: a mesma página (reader.html) usada no PC, dentro de um WebView. */
class ReaderActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private val pick = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        val uris = if (r.resultCode == RESULT_OK && data != null) WebChromeClient.FileChooserParams.parseResult(r.resultCode, data) else null
        chooser?.onReceiveValue(uris)
        chooser = null
    }

    private val docs = ArrayList<Uri>()
    private val prefs by lazy { getSharedPreferences("hq", MODE_PRIVATE) }
    private val treePick = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Throwable) {}
            prefs.edit().putString("tree", uri.toString()).apply()
            scanTree(uri)
        }
    }

    /** Percorre a pasta escolhida (com subpastas) e entrega a lista de HQs à página. */
    private fun scanTree(tree: Uri) {
        Thread {
            val out = org.json.JSONArray()
            val exts = setOf("cbz", "cbr", "pdf", "zip", "rar")
            fun walk(docId: String) {
                val kids = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
                val cols = arrayOf(
                    android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE,
                    android.provider.DocumentsContract.Document.COLUMN_SIZE
                )
                try {
                    contentResolver.query(kids, cols, null, null, null)?.use { c ->
                        while (c.moveToNext()) {
                            val id = c.getString(0); val name = c.getString(1) ?: continue
                            if (c.getString(2) == android.provider.DocumentsContract.Document.MIME_TYPE_DIR) { walk(id); continue }
                            if (name.substringAfterLast('.', "").lowercase() !in exts) continue
                            synchronized(docs) {
                                docs.add(android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, id))
                                out.put(org.json.JSONObject().put("i", docs.size - 1).put("name", name).put("size", c.getLong(3)))
                            }
                        }
                    }
                } catch (_: Throwable) {}
            }
            walk(android.provider.DocumentsContract.getTreeDocumentId(tree))
            runOnUiThread { web.evaluateJavascript("window.__folderResult&&window.__folderResult(" + out.toString() + ")", null) }
        }.start()
    }

    /** Ponte da loja de mangás: só deixa passar o MangaDex (as imagens dele não aceitam acesso direto da página). */
    private fun proxy(target: String?): android.webkit.WebResourceResponse {
        val hdr = mutableMapOf("Access-Control-Allow-Origin" to "*")
        fun fail(c: Int) = android.webkit.WebResourceResponse("text/plain", "utf-8", c, "Error", hdr, java.io.ByteArrayInputStream(ByteArray(0)))
        if (target == null) return fail(400)
        return try {
            val url = java.net.URL(target)
            val host = url.host.lowercase()
            val ok = url.protocol == "https" && (host == "mangadex.org" || host.endsWith(".mangadex.org") || host.endsWith(".mangadex.network"))
            if (!ok) return fail(403)
            val c = url.openConnection() as java.net.HttpURLConnection
            c.setRequestProperty("User-Agent", "QuebraCabeca/1.0 (Android)")
            c.connectTimeout = 20000; c.readTimeout = 40000
            val code = c.responseCode
            val mime = (c.contentType ?: "application/octet-stream").substringBefore(';')
            val stream = if (code in 200..299) c.inputStream else (c.errorStream ?: java.io.ByteArrayInputStream(ByteArray(0)))
            android.webkit.WebResourceResponse(mime, null, code, "OK", hdr, stream)
        } catch (_: Throwable) { fail(502) }
    }

    inner class Bridge {
        @android.webkit.JavascriptInterface fun pickFolder() { runOnUiThread { treePick.launch(null) } }
        @android.webkit.JavascriptInterface fun openUrl(u: String) {
            if (!u.startsWith("https://")) return
            runOnUiThread { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (_: Throwable) {} }
        }
        @android.webkit.JavascriptInterface fun hasFolder(): Boolean = prefs.getString("tree", null) != null
        @android.webkit.JavascriptInterface fun rescan() {
            val s = prefs.getString("tree", null) ?: return
            runOnUiThread { scanTree(Uri.parse(s)) }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        web = WebView(this)
        WebInsets.wrap(this, web, "#14171F")
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        web.addJavascriptInterface(Bridge(), "nativeReader")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?): Boolean {
                chooser?.onReceiveValue(null)
                chooser = cb
                return try { pick.launch(p!!.createIntent()); true } catch (_: Throwable) { chooser = null; false }
            }
        }
        // o gamertag do quebra-cabeça é reaproveitado
        val tag = Cloud.creatorName(this) ?: ""
        web.loadUrl("file:///android_asset/reader.html")
        web.webViewClient = object : WebViewClient() {
            // as HQs da pasta escolhida são lidas por aqui: https://hqfile.local/<n>
            override fun shouldInterceptRequest(v: WebView?, req: android.webkit.WebResourceRequest?): android.webkit.WebResourceResponse? {
                val u = req?.url ?: return null
                if (u.host == "mdproxy.local") return proxy(u.getQueryParameter("u"))
                if (u.host != "hqfile.local") return null
                val i = u.lastPathSegment?.toIntOrNull()
                val doc = synchronized(docs) { if (i != null && i in docs.indices) docs[i] else null }
                val hdr = mapOf("Access-Control-Allow-Origin" to "*")
                if (doc == null) return android.webkit.WebResourceResponse("text/plain", "utf-8", 404, "Not Found", hdr, java.io.ByteArrayInputStream(ByteArray(0)))
                return try {
                    android.webkit.WebResourceResponse("application/octet-stream", null, 200, "OK", hdr, contentResolver.openInputStream(doc))
                } catch (_: Throwable) {
                    android.webkit.WebResourceResponse("text/plain", "utf-8", 500, "Error", hdr, java.io.ByteArrayInputStream(ByteArray(0)))
                }
            }
            override fun onPageFinished(v: WebView?, url: String?) {
                v?.evaluateJavascript("window.nativeTag=" + org.json.JSONObject.quote(tag) + ";window.onNativeTag&&window.onNativeTag();", null)
            }
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.dndBack&&window.dndBack())||false") { r ->
                    if (r == "true") return@evaluateJavascript
                    isEnabled = false; onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
