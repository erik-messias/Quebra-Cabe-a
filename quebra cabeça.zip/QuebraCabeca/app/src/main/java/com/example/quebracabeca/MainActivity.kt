package com.example.quebracabeca

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private val counts = intArrayOf(6, 12, 24, 48, 70, 100, 150, 200, 300, 500, 750, 1000, 1500, 2000)

    private lateinit var preview: PuzzlePreviewView
    private lateinit var hint: TextView
    private lateinit var label: TextView
    private lateinit var seek: SeekBar
    private lateinit var btnStart: MaterialButton
    private lateinit var drawer: DrawerLayout
    private var coinsText: TextView? = null
    private lateinit var switchRotate: MaterialSwitch
    private lateinit var switchTimed: MaterialSwitch
    private lateinit var icons: List<ShapeIconView>

    private var previewBitmap: Bitmap? = null
    private var style = JigsawGeometry.STYLE_IRREGULAR
    private var seed = System.nanoTime()

    private val prefs by lazy { getSharedPreferences("puzzle_prefs", MODE_PRIVATE) }

    private val pexelsLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) afterNewImage()
    }

    private val cropLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        seed = System.nanoTime()
        showPendingImage()
    }

    /** Imagem nova escolhida: mostra na prévia e abre o corte. */
    private fun afterNewImage() {
        seed = System.nanoTime()
        showPendingImage()
        cropLauncher.launch(Intent(this, CropActivity::class.java))
    }

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) importImage(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val root = findViewById<View>(R.id.root)
        val pad = (16 * resources.displayMetrics.density).toInt()
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(bars.left + pad, bars.top + pad, bars.right + pad, bars.bottom + pad)
            (findViewById<View>(R.id.btn_menu).layoutParams as android.widget.FrameLayout.LayoutParams).apply {
                topMargin = bars.top + (10 * resources.displayMetrics.density).toInt()
                leftMargin = bars.left + (12 * resources.displayMetrics.density).toInt()
            }
            insets
        }

        preview = findViewById(R.id.preview)
        hint = findViewById(R.id.hint)
        label = findViewById(R.id.pieces_label)
        seek = findViewById(R.id.seek)
        btnStart = findViewById(R.id.btn_start)
        switchRotate = findViewById(R.id.switch_rotate)
        switchRotate.isChecked = prefs.getBoolean("rotation", false)
        switchTimed = findViewById(R.id.switch_timed)
        switchTimed.isChecked = prefs.getBoolean("timed", false)
        switchTimed.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("timed", on).apply() }
        switchRotate.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("rotation", on).apply() }

        icons = listOf<ShapeIconView>(
            findViewById(R.id.icon_regular),
            findViewById(R.id.icon_irregular),
            findViewById(R.id.icon_wild)
        )
        icons[0].shapeStyle = JigsawGeometry.STYLE_REGULAR
        icons[1].shapeStyle = JigsawGeometry.STYLE_IRREGULAR
        icons[2].shapeStyle = JigsawGeometry.STYLE_WILD
        findViewById<View>(R.id.shape_regular).setOnClickListener { selectStyle(JigsawGeometry.STYLE_REGULAR) }
        findViewById<View>(R.id.shape_irregular).setOnClickListener { selectStyle(JigsawGeometry.STYLE_IRREGULAR) }
        findViewById<View>(R.id.shape_wild).setOnClickListener { selectStyle(JigsawGeometry.STYLE_WILD) }

        // restaura as últimas escolhas
        style = prefs.getInt("style", JigsawGeometry.STYLE_IRREGULAR).coerceIn(0, 2)
        seek.max = counts.size - 1
        val savedCount = prefs.getInt("count_value", 48)
        seek.progress = counts.indexOfFirst { it >= savedCount }.let { if (it < 0) counts.size - 1 else it }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) = refreshPreview()
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                prefs.edit().putInt("count_value", currentCount()).apply()
            }
        })

        val pick = View.OnClickListener {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        preview.setOnClickListener(pick)
        findViewById<View>(R.id.btn_pick).setOnClickListener(pick)

        btnStart.setOnClickListener { onStartClicked() }

        drawer = findViewById(R.id.drawer)
        findViewById<View>(R.id.btn_menu).setOnClickListener { drawer.openDrawer(GravityCompat.START) }
        coinsText = findViewById(R.id.coins)
        buildDrawer()
        handleShare(intent)

        showPendingImage()
    }

    override fun onResume() {
        super.onResume()
        coinsText?.text = Wallet.coins(this).toString()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShare(intent)
    }

    /** Imagem compartilhada de outro app (Pinterest, galeria, navegador...) vira o puzzle. */
    private fun handleShare(i: Intent?) {
        if (i?.action != Intent.ACTION_SEND || i.type?.startsWith("image/") != true) return
        val uri: Uri? = if (android.os.Build.VERSION.SDK_INT >= 33)
            i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        else @Suppress("DEPRECATION") i.getParcelableExtra(Intent.EXTRA_STREAM)
        i.action = null
        if (uri != null) importImage(uri)
    }

    private fun row(list: android.widget.LinearLayout, icon: Int, title: Int, onClick: () -> Unit) {
        val v = layoutInflater.inflate(R.layout.item_drawer_row, list, false)
        v.findViewById<android.widget.ImageView>(R.id.row_icon).setImageResource(icon)
        v.findViewById<TextView>(R.id.row_title).setText(title)
        v.setOnClickListener { drawer.closeDrawer(GravityCompat.START); onClick() }
        list.addView(v)
    }

    private fun buildDrawer() {
        val list = findViewById<android.widget.LinearLayout>(R.id.drawer_list)
        row(list, R.drawable.ic_plus, R.string.main_new) {}
        row(list, R.drawable.ic_library, R.string.main_library) {
            startActivity(Intent(this, LibraryActivity::class.java))
        }
        row(list, R.drawable.ic_gallery, R.string.main_gallery) {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        row(list, R.drawable.ic_search, R.string.main_images) {
            pexelsLauncher.launch(Intent(this, PexelsActivity::class.java))
        }
        row(list, R.drawable.ic_crop, R.string.main_crop) {
            if (ImageStore.hasPending(this)) cropLauncher.launch(Intent(this, CropActivity::class.java))
            else Toast.makeText(this, R.string.tap_to_pick, Toast.LENGTH_SHORT).show()
        }
        row(list, R.drawable.ic_gallery, R.string.main_join_room) { joinRoom() }
        row(list, R.drawable.ic_store, R.string.main_shop) {
            startActivity(Intent(this, ShopActivity::class.java))
        }
        row(list, R.drawable.ic_settings, R.string.drawer_settings) {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun joinRoom() {
        val et = android.widget.EditText(this).apply {
            hint = "Código da sala (5 letras)"; setSingleLine()
            filters = arrayOf(android.text.InputFilter.AllCaps(), android.text.InputFilter.LengthFilter(5))
        }
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle(R.string.main_join_room).setView(et)
            .setPositiveButton("Entrar") { _, _ ->
                val code = et.text.toString().trim().uppercase()
                if (code.startsWith("P")) { Toast.makeText(this, "Essa sala é do PC. Entre pelo computador.", Toast.LENGTH_LONG).show(); return@setPositiveButton }
                Toast.makeText(this, "Entrando na sala…", Toast.LENGTH_SHORT).show()
                bg {
                    val r = try { Room.join(this, code) } catch (e: Throwable) { null }
                    val id = r?.let { ImageStore.createFromRoom(this, it.img, it.count, it.style, it.seed, it.rotation, it.state) }
                    runOnUiThread {
                        if (r == null || id == null) Toast.makeText(this, "Sala não encontrada. Confira o código e a internet.", Toast.LENGTH_LONG).show()
                        else startActivity(Intent(this, PuzzleActivity::class.java)
                            .putExtra(PuzzleActivity.EXTRA_ID, id).putExtra(PuzzleActivity.EXTRA_RESUME, true)
                            .putExtra(PuzzleActivity.EXTRA_COUNT, r.count).putExtra(PuzzleActivity.EXTRA_STYLE, r.style)
                            .putExtra(PuzzleActivity.EXTRA_SEED, r.seed).putExtra(PuzzleActivity.EXTRA_ROTATION, r.rotation)
                            .putExtra(PuzzleActivity.EXTRA_ROOM, code))
                    }
                }
            }
            .setNegativeButton(android.R.string.cancel, null).show()
    }

    private fun selectStyle(s: Int) {
        style = s
        prefs.edit().putInt("style", s).apply()
        refreshPreview()
    }

    private fun importImage(uri: Uri) {
        hint.visibility = View.VISIBLE
        hint.setText(R.string.loading)
        Thread {
            val ok = try {
                ImageStore.importPending(this, uri)
            } catch (e: Throwable) {
                false
            }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                if (ok) {
                    afterNewImage()
                } else {
                    hint.setText(R.string.tap_to_pick)
                    Toast.makeText(this, R.string.load_error, Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun showPendingImage() {
        previewBitmap = ImageStore.loadPendingPreview(this)
        if (previewBitmap == null) {
            hint.visibility = View.VISIBLE
            hint.setText(R.string.tap_to_pick)
            btnStart.isEnabled = false
        } else {
            hint.visibility = View.GONE
            btnStart.isEnabled = true
        }
        refreshPreview()
    }

    private fun currentCount() = counts[seek.progress.coerceIn(0, counts.size - 1)]

    /** Atualiza seleção de formato, texto e a prévia com os contornos das peças. */
    private fun refreshPreview() {
        icons[0].chosen = style == JigsawGeometry.STYLE_REGULAR
        icons[1].chosen = style == JigsawGeometry.STYLE_IRREGULAR
        icons[2].chosen = style == JigsawGeometry.STYLE_WILD

        val bmp = previewBitmap
        if (bmp == null) {
            preview.setPuzzle(null, 0, 0, style, seed)
            label.text = getString(R.string.pieces_plain, currentCount())
            return
        }
        // a grade usa as dimensões da imagem original, como o jogo
        val size = ImageStore.pendingSize(this) ?: (bmp.width to bmp.height)
        val (rows, cols) = JigsawGeometry.grid(currentCount(), size.first, size.second)
        preview.setPuzzle(bmp, rows, cols, style, seed)
        label.text = getString(R.string.pieces_fmt, rows * cols, cols, rows)
    }

    private fun onStartClicked() = launchNewGame()

    private fun launchNewGame() {
        val id = ImageStore.startGameFromPending(
            this, currentCount(), style, seed, switchRotate.isChecked
        ) ?: return
        startActivity(
            Intent(this, PuzzleActivity::class.java)
                .putExtra(PuzzleActivity.EXTRA_ID, id)
                .putExtra(PuzzleActivity.EXTRA_COUNT, currentCount())
                .putExtra(PuzzleActivity.EXTRA_STYLE, style)
                .putExtra(PuzzleActivity.EXTRA_SEED, seed)
                .putExtra(PuzzleActivity.EXTRA_ROTATION, switchRotate.isChecked)
                .putExtra(PuzzleActivity.EXTRA_TIMED, switchTimed.isChecked)
        )
        seed = System.nanoTime()
        refreshPreview()
    }
}
