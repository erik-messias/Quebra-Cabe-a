package com.example.quebracabeca

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {

    private val counts = intArrayOf(6, 12, 24, 48, 70, 100, 150, 200, 300, 500)

    private lateinit var preview: PuzzlePreviewView
    private lateinit var hint: TextView
    private lateinit var label: TextView
    private lateinit var seek: SeekBar
    private lateinit var btnStart: MaterialButton
    private lateinit var btnResume: MaterialButton
    private lateinit var icons: List<ShapeIconView>

    private var previewBitmap: Bitmap? = null
    private var style = JigsawGeometry.STYLE_IRREGULAR
    private var seed = System.nanoTime()

    private val prefs by lazy { getSharedPreferences("puzzle_prefs", MODE_PRIVATE) }

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) importImage(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val root = findViewById<View>(R.id.root)
        val pad = (16 * resources.displayMetrics.density).toInt()
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(bars.left + pad, bars.top + pad, bars.right + pad, bars.bottom + pad)
            insets
        }

        preview = findViewById(R.id.preview)
        hint = findViewById(R.id.hint)
        label = findViewById(R.id.pieces_label)
        seek = findViewById(R.id.seek)
        btnStart = findViewById(R.id.btn_start)
        btnResume = findViewById(R.id.btn_resume)

        icons = listOf<ShapeIconView>(
            findViewById(R.id.icon_regular),
            findViewById(R.id.icon_irregular),
            findViewById(R.id.icon_wild)
        )
        icons[0].shapeStyle = JigsawGeometry.STYLE_REGULAR
        icons[1].shapeStyle = JigsawGeometry.STYLE_IRREGULAR
        icons[2].shapeStyle = JigsawGeometry.STYLE_WILD
        findViewById<View>(R.id.shape_regular).setOnClickListener { selectStyle(JigsawGeometry.STYLE_REGULAR) }
        findViewById<View>(R.id.shape_irregular).setOnClickListener { selectStyle(JigsawGeometry.STYLE_IRREGULAR) }
        findViewById<View>(R.id.shape_wild).setOnClickListener { selectStyle(JigsawGeometry.STYLE_WILD) }

        // restaura as últimas escolhas
        style = prefs.getInt("style", JigsawGeometry.STYLE_IRREGULAR).coerceIn(0, 2)
        seek.max = counts.size - 1
        seek.progress = prefs.getInt("count_index", 3).coerceIn(0, counts.size - 1)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) = refreshPreview()
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                prefs.edit().putInt("count_index", seek.progress).apply()
            }
        })

        val pick = View.OnClickListener {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        preview.setOnClickListener(pick)
        findViewById<View>(R.id.btn_pick).setOnClickListener(pick)

        btnStart.setOnClickListener { onStartClicked() }
        btnResume.setOnClickListener {
            startActivity(
                Intent(this, PuzzleActivity::class.java).putExtra(PuzzleActivity.EXTRA_RESUME, true)
            )
        }

        showPendingImage()
    }

    override fun onResume() {
        super.onResume()
        btnResume.visibility = if (ImageStore.hasSave(this)) View.VISIBLE else View.GONE
    }

    private fun selectStyle(s: Int) {
        style = s
        prefs.edit().putInt("style", s).apply()
        refreshPreview()
    }

    private fun importImage(uri: Uri) {
        hint.visibility = View.VISIBLE
        hint.setText(R.string.loading)
        Thread {
            val ok = try {
                ImageStore.importPending(this, uri)
            } catch (e: Throwable) {
                false
            }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                if (ok) {
                    seed = System.nanoTime()
                    showPendingImage()
                } else {
                    hint.setText(R.string.tap_to_pick)
                    Toast.makeText(this, R.string.load_error, Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun showPendingImage() {
        previewBitmap = ImageStore.loadPendingPreview(this)
        if (previewBitmap == null) {
            hint.visibility = View.VISIBLE
            hint.setText(R.string.tap_to_pick)
            btnStart.isEnabled = false
        } else {
            hint.visibility = View.GONE
            btnStart.isEnabled = true
        }
        refreshPreview()
    }

    private fun currentCount() = counts[seek.progress.coerceIn(0, counts.size - 1)]

    /** Atualiza seleção de formato, texto e a prévia com os contornos das peças. */
    private fun refreshPreview() {
        icons[0].chosen = style == JigsawGeometry.STYLE_REGULAR
        icons[1].chosen = style == JigsawGeometry.STYLE_IRREGULAR
        icons[2].chosen = style == JigsawGeometry.STYLE_WILD

        val bmp = previewBitmap
        if (bmp == null) {
            preview.setPuzzle(null, 0, 0, style, seed)
            label.text = getString(R.string.pieces_plain, currentCount())
            return
        }
        // a grade usa as dimensões da imagem original, como o jogo
        val size = ImageStore.pendingSize(this) ?: (bmp.width to bmp.height)
        val (rows, cols) = JigsawGeometry.grid(currentCount(), size.first, size.second)
        preview.setPuzzle(bmp, rows, cols, style, seed)
        label.text = getString(R.string.pieces_fmt, rows * cols, cols, rows)
    }

    private fun onStartClicked() {
        if (ImageStore.hasSave(this)) {
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.replace_title)
                .setMessage(R.string.replace_msg)
                .setPositiveButton(R.string.replace_yes) { _, _ -> launchNewGame() }
                .setNegativeButton(R.string.cancel, null)
                .show()
        } else {
            launchNewGame()
        }
    }

    private fun launchNewGame() {
        if (!ImageStore.startGameFromPending(this)) return
        startActivity(
            Intent(this, PuzzleActivity::class.java)
                .putExtra(PuzzleActivity.EXTRA_COUNT, currentCount())
                .putExtra(PuzzleActivity.EXTRA_STYLE, style)
                .putExtra(PuzzleActivity.EXTRA_SEED, seed)
        )
    }
}
