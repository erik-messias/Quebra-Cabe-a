package com.example.quebracabeca

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Mostra a imagem com uma moldura de corte que se arrasta pelos cantos (como no Just Jigsaws). */
class CropView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private var bmp: Bitmap? = null
    private val img = RectF()
    private val crop = RectF()
    private val d = resources.displayMetrics.density
    private val minSize = 56f * d
    private val handleR = 15f * d

    private val dim = Paint().apply { color = Color.argb(150, 0, 0, 0) }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.WHITE; strokeWidth = 2f * d
    }
    private val grid = Paint().apply { color = Color.argb(90, 255, 255, 255); strokeWidth = 1f * d }
    private val handleFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(205, 205, 210) }
    private val handleStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.rgb(40, 40, 50); strokeWidth = 3f * d
    }
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)

    // 0..3 = cantos (TL, TR, BR, BL), 4 = mover, -1 = nada
    private var drag = -1
    private var lx = 0f
    private var ly = 0f

    fun setBitmap(b: Bitmap) {
        bmp = b
        layoutImage()
        invalidate()
    }

    private fun layoutImage() {
        val b = bmp ?: return
        if (width == 0 || height == 0) return
        val m = 28f * d
        val s = min((width - 2 * m) / b.width, (height - 2 * m) / b.height)
        val w = b.width * s
        val h = b.height * s
        img.set((width - w) / 2f, (height - h) / 2f, (width + w) / 2f, (height + h) / 2f)
        crop.set(img)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        layoutImage()
    }

    fun rotate(clockwise: Boolean) = transform(Matrix().apply { postRotate(if (clockwise) 90f else -90f) })

    fun flip(horizontal: Boolean) =
        transform(Matrix().apply { if (horizontal) postScale(-1f, 1f) else postScale(1f, -1f) })

    private fun transform(m: Matrix) {
        val b = bmp ?: return
        bmp = Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
        layoutImage()
        invalidate()
    }

    /** Recorte atual, em pixels da imagem. */
    fun croppedBitmap(): Bitmap? {
        val b = bmp ?: return null
        val sx = b.width / img.width()
        val x = ((crop.left - img.left) * sx).toInt().coerceIn(0, b.width - 1)
        val y = ((crop.top - img.top) * sx).toInt().coerceIn(0, b.height - 1)
        val w = (crop.width() * sx).toInt().coerceIn(1, b.width - x)
        val h = (crop.height() * sx).toInt().coerceIn(1, b.height - y)
        return Bitmap.createBitmap(b, x, y, w, h)
    }

    override fun onDraw(c: Canvas) {
        val b = bmp ?: return
        c.drawBitmap(b, null, img, bmpPaint)
        // escurece o que ficou de fora
        c.drawRect(img.left, img.top, img.right, crop.top, dim)
        c.drawRect(img.left, crop.bottom, img.right, img.bottom, dim)
        c.drawRect(img.left, crop.top, crop.left, crop.bottom, dim)
        c.drawRect(crop.right, crop.top, img.right, crop.bottom, dim)
        c.drawRect(crop, line)
        for (i in 1..2) {
            val x = crop.left + crop.width() * i / 3f
            val y = crop.top + crop.height() * i / 3f
            c.drawLine(x, crop.top, x, crop.bottom, grid)
            c.drawLine(crop.left, y, crop.right, y, grid)
        }
        for ((x, y) in corners()) {
            c.drawCircle(x, y, handleR, handleFill)
            c.drawCircle(x, y, handleR, handleStroke)
        }
    }

    private fun corners() = listOf(
        crop.left to crop.top, crop.right to crop.top, crop.right to crop.bottom, crop.left to crop.bottom
    )

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                drag = -1
                var best = handleR * 2.6f
                for ((i, c) in corners().withIndex()) {
                    val dist = hypot(e.x - c.first, e.y - c.second)
                    if (dist < best) { best = dist; drag = i }
                }
                if (drag < 0 && crop.contains(e.x, e.y)) drag = 4
                lx = e.x; ly = e.y
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - lx
                val dy = e.y - ly
                lx = e.x; ly = e.y
                when (drag) {
                    0 -> { crop.left = (crop.left + dx).coerceIn(img.left, crop.right - minSize); crop.top = (crop.top + dy).coerceIn(img.top, crop.bottom - minSize) }
                    1 -> { crop.right = (crop.right + dx).coerceIn(crop.left + minSize, img.right); crop.top = (crop.top + dy).coerceIn(img.top, crop.bottom - minSize) }
                    2 -> { crop.right = (crop.right + dx).coerceIn(crop.left + minSize, img.right); crop.bottom = (crop.bottom + dy).coerceIn(crop.top + minSize, img.bottom) }
                    3 -> { crop.left = (crop.left + dx).coerceIn(img.left, crop.right - minSize); crop.bottom = (crop.bottom + dy).coerceIn(crop.top + minSize, img.bottom) }
                    4 -> {
                        val w = crop.width(); val h = crop.height()
                        val nl = (crop.left + dx).coerceIn(img.left, img.right - w)
                        val nt = (crop.top + dy).coerceIn(img.top, img.bottom - h)
                        crop.set(nl, nt, nl + w, nt + h)
                    }
                }
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> drag = -1
        }
        return true
    }
}
