package com.example.quebracabeca

import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import android.media.AudioAttributes
import android.media.SoundPool
import android.view.ViewGroup
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.progressindicator.LinearProgressIndicator
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

class PuzzleActivity : AppCompatActivity(), PuzzleView.Listener {

    companion object {
        const val EXTRA_COUNT = "count"
        const val EXTRA_RESUME = "resume"
        const val EXTRA_STYLE = "style"
        const val EXTRA_SEED = "seed"
        const val EXTRA_ROTATION = "rotation"
        const val EXTRA_ID = "id"
        const val EXTRA_TIMED = "timed"

        private val TABLE_COLORS = intArrayOf(
            0xFF353B45.toInt(), // grafite (padrão)
            0xFF1F2A44.toInt(), // azul-marinho
            0xFF2E4A3A.toInt(), // verde
            0xFF5A3E2B.toInt(), // marrom
            0xFF6B2D3C.toInt(), // vinho
            0xFF000000.toInt(), // preto
            0xFF8A6E4B.toInt(), // madeira clara
            0xFF7A7F87.toInt(), // cinza
            0xFFC9B79C.toInt(), // bege
            0xFFE9E4D8.toInt()  // claro
        )
    }

    private lateinit var puzzle: PuzzleView
    private lateinit var drawer: DrawerLayout
    private lateinit var info: TextView
    private lateinit var hudGroup: List<View>
    private var coinText: TextView? = null
    private var sounds: SoundPool? = null
    private var sSnap = 0
    private var sLock = 0
    private var soundOn = true
    private var gBmp: Bitmap? = null
    private var gCount = 48
    private var gStyle = 1
    private var gSeed = 0L
    private var gRotation = false
    private lateinit var progress: LinearProgressIndicator
    private lateinit var showHudButton: View

    private val prefs by lazy { getSharedPreferences("puzzle_prefs", MODE_PRIVATE) }

    private val handler = Handler(Looper.getMainLooper())
    private var baseElapsed = 0L
    private var resumedAt = 0L
    private var running = false
    private var ready = false
    private var finished = false
    private var percent = 0
    private var total = 0
    private var hudHidden = false
    private var timed = false
    private var timeUpShown = false
    private var lastReward = 0
    private var limitMs = 0L

    private val hudBackCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() = setHud(true)
    }

    private val drawerBackCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() = drawer.closeDrawer(GravityCompat.START)
    }

    private val tick = object : Runnable {
        override fun run() {
            updateTitle()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_puzzle)
        onBackPressedDispatcher.addCallback(this, hudBackCallback)
        onBackPressedDispatcher.addCallback(this, drawerBackCallback)

        // orientação preferida (jogar na horizontal)
        applyOrientation(prefs.getBoolean("landscape", false))

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        progress = findViewById(R.id.progress)
        puzzle = findViewById(R.id.puzzle)
        info = findViewById(R.id.info)
        drawer = findViewById(R.id.drawer)
        hudGroup = listOf(findViewById(R.id.hud_buttons), info, progress)
        showHudButton = findViewById(R.id.btn_show_hud)
        puzzle.listener = this
        applyTable()
        puzzle.ghostAlpha = prefs.getInt("ghost_pct", 18) * 255 / 100
        applySettings()

        showHudButton.setOnClickListener { setHud(true) }
        findViewById<View>(R.id.btn_menu).setOnClickListener { drawer.openDrawer(GravityCompat.START) }
        findViewById<View>(R.id.btn_arrange).setOnClickListener { puzzle.arrangeAround() }
        findViewById<View>(R.id.btn_hint).setOnClickListener { useHint() }
        drawer.addDrawerListener(object : DrawerLayout.SimpleDrawerListener() {
            override fun onDrawerOpened(v: View) {
                drawerBackCallback.isEnabled = true
                coinText?.text = getString(R.string.coins_fmt, Wallet.coins(this@PuzzleActivity))
            }
            override fun onDrawerClosed(v: View) { drawerBackCallback.isEnabled = false }
        })
        buildDrawer()

        sounds = SoundPool.Builder().setMaxStreams(3).setAudioAttributes(
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        ).build()
        sSnap = sounds!!.load(this, R.raw.snap, 1)
        sLock = sounds!!.load(this, R.raw.lock, 1)
        puzzle.onSnap = { locked ->
            if (soundOn) sounds?.play(if (locked) sLock else sSnap, 1f, 1f, 1, 0, 1f)
        }
        updateTitle()

        intent.getStringExtra(EXTRA_ID)?.let { ImageStore.currentId = it }
        val resume = intent.getBooleanExtra(EXTRA_RESUME, false)
        val count = intent.getIntExtra(EXTRA_COUNT, 48)
        val style = intent.getIntExtra(EXTRA_STYLE, JigsawGeometry.STYLE_IRREGULAR)
        val seed = intent.getLongExtra(EXTRA_SEED, System.nanoTime())
        val rotation = intent.getBooleanExtra(EXTRA_ROTATION, false)
        timed = intent.getBooleanExtra(EXTRA_TIMED, false)
        limitMs = maxOf(90_000L, count * 6_000L)
        Thread {
            val bmp: Bitmap? = ImageStore.loadGame(this)
            val saved = if (resume) ImageStore.readSave(this) else null
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                if (bmp == null) {
                    finish()
                } else {
                    gBmp = bmp; gCount = count; gStyle = style; gSeed = seed; gRotation = rotation
                    baseElapsed = saved?.optLong("elapsed", 0L) ?: 0L
                    if (saved != null) timed = saved.optBoolean("timed", timed)
                    puzzle.start(bmp, count, saved, style, seed, rotation)
                }
            }
        }.start()
    }

    // ---------------------------------------------------------------- orientação / barra (HUD)

    private fun applyOrientation(landscape: Boolean) {
        requestedOrientation = if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    /** Mostra/esconde os botões e a barra de progresso, para usar a tela toda. */
    private fun setHud(visible: Boolean) {
        hudHidden = !visible
        hudBackCallback.isEnabled = hudHidden
        for (v in hudGroup) v.visibility = if (visible) View.VISIBLE else View.GONE
        showHudButton.visibility = if (visible) View.GONE else View.VISIBLE
        applyFullscreen()
    }

    private fun applySettings() {
        puzzle.lockPieces = prefs.getBoolean("lock_pieces", true)
        puzzle.oneFinger = prefs.getBoolean("one_finger", true)
        puzzle.vibration = prefs.getBoolean("vibration", true)
        puzzle.arrangeOnLoad = prefs.getBoolean("arrange_edge", true)
        soundOn = prefs.getBoolean("sound", true)
        puzzle.lightMode = prefs.getInt("light_mode", 0)
        applyFullscreen()
    }

    private fun applyFullscreen() {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        if (hudHidden || prefs.getBoolean("fullscreen", false)) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    // ---------------------------------------------------------------- menu lateral

    private fun addRow(list: LinearLayout, icon: Int, title: Int, onClick: () -> Unit): View {
        val v = layoutInflater.inflate(R.layout.item_drawer_row, list, false)
        v.findViewById<ImageView>(R.id.row_icon).setImageResource(icon)
        v.findViewById<TextView>(R.id.row_title).setText(title)
        v.setOnClickListener { onClick() }
        list.addView(v)
        return v
    }

    private fun addSwitch(list: LinearLayout, icon: Int, title: Int, checked: Boolean, onChange: (Boolean) -> Unit) {
        val v = layoutInflater.inflate(R.layout.item_drawer_row, list, false)
        v.findViewById<ImageView>(R.id.row_icon).setImageResource(icon)
        v.findViewById<TextView>(R.id.row_title).setText(title)
        val sw = v.findViewById<MaterialSwitch>(R.id.row_switch)
        sw.visibility = View.VISIBLE
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, on -> onChange(on) }
        v.setOnClickListener { sw.toggle() }
        list.addView(v)
    }

    private fun addDivider(list: LinearLayout) {
        val d = resources.displayMetrics.density
        list.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1).apply {
                setMargins((20 * d).toInt(), (8 * d).toInt(), (20 * d).toInt(), (8 * d).toInt())
            }
            setBackgroundColor(0x33808080)
        })
    }

    private fun buildDrawer() {
        val list = findViewById<LinearLayout>(R.id.drawer_list)
        val coin = addRow(list, R.drawable.ic_coin, R.string.coins_fmt) {}
        coin.findViewById<ImageView>(R.id.row_icon).clearColorFilter()
        coinText = coin.findViewById(R.id.row_title)
        coinText?.text = getString(R.string.coins_fmt, Wallet.coins(this))
        addDivider(list)
        addRow(list, R.drawable.ic_back, R.string.drawer_back) { finish() }
        addRow(list, R.drawable.ic_save, R.string.drawer_save) {
            persist()
            drawer.closeDrawer(GravityCompat.START)
            Toast.makeText(this, R.string.drawer_saved, Toast.LENGTH_SHORT).show()
        }
        addRow(list, R.drawable.ic_arrange, R.string.drawer_arrange) {
            puzzle.arrangeAround(); drawer.closeDrawer(GravityCompat.START)
        }
        addRow(list, R.drawable.ic_image, R.string.drawer_preview) {
            drawer.closeDrawer(GravityCompat.START); showPreview()
        }
        addRow(list, R.drawable.ic_hint, R.string.drawer_hint) {
            drawer.closeDrawer(GravityCompat.START); useHint()
        }
        addRow(list, R.drawable.ic_stats, R.string.drawer_stats) {
            drawer.closeDrawer(GravityCompat.START); showStats()
        }
        addDivider(list)
        addSwitch(list, R.drawable.ic_arrange, R.string.drawer_edges, false) { puzzle.edgesOnly = it }
        addSwitch(list, R.drawable.ic_image, R.string.drawer_ghost, true) { puzzle.showGhost = it }
        addSwitch(list, R.drawable.ic_stats, R.string.drawer_time, prefs.getBoolean("show_time", true)) {
            prefs.edit().putBoolean("show_time", it).apply(); updateTitle()
        }
        addSwitch(list, R.drawable.ic_fullscreen, R.string.drawer_landscape, prefs.getBoolean("landscape", false)) {
            prefs.edit().putBoolean("landscape", it).apply(); applyOrientation(it)
        }
        addDivider(list)
        addRow(list, R.drawable.ic_gallery, R.string.drawer_appearance) {
            drawer.closeDrawer(GravityCompat.START); showAppearance()
        }
        addRow(list, R.drawable.ic_gallery, R.string.drawer_arrange_table) {
            drawer.closeDrawer(GravityCompat.START); setDecoEdit(true)
        }
        addRow(list, R.drawable.ic_gallery, R.string.drawer_ambience) {
            drawer.closeDrawer(GravityCompat.START); showAmbience()
        }
        addRow(list, R.drawable.ic_fullscreen_exit, R.string.drawer_hide) {
            drawer.closeDrawer(GravityCompat.START); setHud(false)
        }
        addRow(list, R.drawable.ic_reset, R.string.drawer_reset) {
            drawer.closeDrawer(GravityCompat.START)
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.drawer_reset)
                .setMessage(R.string.drawer_reset_msg)
                .setPositiveButton(R.string.drawer_reset) { _, _ -> resetPuzzle() }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }
        addDivider(list)
        addRow(list, R.drawable.ic_settings, R.string.drawer_settings) {
            drawer.closeDrawer(GravityCompat.START)
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun useHint() {
        when {
            Wallet.coins(this) < ShopCatalog.HINT_COST ->
                Toast.makeText(this, getString(R.string.hint_no_coins, ShopCatalog.HINT_COST), Toast.LENGTH_LONG).show()
            puzzle.showHint() -> Wallet.spend(this, ShopCatalog.HINT_COST)
            else -> Toast.makeText(this, R.string.hint_none, Toast.LENGTH_SHORT).show()
        }
    }

    private fun resetPuzzle() {
        val bmp = gBmp ?: return
        stopTimer()
        baseElapsed = 0L
        finished = false
        timeUpShown = false
        ready = false
        ImageStore.clearSave(this)
        ImageStore.clearRec(this)
        puzzle.start(bmp, gCount, null, gStyle, gSeed, gRotation)
    }

    /** Grava a posição atual das peças no aparelho. */
    private fun persist() {
        if (!ready || finished) return
        puzzle.flushRecording()
        puzzle.saveState()?.let {
            it.put("elapsed", elapsed())
            it.put("timed", timed)
            ImageStore.writeSave(this, it)
            ImageStore.updateProgress(this, percent, elapsed())
        }
    }

    // ---------------------------------------------------------------- aparência

    private fun showAppearance() {
        val dp = resources.displayMetrics.density
        val pad = (20 * dp).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
        }

        box.addView(TextView(this).apply {
            setText(R.string.appearance_table)
            setPadding(0, 0, 0, pad / 2)
        })

        val swatches = ArrayList<View>()
        fun refreshSwatches() {
            for ((i, v) in swatches.withIndex()) {
                val d = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(TABLE_COLORS[i])
                    val chosen = TABLE_COLORS[i] == puzzle.tableColor
                    setStroke(
                        ((if (chosen) 3 else 1) * dp).toInt(),
                        if (chosen) 0xFFFFC107.toInt() else 0x66808080
                    )
                }
                v.background = d
            }
        }
        val sizePx = (40 * dp).toInt()
        val gap = (6 * dp).toInt()
        for (rowStart in 0 until TABLE_COLORS.size step 5) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (i in rowStart until minOf(rowStart + 5, TABLE_COLORS.size)) {
                val v = View(this)
                v.layoutParams = LinearLayout.LayoutParams(sizePx, sizePx).apply {
                    setMargins(gap, gap, gap, gap)
                }
                v.setOnClickListener {
                    puzzle.tableColor = TABLE_COLORS[i]
                    prefs.edit().putInt("table_color", TABLE_COLORS[i]).apply()
                    refreshSwatches()
                }
                swatches.add(v)
                row.addView(v)
            }
            box.addView(row)
        }
        refreshSwatches()

        val pct = prefs.getInt("ghost_pct", 18)
        val label = TextView(this).apply {
            text = getString(R.string.appearance_opacity, pct)
            setPadding(0, pad / 2, 0, 0)
        }
        val seek = SeekBar(this).apply {
            max = 100
            progress = pct
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    label.text = getString(R.string.appearance_opacity, p)
                    puzzle.ghostAlpha = p * 255 / 100
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {
                    prefs.edit().putInt("ghost_pct", sb?.progress ?: pct).apply()
                }
            })
        }
        box.addView(label)
        box.addView(seek)

        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.appearance_title)
            .setView(box)
            .setPositiveButton(R.string.close, null)
            .show()
    }

    // ---------------------------------------------------------------- ciclo de vida / timer

    // ---------------------------------------------------------------- ambiente (luz + som)

    private var ambient: android.media.MediaPlayer? = null
    private var ambientKind = 0

    private fun ambientRes(k: Int) = when (k) {
        1 -> R.raw.amb_rain
        2 -> R.raw.amb_wind
        3 -> R.raw.amb_fire
        4 -> R.raw.amb_clock
        5 -> R.raw.amb_birds
        else -> 0
    }

    private fun updateAmbient() {
        val k = prefs.getInt("ambient", 0)
        val vol = prefs.getInt("ambient_vol", 50) / 100f
        if (k != ambientKind) {
            ambient?.release(); ambient = null; ambientKind = k
        }
        if (k == 0) return
        if (ambient == null) {
            ambient = try {
                android.media.MediaPlayer.create(this, ambientRes(k))?.apply { isLooping = true }
            } catch (e: Exception) { null }
        }
        ambient?.setVolume(vol, vol)
        if (ambient?.isPlaying == false) ambient?.start()
    }

    private var decoDone: android.widget.Button? = null

    private fun setDecoEdit(on: Boolean) {
        puzzle.decoEdit = on
        if (on) {
            if (decoDone == null) {
                val b = android.widget.Button(this).apply {
                    text = getString(R.string.arrange_table_done)
                    setOnClickListener { setDecoEdit(false) }
                }
                val lp = android.widget.FrameLayout.LayoutParams(
                    android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                    android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                    android.view.Gravity.BOTTOM or android.view.Gravity.CENTER_HORIZONTAL
                ).apply { bottomMargin = (32 * resources.displayMetrics.density).toInt() }
                findViewById<android.widget.FrameLayout>(R.id.root).addView(b, lp)
                decoDone = b
            }
            decoDone?.visibility = android.view.View.VISIBLE
            android.widget.Toast.makeText(this, R.string.arrange_table_hint, android.widget.Toast.LENGTH_LONG).show()
        } else decoDone?.visibility = android.view.View.GONE
    }

    private fun showAmbience() {
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad / 2, pad, 0) }
        fun label(t: String) = TextView(this).apply { text = t; setPadding(0, pad / 2, 0, 0) }
        val lights = arrayOf("Automática (hora do dia)", "Manhã", "Tarde", "Noite", "Desligada")
        val sounds = arrayOf("Desligado", "Chuva", "Vento", "Lareira", "Tic-tac", "Pássaros")
        val sLight = Spinner(this).apply {
            adapter = ArrayAdapter(this@PuzzleActivity, android.R.layout.simple_spinner_dropdown_item, lights)
            setSelection(prefs.getInt("light_mode", 0))
        }
        val sSound = Spinner(this).apply {
            adapter = ArrayAdapter(this@PuzzleActivity, android.R.layout.simple_spinner_dropdown_item, sounds)
            setSelection(prefs.getInt("ambient", 0))
        }
        val seek = SeekBar(this).apply { max = 100; progress = prefs.getInt("ambient_vol", 50) }
        box.addView(label("Luz da mesa")); box.addView(sLight)
        box.addView(label("Som de ambiente")); box.addView(sSound)
        box.addView(label("Volume do ambiente")); box.addView(seek)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.drawer_ambience)
            .setView(box)
            .setPositiveButton(R.string.close) { _, _ ->
                prefs.edit().putInt("light_mode", sLight.selectedItemPosition)
                    .putInt("ambient", sSound.selectedItemPosition)
                    .putInt("ambient_vol", seek.progress).apply()
                applySettings(); updateAmbient()
            }
            .show()
    }

    override fun onResume() {
        super.onResume()
        applySettings()
        updateAmbient()
        if (ready && !finished) startTimer()
    }

    override fun onPause() {
        super.onPause()
        ambient?.pause()
        stopTimer()
        persist()
    }

    private fun startTimer() {
        if (running) return
        running = true
        resumedAt = SystemClock.elapsedRealtime()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    private fun stopTimer() {
        if (running) {
            baseElapsed += SystemClock.elapsedRealtime() - resumedAt
            running = false
        }
        handler.removeCallbacks(tick)
    }

    private fun elapsed(): Long =
        baseElapsed + if (running) SystemClock.elapsedRealtime() - resumedAt else 0L

    private fun formatTime(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec)
        else String.format("%02d:%02d", m, sec)
    }

    /** Aplica a mesa e as decorações escolhidas na loja. */
    private fun applyTable() {
        val t = ShopCatalog.byId(Wallet.equippedTable(this))
        if (t != null && t.id != ShopCatalog.DEFAULT_TABLE && Wallet.isOwned(this, t)) {
            puzzle.tableColor = t.color
            puzzle.tablePattern = t.pattern
        } else {
            puzzle.tableColor = prefs.getInt("table_color", TABLE_COLORS[0])
            puzzle.tablePattern = 0
        }
        val equipped = Wallet.equippedDecos(this)
        val petItem = ShopCatalog.byId(ShopCatalog.PET_CAT)
        puzzle.walkerGif = if (ShopCatalog.PET_CAT in equipped)
            java.io.File(filesDir, "pet.gif").takeIf { it.exists() } else null
        puzzle.walker = if (ShopCatalog.PET_CAT in equipped && petItem != null &&
            Wallet.isOwned(this, petItem)) petItem.icon else 0
        puzzle.decorations = equipped.filter { it != ShopCatalog.PET_CAT }
            .mapNotNull { id -> ShopCatalog.byId(id)?.takeIf { Wallet.isOwned(this, it) }?.let { PuzzleView.DecoItem(it.id, it.icon) } }
        puzzle.loadDecoPos(prefs.getString("deco_pos", "") ?: "")
        puzzle.onDecoSaved = { prefs.edit().putString("deco_pos", puzzle.decoPosString()).apply() }
    }

    private fun showStats() {
        val st = puzzle.stats()
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.stats_title)
            .setMessage(
                getString(
                    R.string.stats_body, st.placed, st.total, st.total - st.placed,
                    st.snaps, st.moves, st.hints, formatTime(elapsed())
                )
            )
            .setPositiveButton(R.string.close, null)
            .show()
    }

    private fun timeUp() {
        timeUpShown = true
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.timeup_title)
            .setMessage(getString(R.string.timeup_msg, percent))
            .setCancelable(false)
            .setPositiveButton(R.string.timeup_continue) { _, _ -> timed = false; updateTitle() }
            .setNegativeButton(R.string.timeup_exit) { _, _ -> finish() }
            .show()
    }

    private fun updateTitle() {
        val show = prefs.getBoolean("show_time", true)
        val t = when {
            timed && !finished -> getString(R.string.timed_left, formatTime((limitMs - elapsed()).coerceAtLeast(0L)))
            show -> formatTime(elapsed())
            else -> ""
        }
        val sub = if (total > 0) getString(R.string.subtitle_fmt, percent, total) else ""
        info.text = listOf(t, sub).filter { it.isNotEmpty() }.joinToString("  ·  ")
        info.visibility = if (info.text.isEmpty() || hudHidden) View.GONE else View.VISIBLE
        if (timed && !finished && !timeUpShown && ready && elapsed() >= limitMs) timeUp()
    }

    // ---------------------------------------------------------------- PuzzleView.Listener

    override fun onReady() {
        ready = true
        if (!finished) startTimer()
        val hint = if (puzzle.isRotationMode) R.string.hint_rotate else R.string.hint_edge
        Toast.makeText(this, hint, Toast.LENGTH_LONG).show()
    }

    override fun onProgress(percent: Int, total: Int) {
        this.percent = percent
        this.total = total
        progress.setProgressCompat(percent, true)
        updateTitle()
    }

    override fun onCompleted() {
        finished = true
        val time = formatTime(elapsed())
        stopTimer()
        updateTitle()
        progress.setProgressCompat(100, true)
        ImageStore.markCompleted(this, elapsed())
        val st0 = puzzle.stats()
        var reward = maxOf(5, total / 5)
        if (st0.hints == 0) reward += reward / 2
        if (timed) reward += reward / 2
        Wallet.add(this, reward)
        lastReward = reward
        if (hudHidden) setHud(true)
        generateVideo(time)
    }

    // ---------------------------------------------------------------- vídeo da montagem

    private fun generateVideo(time: String) {
        val assets = puzzle.replayAssets()
        if (assets == null) {
            showDoneDialog(time, null)
            return
        }

        val pad = (20 * resources.displayMetrics.density).toInt()
        val bar = LinearProgressIndicator(this).apply { max = 100; isIndeterminate = false }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, 0)
            addView(TextView(context).apply {
                text = getString(R.string.video_generating)
                setPadding(0, 0, 0, pad / 2)
            })
            addView(bar)
        }
        val cancelled = AtomicBoolean(false)
        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.done_title)
            .setView(box)
            .setCancelable(false)
            .setNegativeButton(R.string.video_skip) { _, _ -> cancelled.set(true) }
            .create()
        dialog.show()

        val appCtx = applicationContext
        val vid = ImageStore.currentId
        Thread {
            var saved = false
            try {
                val events = ReplayRecorder.readAll(ImageStore.recFile(appCtx))
                val tmp = File(appCtx.cacheDir, "replay.mp4")
                tmp.delete()
                val dest = vid?.let { ImageStore.videoFile(appCtx, it) }
                val ok = ReplayRenderer.render(
                    assets, events, tmp, getString(R.string.video_caption, time),
                    { p -> runOnUiThread { bar.setProgressCompat(p, false) } },
                    { cancelled.get() }
                )
                if (ok && !cancelled.get() && dest != null) {
                    dest.delete()
                    tmp.copyTo(dest, overwrite = true)
                    saved = true
                }
                tmp.delete()
            } catch (t: Throwable) {
                saved = false
            }
            ImageStore.clearRec(appCtx)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                dialog.dismiss()
                showDoneDialog(time, if (saved) vid else null)
            }
        }.start()
    }

    private fun showDoneDialog(time: String, videoId: String?) {
        val st = puzzle.stats()
        val extra = getString(R.string.done_stats, st.snaps, st.moves, st.hints) + "\n" +
            getString(R.string.done_reward, lastReward, Wallet.coins(this))
        val b = MaterialAlertDialogBuilder(this).setTitle(R.string.done_title)
        if (videoId != null) {
            b.setMessage(getString(R.string.done_msg, time) + "\n" + extra + "\n\n" + getString(R.string.video_kept))
                .setPositiveButton(R.string.video_watch) { _, _ ->
                    startActivity(
                        Intent(this, VideoPlayerActivity::class.java)
                            .putExtra(VideoPlayerActivity.EXTRA_ID, videoId)
                    )
                }
                .setNeutralButton(R.string.video_save_gallery) { _, _ ->
                    Thread {
                        val ok = ImageStore.saveVideoToGallery(applicationContext, videoId) != null
                        runOnUiThread {
                            Toast.makeText(
                                this, if (ok) R.string.video_saved else R.string.video_save_error,
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }.start()
                }
                .setNegativeButton(R.string.close, null)
        } else {
            b.setMessage(getString(R.string.done_msg, time) + "\n" + extra)
                .setPositiveButton(R.string.done_new) { _, _ -> finish() }
                .setNegativeButton(R.string.done_view, null)
        }
        b.show()
    }

    private fun openVideo(intent: Intent) {
        try {
            startActivity(intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) {
            Toast.makeText(this, R.string.video_no_app, Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------- prévia

    private fun showPreview() {
        val bmp = puzzle.previewBitmap ?: return
        val pad = (12 * resources.displayMetrics.density).toInt()
        val iv = ImageView(this).apply {
            setImageBitmap(bmp)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(pad, pad, pad, 0)
            visibility = View.VISIBLE
        }
        MaterialAlertDialogBuilder(this)
            .setView(iv)
            .setPositiveButton(R.string.close, null)
            .show()
    }

    override fun onDestroy() {
        ambient?.release()
        ambient = null
        sounds?.release()
        handler.removeCallbacks(tick)
        super.onDestroy()
    }
}
