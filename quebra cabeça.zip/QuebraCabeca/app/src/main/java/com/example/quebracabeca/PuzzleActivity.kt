package com.example.quebracabeca

import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.progressindicator.LinearProgressIndicator
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

class PuzzleActivity : AppCompatActivity(), PuzzleView.Listener {

    companion object {
        const val EXTRA_COUNT = "count"
        const val EXTRA_RESUME = "resume"
        const val EXTRA_STYLE = "style"
        const val EXTRA_SEED = "seed"
        const val EXTRA_ROTATION = "rotation"

        private val TABLE_COLORS = intArrayOf(
            0xFF353B45.toInt(), // grafite (padrão)
            0xFF1F2A44.toInt(), // azul-marinho
            0xFF2E4A3A.toInt(), // verde
            0xFF5A3E2B.toInt(), // marrom
            0xFF6B2D3C.toInt(), // vinho
            0xFF000000.toInt(), // preto
            0xFF8A6E4B.toInt(), // madeira clara
            0xFF7A7F87.toInt(), // cinza
            0xFFC9B79C.toInt(), // bege
            0xFFE9E4D8.toInt()  // claro
        )
    }

    private lateinit var puzzle: PuzzleView
    private lateinit var toolbar: MaterialToolbar
    private lateinit var progress: LinearProgressIndicator
    private lateinit var showHudButton: View

    private val prefs by lazy { getSharedPreferences("puzzle_prefs", MODE_PRIVATE) }

    private val handler = Handler(Looper.getMainLooper())
    private var baseElapsed = 0L
    private var resumedAt = 0L
    private var running = false
    private var ready = false
    private var finished = false
    private var percent = 0
    private var total = 0
    private var hudHidden = false

    private val hudBackCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() = setHud(true)
    }

    private val tick = object : Runnable {
        override fun run() {
            updateTitle()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_puzzle)
        onBackPressedDispatcher.addCallback(this, hudBackCallback)

        // orientação preferida (jogar na horizontal)
        applyOrientation(prefs.getBoolean("landscape", false))

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        toolbar = findViewById(R.id.toolbar)
        progress = findViewById(R.id.progress)
        puzzle = findViewById(R.id.puzzle)
        showHudButton = findViewById(R.id.btn_show_hud)
        puzzle.listener = this
        puzzle.tableColor = prefs.getInt("table_color", TABLE_COLORS[0])
        puzzle.ghostAlpha = prefs.getInt("ghost_pct", 18) * 255 / 100

        showHudButton.setOnClickListener { setHud(true) }

        toolbar.setNavigationIcon(R.drawable.ic_back)
        toolbar.setNavigationContentDescription(R.string.back)
        toolbar.setNavigationOnClickListener { finish() }
        toolbar.inflateMenu(R.menu.puzzle_menu)
        toolbar.menu.findItem(R.id.action_landscape).isChecked = prefs.getBoolean("landscape", false)
        toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_preview -> showPreview()
                R.id.action_ghost -> {
                    item.isChecked = !item.isChecked
                    puzzle.showGhost = item.isChecked
                }
                R.id.action_edges -> {
                    item.isChecked = !item.isChecked
                    puzzle.edgesOnly = item.isChecked
                }
                R.id.action_landscape -> {
                    item.isChecked = !item.isChecked
                    prefs.edit().putBoolean("landscape", item.isChecked).apply()
                    applyOrientation(item.isChecked)
                }
                R.id.action_scatter -> puzzle.arrangeAround()
                R.id.action_fit -> puzzle.fitToView()
                R.id.action_hud -> setHud(false)
                R.id.action_appearance -> showAppearance()
            }
            true
        }
        updateTitle()

        val resume = intent.getBooleanExtra(EXTRA_RESUME, false)
        val count = intent.getIntExtra(EXTRA_COUNT, 48)
        val style = intent.getIntExtra(EXTRA_STYLE, JigsawGeometry.STYLE_IRREGULAR)
        val seed = intent.getLongExtra(EXTRA_SEED, System.nanoTime())
        val rotation = intent.getBooleanExtra(EXTRA_ROTATION, false)
        Thread {
            val bmp: Bitmap? = ImageStore.loadGame(this)
            val saved = if (resume) ImageStore.readSave(this) else null
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                if (bmp == null) {
                    finish()
                } else {
                    baseElapsed = saved?.optLong("elapsed", 0L) ?: 0L
                    puzzle.start(bmp, count, saved, style, seed, rotation)
                }
            }
        }.start()
    }

    // ---------------------------------------------------------------- orientação / barra (HUD)

    private fun applyOrientation(landscape: Boolean) {
        requestedOrientation = if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    /** Mostra/esconde a barra de cima e as barras do sistema, para usar a tela toda. */
    private fun setHud(visible: Boolean) {
        hudHidden = !visible
        hudBackCallback.isEnabled = hudHidden
        toolbar.visibility = if (visible) View.VISIBLE else View.GONE
        progress.visibility = if (visible) View.VISIBLE else View.GONE
        showHudButton.visibility = if (visible) View.GONE else View.VISIBLE
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (visible) {
            controller.show(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    // ---------------------------------------------------------------- aparência

    private fun showAppearance() {
        val dp = resources.displayMetrics.density
        val pad = (20 * dp).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
        }

        box.addView(TextView(this).apply {
            setText(R.string.appearance_table)
            setPadding(0, 0, 0, pad / 2)
        })

        val swatches = ArrayList<View>()
        fun refreshSwatches() {
            for ((i, v) in swatches.withIndex()) {
                val d = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(TABLE_COLORS[i])
                    val chosen = TABLE_COLORS[i] == puzzle.tableColor
                    setStroke(
                        ((if (chosen) 3 else 1) * dp).toInt(),
                        if (chosen) 0xFFFFC107.toInt() else 0x66808080
                    )
                }
                v.background = d
            }
        }
        val sizePx = (40 * dp).toInt()
        val gap = (6 * dp).toInt()
        for (rowStart in 0 until TABLE_COLORS.size step 5) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (i in rowStart until minOf(rowStart + 5, TABLE_COLORS.size)) {
                val v = View(this)
                v.layoutParams = LinearLayout.LayoutParams(sizePx, sizePx).apply {
                    setMargins(gap, gap, gap, gap)
                }
                v.setOnClickListener {
                    puzzle.tableColor = TABLE_COLORS[i]
                    prefs.edit().putInt("table_color", TABLE_COLORS[i]).apply()
                    refreshSwatches()
                }
                swatches.add(v)
                row.addView(v)
            }
            box.addView(row)
        }
        refreshSwatches()

        val pct = prefs.getInt("ghost_pct", 18)
        val label = TextView(this).apply {
            text = getString(R.string.appearance_opacity, pct)
            setPadding(0, pad / 2, 0, 0)
        }
        val seek = SeekBar(this).apply {
            max = 100
            progress = pct
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    label.text = getString(R.string.appearance_opacity, p)
                    puzzle.ghostAlpha = p * 255 / 100
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {
                    prefs.edit().putInt("ghost_pct", sb?.progress ?: pct).apply()
                }
            })
        }
        box.addView(label)
        box.addView(seek)

        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.appearance_title)
            .setView(box)
            .setPositiveButton(R.string.close, null)
            .show()
    }

    // ---------------------------------------------------------------- ciclo de vida / timer

    override fun onResume() {
        super.onResume()
        if (ready && !finished) startTimer()
    }

    override fun onPause() {
        super.onPause()
        stopTimer()
        if (ready && !finished) {
            puzzle.flushRecording()
            puzzle.saveState()?.let {
                it.put("elapsed", baseElapsed)
                ImageStore.writeSave(this, it)
            }
        }
    }

    private fun startTimer() {
        if (running) return
        running = true
        resumedAt = SystemClock.elapsedRealtime()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    private fun stopTimer() {
        if (running) {
            baseElapsed += SystemClock.elapsedRealtime() - resumedAt
            running = false
        }
        handler.removeCallbacks(tick)
    }

    private fun elapsed(): Long =
        baseElapsed + if (running) SystemClock.elapsedRealtime() - resumedAt else 0L

    private fun formatTime(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec)
        else String.format("%02d:%02d", m, sec)
    }

    private fun updateTitle() {
        toolbar.title = formatTime(elapsed())
        toolbar.subtitle = if (total > 0) getString(R.string.subtitle_fmt, percent, total) else null
    }

    // ---------------------------------------------------------------- PuzzleView.Listener

    override fun onReady() {
        ready = true
        if (!finished) startTimer()
        val hint = if (puzzle.isRotationMode) R.string.hint_rotate else R.string.hint_edge
        Toast.makeText(this, hint, Toast.LENGTH_LONG).show()
    }

    override fun onProgress(percent: Int, total: Int) {
        this.percent = percent
        this.total = total
        progress.setProgressCompat(percent, true)
        updateTitle()
    }

    override fun onCompleted() {
        finished = true
        val time = formatTime(elapsed())
        stopTimer()
        updateTitle()
        progress.setProgressCompat(100, true)
        ImageStore.clearSave(this)
        if (hudHidden) setHud(true)
        generateVideo(time)
    }

    // ---------------------------------------------------------------- vídeo da montagem

    private fun generateVideo(time: String) {
        val assets = puzzle.replayAssets()
        if (assets == null) {
            showDoneDialog(time, null)
            return
        }

        val pad = (20 * resources.displayMetrics.density).toInt()
        val bar = LinearProgressIndicator(this).apply { max = 100; isIndeterminate = false }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, 0)
            addView(TextView(context).apply {
                text = getString(R.string.video_generating)
                setPadding(0, 0, 0, pad / 2)
            })
            addView(bar)
        }
        val cancelled = AtomicBoolean(false)
        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.done_title)
            .setView(box)
            .setCancelable(false)
            .setNegativeButton(R.string.video_skip) { _, _ -> cancelled.set(true) }
            .create()
        dialog.show()

        val appCtx = applicationContext
        Thread {
            var uri: Uri? = null
            try {
                val events = ReplayRecorder.readAll(ImageStore.recFile(appCtx))
                val tmp = File(appCtx.cacheDir, "replay.mp4")
                tmp.delete()
                val ok = ReplayRenderer.render(
                    assets, events, tmp, getString(R.string.video_caption, time),
                    { p -> runOnUiThread { bar.setProgressCompat(p, false) } },
                    { cancelled.get() }
                )
                if (ok && !cancelled.get()) uri = VideoSaver.saveToGallery(appCtx, tmp)
                tmp.delete()
            } catch (t: Throwable) {
                uri = null
            }
            ImageStore.clearRec(appCtx)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                dialog.dismiss()
                showDoneDialog(time, uri)
            }
        }.start()
    }

    private fun showDoneDialog(time: String, video: Uri?) {
        val b = MaterialAlertDialogBuilder(this).setTitle(R.string.done_title)
        if (video != null) {
            b.setMessage(getString(R.string.done_msg, time) + "\n\n" + getString(R.string.video_saved))
                .setPositiveButton(R.string.video_watch) { _, _ ->
                    openVideo(Intent(Intent.ACTION_VIEW).setDataAndType(video, "video/mp4"))
                }
                .setNeutralButton(R.string.video_share) { _, _ ->
                    val send = Intent(Intent.ACTION_SEND)
                        .setType("video/mp4")
                        .putExtra(Intent.EXTRA_STREAM, video)
                    openVideo(Intent.createChooser(send, null))
                }
                .setNegativeButton(R.string.close, null)
        } else {
            b.setMessage(getString(R.string.done_msg, time))
                .setPositiveButton(R.string.done_new) { _, _ -> finish() }
                .setNegativeButton(R.string.done_view, null)
        }
        b.show()
    }

    private fun openVideo(intent: Intent) {
        try {
            startActivity(intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) {
            Toast.makeText(this, R.string.video_no_app, Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------- prévia

    private fun showPreview() {
        val bmp = puzzle.previewBitmap ?: return
        val pad = (12 * resources.displayMetrics.density).toInt()
        val iv = ImageView(this).apply {
            setImageBitmap(bmp)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(pad, pad, pad, 0)
            visibility = View.VISIBLE
        }
        MaterialAlertDialogBuilder(this)
            .setView(iv)
            .setPositiveButton(R.string.close, null)
            .show()
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }
}
