package com.example.quebracabeca

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.File
import java.io.FileOutputStream

/** Editor para desenhar uma decoração própria (fundo transparente). */
class DrawActivity : AppCompatActivity() {

    private lateinit var canvasView: DrawView

    private class DrawView(ctx: Context) : View(ctx) {
        val size = 640
        var bmp: Bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        var cv = Canvas(bmp)
        val undo = ArrayDeque<Bitmap>()
        var color = Color.BLACK
        var brush = 10f
        var eraser = false
        private val pen = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        private val bg = Paint()
        private val dst = RectF()
        private var lx = 0f
        private var ly = 0f
        private var side = 0f
        private var ox = 0f
        private var oy = 0f

        private fun snapshot() {
            undo.addLast(bmp.copy(Bitmap.Config.ARGB_8888, false))
            if (undo.size > 15) undo.removeFirst().recycle()
        }

        fun undoLast() {
            val b = undo.removeLastOrNull() ?: return
            bmp.recycle(); bmp = b.copy(Bitmap.Config.ARGB_8888, true); cv = Canvas(bmp); b.recycle(); invalidate()
        }

        fun clearAll() { snapshot(); bmp.eraseColor(Color.TRANSPARENT); invalidate() }

        private fun toBmp(x: Float, y: Float) = Pair((x - ox) / side * size, (y - oy) / side * size)

        override fun onDraw(c: Canvas) {
            side = minOf(width, height).toFloat(); ox = (width - side) / 2f; oy = (height - side) / 2f
            dst.set(ox, oy, ox + side, oy + side)
            bg.color = Color.WHITE; c.drawRect(dst, bg)
            bg.color = Color.rgb(228, 228, 232)
            val t = side / 20f
            for (i in 0 until 20) for (j in 0 until 20) if ((i + j) % 2 == 0)
                c.drawRect(ox + i * t, oy + j * t, ox + (i + 1) * t, oy + (j + 1) * t, bg)
            c.drawBitmap(bmp, null, dst, null)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val (x, y) = toBmp(e.x, e.y)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    parent?.requestDisallowInterceptTouchEvent(true)
                    snapshot(); lx = x; ly = y; stroke(x, y, x, y)
                }
                MotionEvent.ACTION_MOVE -> { stroke(lx, ly, x, y); lx = x; ly = y }
            }
            invalidate(); return true
        }

        private fun stroke(x0: Float, y0: Float, x1: Float, y1: Float) {
            pen.strokeWidth = brush
            if (eraser) { pen.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) } else { pen.xfermode = null; pen.color = color }
            if (x0 == x1 && y0 == y1) { pen.style = Paint.Style.FILL; cv.drawCircle(x0, y0, brush / 2f, pen); pen.style = Paint.Style.STROKE }
            else cv.drawLine(x0, y0, x1, y1, pen)
        }

        /** Imagem final recortada no desenho (null se estiver em branco). */
        fun result(): Bitmap? {
            val w = bmp.width; val h = bmp.height
            val px = IntArray(w * h); bmp.getPixels(px, 0, w, 0, 0, w, h)
            var l = w; var t = h; var r = -1; var b = -1
            for (y in 0 until h) for (x in 0 until w) if ((px[y * w + x] ushr 24) > 8) {
                if (x < l) l = x; if (x > r) r = x; if (y < t) t = y; if (y > b) b = y
            }
            if (r < 0) return null
            val pad = 8
            l = maxOf(0, l - pad); t = maxOf(0, t - pad); r = minOf(w - 1, r + pad); b = minOf(h - 1, b + pad)
            return Bitmap.createBitmap(bmp, l, t, r - l + 1, b - t + 1)
        }
    }

    private fun dp(v: Int) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(b.left + dp(8), b.top + dp(8), b.right + dp(8), b.bottom + dp(8)); insets
        }
        canvasView = DrawView(this)

        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; setOnClickListener { f() }
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        lateinit var eraserBtn: Button
        top.addView(btn("Desfazer") { canvasView.undoLast() })
        top.addView(btn("Limpar") { canvasView.clearAll() })
        eraserBtn = btn("Borracha") {
            canvasView.eraser = !canvasView.eraser
            eraserBtn.text = if (canvasView.eraser) "Borracha ✓" else "Borracha"
        }
        top.addView(eraserBtn)
        root.addView(top)

        root.addView(canvasView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val cols = intArrayOf(Color.BLACK, Color.WHITE, Color.rgb(120, 120, 120), Color.rgb(200, 40, 40), Color.rgb(240, 130, 40),
            Color.rgb(245, 205, 50), Color.rgb(90, 170, 70), Color.rgb(40, 130, 90), Color.rgb(60, 150, 220), Color.rgb(50, 70, 180),
            Color.rgb(150, 80, 190), Color.rgb(235, 120, 170), Color.rgb(140, 95, 60), Color.rgb(250, 220, 190))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(6), 0, dp(6)) }
        for (c in cols) {
            val v = View(this).apply {
                background = android.graphics.drawable.GradientDrawable().apply { shape = android.graphics.drawable.GradientDrawable.OVAL; setColor(c); setStroke(dp(2), Color.GRAY) }
                setOnClickListener { canvasView.color = c; canvasView.eraser = false; eraserBtn.text = "Borracha" }
            }
            row.addView(v, LinearLayout.LayoutParams(dp(38), dp(38)).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        root.addView(HorizontalScrollView(this).apply { addView(row) })

        val sz = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        sz.addView(TextView(this).apply { text = "Pincel" })
        sz.addView(SeekBar(this).apply {
            max = 60; progress = 10
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { canvasView.brush = maxOf(2, p).toFloat() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(sz)
        root.addView(Button(this).apply { text = "Salvar decoração"; isAllCaps = false; setOnClickListener { save() } })
        setContentView(root)
    }

    private fun save() {
        val bmp = canvasView.result() ?: run { Toast.makeText(this, "Desenhe alguma coisa primeiro.", Toast.LENGTH_SHORT).show(); return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val name = EditText(this).apply { hint = "Nome da decoração"; setSingleLine() }
        val price = EditText(this).apply { hint = "Preço em moedas (ex: 50)"; inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        box.addView(name); box.addView(price)
        AlertDialog.Builder(this).setTitle("Registrar decoração").setView(box)
            .setPositiveButton("Salvar") { _, _ ->
                val n = name.text.toString().trim().ifEmpty { "Minha decoração" }
                val pr = (price.text.toString().toIntOrNull() ?: 0).coerceIn(0, 100000)
                val id = ShopCatalog.addCustom(this, n, pr, bmp)
                Wallet.grantAndEquip(this, id)
                Toast.makeText(this, "Decoração salva e registrada!", Toast.LENGTH_LONG).show()
                finish()
            }
            .setNegativeButton("Cancelar", null).show()
    }
}
