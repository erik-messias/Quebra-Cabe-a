package com.example.quebracabeca

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.appbar.MaterialToolbar

/** Corta, gira e espelha a imagem escolhida antes de criar o quebra-cabeça. */
class CropActivity : AppCompatActivity() {

    private lateinit var crop: CropView

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crop)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        findViewById<MaterialToolbar>(R.id.toolbar).apply {
            setNavigationIcon(R.drawable.ic_back)
            setNavigationOnClickListener { finish() }
        }
        crop = findViewById(R.id.crop)
        findViewById<View>(R.id.btn_left).setOnClickListener { crop.rotate(false) }
        findViewById<View>(R.id.btn_right).setOnClickListener { crop.rotate(true) }
        findViewById<View>(R.id.btn_flip_h).setOnClickListener { crop.flip(true) }
        findViewById<View>(R.id.btn_flip_v).setOnClickListener { crop.flip(false) }
        findViewById<View>(R.id.btn_done).setOnClickListener { save() }

        Thread {
            val bmp = ImageStore.loadPending(this)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                if (bmp == null) finish() else crop.setBitmap(bmp)
            }
        }.start()
    }

    private fun save() {
        val out = crop.croppedBitmap() ?: return
        Thread {
            ImageStore.savePending(this, out)
            runOnUiThread {
                setResult(Activity.RESULT_OK)
                finish()
            }
        }.start()
    }
}
