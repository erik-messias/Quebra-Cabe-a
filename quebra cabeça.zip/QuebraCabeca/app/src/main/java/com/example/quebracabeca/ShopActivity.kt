package com.example.quebracabeca

import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton

/** Loja: gasta as moedas ganhas nos puzzles em mesas e decorações. */
class ShopActivity : AppCompatActivity() {

    private lateinit var toolbar: MaterialToolbar

    private val gifPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) importGif(uri)
    }

    // linhas: String = título de seção, ShopItem = item
    private val rows: List<Any> = listOf<Any>(getSectionTables()) + ShopCatalog.items.filter { it.isTable } +
        listOf<Any>(getSectionDecos()) + ShopCatalog.items.filter { !it.isTable }

    private fun getSectionTables() = "Mesas"
    private fun getSectionDecos() = "Decorações (até ${ShopCatalog.MAX_DECOS} na mesa)"

    private class VH(v: View) : RecyclerView.ViewHolder(v) {
        val header: TextView = v.findViewById(R.id.header)
        val row: View = v.findViewById(R.id.row)
        val icon: ImageView = v.findViewById(R.id.icon)
        val name: TextView = v.findViewById(R.id.name)
        val sub: TextView = v.findViewById(R.id.sub)
        val btn: MaterialButton = v.findViewById(R.id.btn)
    }

    private val adapter = object : RecyclerView.Adapter<VH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_shop, parent, false))

        override fun getItemCount() = rows.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val r = rows[position]
            if (r is String) {
                h.header.visibility = View.VISIBLE
                h.header.text = r
                h.row.visibility = View.GONE
                return
            }
            r as ShopItem
            h.header.visibility = View.GONE
            h.row.visibility = View.VISIBLE
            h.icon.setImageResource(r.icon)
            h.name.text = r.name
            val owned = Wallet.isOwned(this@ShopActivity, r)
            val using = if (r.isTable) Wallet.equippedTable(this@ShopActivity) == r.id
            else r.id in Wallet.equippedDecos(this@ShopActivity)
            h.sub.text = when {
                using -> "Em uso"
                owned -> "Você tem"
                else -> "🪙 ${r.price}"
            }
            h.btn.text = when {
                r.isTable && using -> "Em uso"
                r.isTable && owned -> "Usar"
                !r.isTable && using -> "Tirar"
                !r.isTable && owned -> "Pôr"
                else -> "Comprar"
            }
            h.btn.isEnabled = !(r.isTable && using)
            h.btn.setOnClickListener { act(r, owned) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shop)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        toolbar = findViewById(R.id.toolbar)
        toolbar.setNavigationIcon(R.drawable.ic_back)
        toolbar.setNavigationOnClickListener { finish() }
        toolbar.inflateMenu(R.menu.shop_menu)
        toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_import_gif -> gifPicker.launch("image/gif")
                R.id.action_remove_gif -> {
                    File(filesDir, "pet.gif").delete()
                    Toast.makeText(this, R.string.gif_removed, Toast.LENGTH_SHORT).show()
                }
            }
            true
        }
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@ShopActivity)
            adapter = this@ShopActivity.adapter
        }
        refresh()
    }

    private fun refresh() {
        toolbar.title = "Loja  ·  🪙 ${Wallet.coins(this)}"
        adapter.notifyDataSetChanged()
    }

    private fun importGif(uri: Uri) {
        val dest = File(filesDir, "pet.gif")
        try {
            contentResolver.openInputStream(uri)?.use { inp -> dest.outputStream().use { inp.copyTo(it) } }
            val d = ImageDecoder.decodeDrawable(ImageDecoder.createSource(dest))
            if (d !is AnimatedImageDrawable) throw IllegalStateException("não animado")
        } catch (t: Throwable) {
            dest.delete()
            Toast.makeText(this, R.string.gif_invalid, Toast.LENGTH_LONG).show()
            return
        }
        Wallet.grantAndEquip(this, ShopCatalog.PET_CAT)
        Toast.makeText(this, R.string.gif_ok, Toast.LENGTH_LONG).show()
        refresh()
    }

    private fun act(item: ShopItem, owned: Boolean) {
        if (!owned) {
            if (!Wallet.buy(this, item)) {
                Toast.makeText(this, "Moedas insuficientes. Complete puzzles para ganhar mais!", Toast.LENGTH_SHORT).show()
                return
            }
        }
        if (item.isTable) {
            Wallet.setTable(this, item.id)
        } else if (!Wallet.toggleDeco(this, item.id)) {
            Toast.makeText(this, "A mesa já está cheia de decorações.", Toast.LENGTH_SHORT).show()
        }
        refresh()
    }
}
