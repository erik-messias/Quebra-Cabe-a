package com.example.quebracabeca

import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton

/** Loja: gasta as moedas ganhas nos puzzles em mesas e decorações. */
class ShopActivity : AppCompatActivity() {

    private lateinit var toolbar: MaterialToolbar

    private val gifPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) importGif(uri)
    }

    // linhas: String = título de seção, ShopItem = item
    private object NewDraw
    private class Status(val text: String)
    private var comm: List<Cloud.Deco>? = null
    private var commStatus = "Carregando…"
    private var rows: List<Any> = emptyList()

    private fun buildRows() {
        ShopCatalog.loadCustom(this)
        rows = listOf<Any>(getSectionTables()) + ShopCatalog.items.filter { it.isTable } +
            listOf<Any>(getSectionDecos()) + ShopCatalog.items.filter { !it.isTable } +
            listOf<Any>("Minhas decorações (registro)", NewDraw) + ShopCatalog.customItems +
            listOf<Any>("Comunidade (decorações de outras pessoas)") + (comm?.map { it as Any } ?: listOf<Any>(Status(commStatus)))
    }

    private fun getSectionTables() = "Mesas"
    private fun getSectionDecos() = "Decorações (até ${ShopCatalog.MAX_DECOS} na mesa)"

    private class VH(v: View) : RecyclerView.ViewHolder(v) {
        val header: TextView = v.findViewById(R.id.header)
        val row: View = v.findViewById(R.id.row)
        val icon: ImageView = v.findViewById(R.id.icon)
        val name: TextView = v.findViewById(R.id.name)
        val sub: TextView = v.findViewById(R.id.sub)
        val btn: MaterialButton = v.findViewById(R.id.btn)
    }

    private val adapter = object : RecyclerView.Adapter<VH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_shop, parent, false))

        override fun getItemCount() = rows.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val r = rows[position]
            if (r is String) {
                h.header.visibility = View.VISIBLE
                h.header.text = r
                h.row.visibility = View.GONE
                return
            }
            h.header.visibility = View.GONE
            h.row.visibility = View.VISIBLE
            if (r is Status) {
                h.icon.setImageResource(R.drawable.ic_gallery); h.name.text = r.text; h.sub.text = ""
                h.btn.text = "Atualizar"; h.btn.isEnabled = true; h.btn.setOnClickListener { loadCommunity() }
                h.row.setOnClickListener(null)
                return
            }
            if (r is Cloud.Deco) {
                val bmp = bmpCache.getOrPut(r.id) { Cloud.fromBase64(r.img) }
                if (bmp != null) h.icon.setImageBitmap(bmp) else h.icon.setImageResource(R.drawable.ic_gallery)
                h.name.text = r.name
                val mine = r.authorUid == Cloud.uid(this@ShopActivity)
                val have = ShopCatalog.customItems.any { it.cloudId == r.id }
                h.sub.text = "por ${r.author.ifEmpty { "anônimo" }} · 🪙 ${r.price} · vendas ${r.sales}"
                h.btn.text = if (mine) "Sua" else if (have) "Você tem" else "Comprar"
                h.btn.isEnabled = !mine && !have
                h.row.setOnClickListener(null)
                h.btn.setOnClickListener { buyCommunity(r) }
                return
            }
            if (r === NewDraw) {
                h.row.setOnClickListener(null)
                h.icon.setImageResource(R.drawable.ic_gallery)
                h.name.text = "Desenhar nova decoração"
                h.sub.text = "Crie, dê um preço e registre"
                h.btn.text = "Desenhar"
                h.btn.isEnabled = true
                h.btn.setOnClickListener { startActivity(android.content.Intent(this@ShopActivity, DrawActivity::class.java)) }
                return
            }
            r as ShopItem
            h.row.setOnClickListener(null)
            if (r.file != null) h.icon.setImageBitmap(android.graphics.BitmapFactory.decodeFile(r.file)) else h.icon.setImageResource(r.icon)
            h.name.text = r.name
            val owned = Wallet.isOwned(this@ShopActivity, r)
            val using = if (r.isTable) Wallet.equippedTable(this@ShopActivity) == r.id
            else r.id in Wallet.equippedDecos(this@ShopActivity)
            h.sub.text = when {
                r.file != null && r.author.isNotEmpty() -> "Comprada de ${r.author} · 🪙 ${r.price}"
                r.file != null -> "Sua criação · preço 🪙 ${r.price} · vendas ${r.sales} · " +
                    java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date(r.created))
                using -> "Em uso"
                owned -> "Você tem"
                else -> "🪙 ${r.price}"
            }
            h.btn.text = when {
                r.isTable && using -> "Em uso"
                r.isTable && owned -> "Usar"
                !r.isTable && using -> "Tirar"
                !r.isTable && owned -> "Pôr"
                else -> "Comprar"
            }
            h.btn.isEnabled = !(r.isTable && using)
            h.btn.setOnClickListener { act(r, owned) }
            if (r.file != null && r.author.isEmpty()) {
                if (r.cloudId.isNotEmpty()) h.sub.text = h.sub.text.toString() + " · publicada ✔"
                else { h.sub.text = h.sub.text.toString() + " · toque na linha para publicar"; h.row.setOnClickListener { publish(r) } }
            }
        }
    }

    private val bmpCache = HashMap<String, android.graphics.Bitmap?>()

    private fun loadCommunity() {
        commStatus = "Carregando…"; comm = null; buildRows(); refresh()
        bg {
            val res = try { Cloud.list(this) } catch (e: Throwable) { null }
            val earned = try { Cloud.claimEarnings(this) } catch (e: Throwable) { 0 }
            runOnUiThread {
                comm = res
                if (res == null) commStatus = "Sem conexão com a comunidade. Toque em Atualizar."
                else if (res.isEmpty()) { comm = null; commStatus = "Ainda não há decorações. Publique a primeira!" }
                if (earned > 0) Toast.makeText(this, "Você ganhou 🪙 $earned com vendas!", Toast.LENGTH_LONG).show()
                buildRows(); refresh()
            }
        }
    }

    private fun publish(item: ShopItem) {
        val go = { author: String ->
            Cloud.setCreatorName(this, author)
            Toast.makeText(this, "Publicando…", Toast.LENGTH_SHORT).show()
            bg {
                val bmp = android.graphics.BitmapFactory.decodeFile(item.file)
                val id = try { Cloud.publish(this, item.name, item.price, author, bmp) } catch (e: Throwable) { null }
                runOnUiThread {
                    if (id != null) { ShopCatalog.setCloudId(this, item.id, id); Toast.makeText(this, "Publicada na comunidade!", Toast.LENGTH_LONG).show(); loadCommunity() }
                    else Toast.makeText(this, "Não consegui publicar. Verifique a internet.", Toast.LENGTH_LONG).show()
                }
            }
        }
        val saved = Cloud.creatorName(this)
        if (saved != null) { go(saved); return }
        val et = android.widget.EditText(this).apply { hint = "Seu nome de criador"; setSingleLine() }
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Publicar na comunidade").setView(et)
            .setPositiveButton("Publicar") { _, _ -> go(et.text.toString().trim().ifEmpty { "Anônimo" }) }
            .setNegativeButton(android.R.string.cancel, null).show()
    }

    private fun buyCommunity(d: Cloud.Deco) {
        if (!Wallet.spend(this, d.price)) { Toast.makeText(this, "Moedas insuficientes.", Toast.LENGTH_SHORT).show(); return }
        val bmp = bmpCache.getOrPut(d.id) { Cloud.fromBase64(d.img) }
        if (bmp == null) { Wallet.add(this, d.price); Toast.makeText(this, "Imagem inválida.", Toast.LENGTH_SHORT).show(); return }
        val id = ShopCatalog.addBought(this, d.id, d.name, d.price, d.author, bmp)
        Wallet.grantAndEquip(this, id)
        Toast.makeText(this, "Comprada! Já está na sua mesa.", Toast.LENGTH_SHORT).show()
        refresh()
        bg { try { Cloud.recordSale(this, d) } catch (_: Throwable) {} }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shop)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        toolbar = findViewById(R.id.toolbar)
        toolbar.setNavigationIcon(R.drawable.ic_back)
        toolbar.setNavigationOnClickListener { finish() }
        toolbar.inflateMenu(R.menu.shop_menu)
        toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_import_gif -> gifPicker.launch("image/gif")
                R.id.action_promo -> {
                    val et = android.widget.EditText(this).apply { hint = getString(R.string.promo_hint); setSingleLine() }
                    androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle(R.string.promo_code).setView(et)
                        .setPositiveButton(android.R.string.ok) { _, _ ->
                            val n = Wallet.redeem(this, et.text.toString())
                            Toast.makeText(this, if (n > 0) getString(R.string.promo_ok, n) else getString(R.string.promo_bad), Toast.LENGTH_LONG).show()
                            refresh()
                        }
                        .setNegativeButton(android.R.string.cancel, null).show()
                }
                R.id.action_remove_gif -> {
                    File(filesDir, "pet.gif").delete()
                    Toast.makeText(this, R.string.gif_removed, Toast.LENGTH_SHORT).show()
                }
            }
            true
        }
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@ShopActivity)
            adapter = this@ShopActivity.adapter
        }
        buildRows()
        refresh()
        loadCommunity()
    }

    override fun onResume() {
        super.onResume()
        if (::toolbar.isInitialized) { buildRows(); refresh() }
    }

    private fun refresh() {
        toolbar.title = "Loja  ·  🪙 ${Wallet.coins(this)}"
        adapter.notifyDataSetChanged()
    }

    private fun importGif(uri: Uri) {
        val dest = File(filesDir, "pet.gif")
        try {
            contentResolver.openInputStream(uri)?.use { inp -> dest.outputStream().use { inp.copyTo(it) } }
            val d = ImageDecoder.decodeDrawable(ImageDecoder.createSource(dest))
            if (d !is AnimatedImageDrawable) throw IllegalStateException("não animado")
        } catch (t: Throwable) {
            dest.delete()
            Toast.makeText(this, R.string.gif_invalid, Toast.LENGTH_LONG).show()
            return
        }
        Wallet.grantAndEquip(this, ShopCatalog.PET_CAT)
        Toast.makeText(this, R.string.gif_ok, Toast.LENGTH_LONG).show()
        refresh()
    }

    private fun act(item: ShopItem, owned: Boolean) {
        if (!owned) {
            if (!Wallet.buy(this, item)) {
                Toast.makeText(this, "Moedas insuficientes. Complete puzzles para ganhar mais!", Toast.LENGTH_SHORT).show()
                return
            }
        }
        if (item.isTable) {
            Wallet.setTable(this, item.id)
        } else if (!Wallet.toggleDeco(this, item.id)) {
            Toast.makeText(this, "A mesa já está cheia de decorações.", Toast.LENGTH_SHORT).show()
        }
        refresh()
    }
}
