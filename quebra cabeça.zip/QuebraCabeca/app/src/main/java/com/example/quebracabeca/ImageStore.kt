package com.example.quebracabeca

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import org.json.JSONObject
import java.io.File
import kotlin.math.max

/**
 * Armazenamento interno do app:
 *  - pending.jpg : imagem escolhida na tela inicial (ainda não começou)
 *  - game.jpg    : imagem do puzzle em andamento
 *  - game.json   : progresso salvo do puzzle em andamento
 */
object ImageStore {
    private const val MAX_SIDE = 2048

    private fun pending(ctx: Context) = File(ctx.filesDir, "pending.jpg")
    private fun game(ctx: Context) = File(ctx.filesDir, "game.jpg")
    private fun save(ctx: Context) = File(ctx.filesDir, "game.json")

    fun recFile(ctx: Context) = File(ctx.filesDir, "game.rec")
    fun clearRec(ctx: Context) {
        recFile(ctx).delete()
    }

    fun hasPending(ctx: Context) = pending(ctx).exists()
    fun hasSave(ctx: Context) = save(ctx).exists() && game(ctx).exists()

    /** Lê a imagem da galeria, aplica rotação EXIF, reduz e grava como pending.jpg. */
    fun importPending(ctx: Context, uri: Uri): Boolean {
        val resolver = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false

        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= MAX_SIDE) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val decoded = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return false

        val orientation = try {
            resolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }

        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
        }
        val longest = max(decoded.width, decoded.height)
        if (longest > MAX_SIDE) {
            val s = MAX_SIDE.toFloat() / longest
            m.postScale(s, s)
        }
        val finalBmp = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, m, true)

        pending(ctx).outputStream().use { finalBmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        return true
    }

    fun loadPending(ctx: Context): Bitmap? =
        pending(ctx).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }

    fun pendingSize(ctx: Context): Pair<Int, Int>? {
        val f = pending(ctx)
        if (!f.exists()) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        return if (o.outWidth > 0) o.outWidth to o.outHeight else null
    }

    /** Promove a imagem pendente a imagem do jogo e apaga o progresso antigo. */
    fun startGameFromPending(ctx: Context): Boolean {
        val p = pending(ctx)
        if (!p.exists()) return false
        p.copyTo(game(ctx), overwrite = true)
        save(ctx).delete()
        recFile(ctx).delete()
        return true
    }

    fun loadGame(ctx: Context): Bitmap? =
        game(ctx).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }

    fun readSave(ctx: Context): JSONObject? = try {
        save(ctx).takeIf { it.exists() }?.let { JSONObject(it.readText()) }
    } catch (e: Exception) {
        null
    }

    fun writeSave(ctx: Context, json: JSONObject) {
        try {
            save(ctx).writeText(json.toString())
        } catch (_: Exception) {
        }
    }

    fun clearSave(ctx: Context) {
        save(ctx).delete()
    }
}
