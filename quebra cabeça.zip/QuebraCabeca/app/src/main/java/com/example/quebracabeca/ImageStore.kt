package com.example.quebracabeca

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import org.json.JSONObject
import java.io.File
import kotlin.math.max

/**
 * Armazenamento interno do app:
 *  - pending.jpg : imagem escolhida na tela inicial (ainda não começou)
 *  - game.jpg    : imagem do puzzle em andamento
 *  - game.json   : progresso salvo do puzzle em andamento
 */
object ImageStore {
    private const val MAX_SIDE = 3072

    private fun pending(ctx: Context) = File(ctx.filesDir, "pending.jpg")

    /** Puzzle atual (o que está aberto na tela do jogo). */
    @Volatile var currentId: String? = null

    private fun libDir(ctx: Context) = File(ctx.filesDir, "library").apply { mkdirs() }
    fun entryDir(ctx: Context, id: String) = File(libDir(ctx), id).apply { mkdirs() }
    private fun cur(ctx: Context) = entryDir(ctx, currentId ?: "none")
    private fun game(ctx: Context) = File(cur(ctx), "game.jpg")
    private fun save(ctx: Context) = File(cur(ctx), "game.json")
    fun videoFile(ctx: Context, id: String) = File(entryDir(ctx, id), "video.mp4")
    fun hasVideo(ctx: Context, id: String) = videoFile(ctx, id).exists()
    private fun videoMarker(ctx: Context, id: String) = File(entryDir(ctx, id), "video.saved")

    /** Copia o vídeo guardado no app para a galeria; depois disso ele não expira mais. */
    fun saveVideoToGallery(ctx: Context, id: String): android.net.Uri? {
        val f = videoFile(ctx, id)
        if (!f.exists()) return null
        val uri = VideoSaver.saveToGallery(ctx, f)
        if (uri != null) try { videoMarker(ctx, id).writeText("1") } catch (_: Exception) {}
        return uri
    }

    fun deleteVideo(ctx: Context, id: String) {
        videoFile(ctx, id).delete()
        videoMarker(ctx, id).delete()
    }

    /** Vídeos que o jogador não baixou para a galeria somem sozinhos depois de 7 dias. */
    private fun expireVideos(ctx: Context) {
        val limit = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
        for (d in libDir(ctx).listFiles() ?: emptyArray()) {
            val v = File(d, "video.mp4")
            if (v.exists() && !File(d, "video.saved").exists() && v.lastModified() < limit) v.delete()
        }
    }

    fun thumbFile(ctx: Context, id: String) = File(entryDir(ctx, id), "thumb.jpg")

    fun recFile(ctx: Context) = File(cur(ctx), "game2.rec")
    fun clearRec(ctx: Context) {
        recFile(ctx).delete()
    }

    // ------------------------------------------------------------ biblioteca

    data class Entry(
        val id: String, val count: Int, val style: Int, val seed: Long, val rotation: Boolean,
        val percent: Int, val completed: Boolean, val elapsed: Long, val updated: Long
    )

    private fun readMeta(dir: File): Entry? = try {
        val j = JSONObject(File(dir, "meta.json").readText())
        Entry(
            dir.name, j.optInt("count", 48), j.optInt("style", 1), j.optLong("seed", 0L),
            j.optBoolean("rotation", false), j.optInt("percent", 0), j.optBoolean("completed", false),
            j.optLong("elapsed", 0L), j.optLong("updated", dir.lastModified())
        )
    } catch (e: Exception) {
        null
    }

    private fun writeMeta(dir: File, e: Entry) {
        try {
            val j = JSONObject()
                .put("count", e.count).put("style", e.style).put("seed", e.seed)
                .put("rotation", e.rotation).put("percent", e.percent)
                .put("completed", e.completed).put("elapsed", e.elapsed)
                .put("updated", System.currentTimeMillis())
            File(dir, "meta.json").writeText(j.toString())
        } catch (_: Exception) {
        }
    }

    fun entry(ctx: Context, id: String): Entry? = readMeta(entryDir(ctx, id))

    /** Traz o puzzle salvo da versão antiga (arquivo único) para a biblioteca. */
    private fun migrateLegacy(ctx: Context) {
        val g = File(ctx.filesDir, "game.jpg")
        val j = File(ctx.filesDir, "game.json")
        if (!g.exists()) return
        if (j.exists()) {
            try {
                val o = JSONObject(j.readText())
                val id = System.currentTimeMillis().toString()
                val dir = entryDir(ctx, id)
                g.copyTo(File(dir, "game.jpg"), true)
                j.copyTo(File(dir, "game.json"), true)
                val count = o.optInt("rows", 6) * o.optInt("cols", 8)
                writeMeta(dir, Entry(id, count, o.optInt("style", 1), o.optLong("seed", 0L),
                    o.optBoolean("rotation", false), 0, false, o.optLong("elapsed", 0L), 0L))
                makeThumb(dir)
            } catch (_: Exception) {
            }
        }
        g.delete(); j.delete()
        File(ctx.filesDir, "game2.rec").delete()
    }

    fun list(ctx: Context): List<Entry> {
        migrateLegacy(ctx)
        expireVideos(ctx)
        return (libDir(ctx).listFiles() ?: emptyArray())
            .filter { it.isDirectory && File(it, "game.jpg").exists() }
            .mapNotNull { readMeta(it) }
            .sortedByDescending { it.updated }
    }

    fun count(ctx: Context) = list(ctx).size

    fun delete(ctx: Context, id: String) {
        entryDir(ctx, id).deleteRecursively()
    }

    private fun makeThumb(dir: File) {
        val src = File(dir, "game.jpg")
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(src.path, o)
        if (o.outWidth <= 0) return
        var sample = 1
        while (max(o.outWidth, o.outHeight) / (sample * 2) >= 640) sample *= 2
        val bmp = BitmapFactory.decodeFile(src.path, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return
        File(dir, "thumb.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        bmp.recycle()
    }

    /** Cria uma entrada nova a partir de uma imagem (arquivo) e a torna a atual. */
    private fun createEntry(ctx: Context, image: File, count: Int, style: Int, seed: Long, rotation: Boolean): String {
        val id = System.currentTimeMillis().toString()
        val dir = entryDir(ctx, id)
        image.copyTo(File(dir, "game.jpg"), true)
        writeMeta(dir, Entry(id, count, style, seed, rotation, 0, false, 0L, 0L))
        makeThumb(dir)
        currentId = id
        return id
    }

    /** Cria uma entrada na biblioteca a partir de uma sala (imagem + estado do anfitrião). */
    fun createFromRoom(ctx: Context, jpg: ByteArray, count: Int, style: Int, seed: Long, rotation: Boolean, state: JSONObject): String {
        val tmp = File(ctx.cacheDir, "room.jpg")
        tmp.writeBytes(jpg)
        val id = createEntry(ctx, tmp, count, style, seed, rotation)
        tmp.delete()
        writeSave(ctx, state)
        return id
    }

    /** Começa um jogo novo com a imagem pendente. Devolve o id, ou null se não há imagem. */
    fun startGameFromPending(ctx: Context, count: Int, style: Int, seed: Long, rotation: Boolean): String? {
        val p = pending(ctx)
        if (!p.exists()) return null
        return createEntry(ctx, p, count, style, seed, rotation)
    }

    /** Joga de novo uma imagem da biblioteca (nova entrada, nova seed). */
    fun replayFrom(ctx: Context, id: String, seed: Long): Entry? {
        val old = entry(ctx, id) ?: return null
        val nid = createEntry(ctx, File(entryDir(ctx, id), "game.jpg"), old.count, old.style, seed, old.rotation)
        return entry(ctx, nid)
    }

    fun updateProgress(ctx: Context, percent: Int, elapsed: Long) {
        val id = currentId ?: return
        val dir = entryDir(ctx, id)
        readMeta(dir)?.let { writeMeta(dir, it.copy(percent = percent, elapsed = elapsed)) }
    }

    fun markCompleted(ctx: Context, elapsed: Long) {
        val id = currentId ?: return
        val dir = entryDir(ctx, id)
        readMeta(dir)?.let { writeMeta(dir, it.copy(percent = 100, completed = true, elapsed = elapsed)) }
        save(ctx).delete()
    }

    fun hasPending(ctx: Context) = pending(ctx).exists()

    /** Lê a imagem da galeria, aplica rotação EXIF, reduz e grava como pending.jpg. */
    fun importPending(ctx: Context, uri: Uri): Boolean {
        val resolver = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false

        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= MAX_SIDE) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val decoded = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return false

        val orientation = try {
            resolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }

        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
        }
        val longest = max(decoded.width, decoded.height)
        if (longest > MAX_SIDE) {
            val s = MAX_SIDE.toFloat() / longest
            m.postScale(s, s)
        }
        val finalBmp = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, m, true)

        pending(ctx).outputStream().use { finalBmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        return true
    }

    fun savePending(ctx: Context, bmp: Bitmap) {
        pending(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
    }

    fun loadPending(ctx: Context): Bitmap? =
        pending(ctx).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }

    /** Versão reduzida da imagem pendente, só para a prévia na tela inicial. */
    fun loadPendingPreview(ctx: Context, maxSide: Int = 1024): Bitmap? {
        val f = pending(ctx)
        if (!f.exists()) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        if (o.outWidth <= 0) return null
        var sample = 1
        while (max(o.outWidth, o.outHeight) / (sample * 2) >= maxSide) sample *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    fun pendingSize(ctx: Context): Pair<Int, Int>? {
        val f = pending(ctx)
        if (!f.exists()) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        return if (o.outWidth > 0) o.outWidth to o.outHeight else null
    }

    fun loadGame(ctx: Context): Bitmap? =
        game(ctx).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }

    fun readSave(ctx: Context): JSONObject? = try {
        save(ctx).takeIf { it.exists() }?.let { JSONObject(it.readText()) }
    } catch (e: Exception) {
        null
    }

    fun writeSave(ctx: Context, json: JSONObject) {
        try {
            save(ctx).writeText(json.toString())
        } catch (_: Exception) {
        }
    }

    fun clearSave(ctx: Context) {
        save(ctx).delete()
    }
}
