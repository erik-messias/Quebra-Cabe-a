package com.example.quebracabeca

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewConfiguration
import org.json.JSONArray
import org.json.JSONObject
import java.util.Random
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Rotação de (x,y) por r quartos de volta no sentido horário (eixo y para baixo). */
private fun rotX(x: Float, y: Float, r: Int): Float = when (r and 3) { 0 -> x; 1 -> -y; 2 -> -x; else -> y }
private fun rotY(x: Float, y: Float, r: Int): Float = when (r and 3) { 0 -> y; 1 -> x; 2 -> -y; else -> -x }

/**
 * Mesa do quebra-cabeça: desenha o tabuleiro e as peças, trata arrastar peças/grupos,
 * girar peças (toque), pan e pinça (zoom), encaixe automático e detecção de conclusão.
 *
 * Coordenadas do "mundo" estão em pixels de renderização. A célula de uma peça tem [cell] de lado.
 * A posição (x,y) de uma peça é o canto superior esquerdo da célula; a rotação é feita em torno
 * do centro da célula, então a célula continua ocupando o mesmo quadrado.
 */
class PuzzleView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    interface Listener {
        fun onReady()
        fun onProgress(percent: Int, total: Int)
        fun onCompleted()
    }

    var listener: Listener? = null

    var showGhost = true
        set(value) { field = value; invalidate() }

    var edgesOnly = false
        set(value) { field = value; invalidate() }

    /** Cor da mesa; o tabuleiro e o fundo são tons derivados dela. */
    var tableColor: Int = 0xFF353B45.toInt()
        set(value) { field = value; applyColors(); invalidate() }

    /** Opacidade (0..255) da imagem original mostrada no tabuleiro. */
    var ghostAlpha: Int = 46
        set(value) { field = value.coerceIn(0, 255); ghostPaint.alpha = field; invalidate() }

    val previewBitmap: Bitmap? get() = scaledImage
    val isReady: Boolean get() = pieces.isNotEmpty()
    val isRotationMode: Boolean get() = rotationMode

    // ---------------------------------------------------------------- modelo

    private class Piece(
        val row: Int,
        val col: Int,
        val index: Int,
        val isEdge: Boolean,
        var bmp: Bitmap
    ) {
        var plain = false // sem contorno (peça já encaixada)
        var x = 0f
        var y = 0f
        var rot = 0 // quartos de volta no sentido horário (0..3)
        lateinit var group: Group
    }

    private class Group(var locked: Boolean = false) {
        val pieces = ArrayList<Piece>()
    }

    private class Built(
        val rows: Int,
        val cols: Int,
        val rc: Int,
        val margin: Int,
        val scaled: Bitmap,
        val bitmaps: Array<Bitmap>,
        val geo: JigsawGeometry
    )

    private var builtRef: Built? = null
    private var rows = 0
    private var cols = 0

    /** Peça encaixada: refaz o bitmap sem o contorno escuro. */
    private fun makePlain(p: Piece) {
        val b = builtRef ?: return
        p.plain = true
        val side = b.rc + 2 * b.margin
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = BitmapShader(b.scaled, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        }
        val bmp = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        cv.translate((b.margin - p.col * b.rc).toFloat(), (b.margin - p.row * b.rc).toFloat())
        cv.drawPath(b.geo.pathFor(p.row, p.col), fill)
        p.bmp = bmp
    }
    private var cell = 0f
    private var margin = 0f
    private var seed = 0L
    private var style = JigsawGeometry.STYLE_IRREGULAR
    private var rotationMode = false
    private var ringsTotal = 0
    private var pieces: Array<Piece> = emptyArray()
    private val groups = ArrayList<Group>()
    private var scaledImage: Bitmap? = null
    private var completed = false

    private var boardX = 0f
    private var boardY = 0f
    private var boardW = 0f
    private var boardH = 0f
    private var worldW = 0f
    private var worldH = 0f

    @Volatile
    private var loadToken = 0

    // gravação da montagem (para o vídeo)
    private var recorder: ReplayRecorder? = null
    private var dragAnchor: Piece? = null

    // ---------------------------------------------------------------- câmera

    private var scale = 1f
    private var tx = 0f
    private var ty = 0f
    private var fitScale = 0f
    private var minScale = 0.1f
    private var maxScale = 10f
    private val density = resources.displayMetrics.density

    // ---------------------------------------------------------------- pincéis

    private val bgPaint = Paint().apply { color = 0xFF1E2227.toInt() }
    private val tablePaint = Paint().apply { color = 0xFF353B45.toInt() }
    private val boardPaint = Paint().apply { color = 0xFF262B33.toInt() }
    private val boardStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0x66FFFFFF
    }
    private val ghostPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply { alpha = 46 }
    private val piecePaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val shadowPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
        colorFilter = PorterDuffColorFilter(Color.argb(120, 0, 0, 0), PorterDuff.Mode.SRC_IN)
    }
    private val edgeGlow = Paint().apply { color = 0x88FFC107.toInt() }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 16f * resources.displayMetrics.scaledDensity
    }

    private fun shade(c: Int, f: Float): Int =
        Color.rgb((Color.red(c) * f).toInt(), (Color.green(c) * f).toInt(), (Color.blue(c) * f).toInt())

    private fun applyColors() {
        tablePaint.color = tableColor
        boardPaint.color = shade(tableColor, 0.78f)
        bgPaint.color = shade(tableColor, 0.55f)
    }

    // ---------------------------------------------------------------- entrada pública

    /**
     * Começa um puzzle novo (saved == null) ou restaura um salvo. A geração das peças
     * roda em segundo plano; [Listener.onReady] avisa quando terminar.
     */
    fun start(
        source: Bitmap,
        targetPieces: Int,
        saved: JSONObject?,
        newStyle: Int = JigsawGeometry.STYLE_IRREGULAR,
        newSeed: Long = System.nanoTime(),
        newRotation: Boolean = false
    ) {
        val token = ++loadToken
        recorder?.close()
        recorder = null
        pieces = emptyArray()
        groups.clear()
        completed = false
        invalidate()

        val savedRows = saved?.optInt("rows", 0) ?: 0
        val savedCols = saved?.optInt("cols", 0) ?: 0
        val useSaved = saved != null && savedRows >= 2 && savedCols >= 2
        val grid = if (useSaved) savedRows to savedCols
        else JigsawGeometry.grid(targetPieces, source.width, source.height)
        seed = if (useSaved) saved!!.optLong("seed", 1L) else newSeed
        style = if (useSaved) saved!!.optInt("style", JigsawGeometry.STYLE_IRREGULAR) else newStyle
        rotationMode = if (useSaved) saved!!.optBoolean("rotation", false) else newRotation
        val useSeed = seed
        val useStyle = style

        Thread {
            val built = build(source, grid.first, grid.second, useSeed, useStyle)
            post {
                if (token == loadToken) install(built, if (useSaved) saved else null)
            }
        }.start()
    }

    fun saveState(): JSONObject? {
        if (pieces.isEmpty() || completed) return null
        val root = JSONObject()
        root.put("rows", rows)
        root.put("cols", cols)
        root.put("seed", seed)
        root.put("style", style)
        root.put("rotation", rotationMode)
        val arr = JSONArray()
        for (g in groups) {
            val go = JSONObject()
            go.put("locked", g.locked)
            val ps = JSONArray()
            for (p in g.pieces) {
                val e = JSONArray()
                e.put(p.index)
                e.put(((p.x - boardX) / cell).toDouble())
                e.put(((p.y - boardY) / cell).toDouble())
                e.put(p.rot)
                ps.put(e)
            }
            go.put("p", ps)
            arr.put(go)
        }
        root.put("groups", arr)
        return root
    }

    // ---------------------------------------------------------------- arrumar ao redor

    private fun ringPitch() = cell * 1.4f
    private fun ringOffset(k: Int) = cell * 1.5f + (k - 1) * ringPitch()

    private fun ringSideCounts(k: Int): IntArray {
        val d = ringOffset(k)
        val nx = max(1, floor((boardW + 2 * d) / ringPitch()).toInt())
        val ny = max(1, floor((boardH + 2 * d) / ringPitch()).toInt())
        return intArrayOf(nx, ny)
    }

    private fun ringSlotCount(k: Int): Int {
        val c = ringSideCounts(k)
        return 2 * (c[0] + c[1])
    }

    /** Define o tamanho da mesa: anéis para todas as peças + 2 anéis de folga + borda larga. */
    private fun computeWorld(n: Int) {
        var k = 0
        var cap = 0
        while (cap < n) {
            k++
            cap += ringSlotCount(k)
        }
        ringsTotal = k + 2
        val edge = ringOffset(ringsTotal) + cell * 2.0f
        boardX = edge
        boardY = edge
        worldW = boardW + 2 * edge
        worldH = boardH + 2 * edge
    }

    /**
     * Centros (x,y) dos espaços do anel k, em volta do tabuleiro. Cada lado começa no seu canto
     * (sentido horário), então nenhum canto é duplicado e o espaçamento nunca fica menor que o passo.
     */
    private fun ringSlots(k: Int): FloatArray {
        val d = ringOffset(k)
        val left = boardX - d
        val top = boardY - d
        val w = boardW + 2 * d
        val h = boardH + 2 * d
        val c = ringSideCounts(k)
        val nx = c[0]
        val ny = c[1]
        val out = FloatArray(2 * (nx + ny) * 2)
        var i = 0
        fun put(x: Float, y: Float) { out[i++] = x; out[i++] = y }
        for (j in 0 until nx) put(left + j * w / nx, top)                 // topo, esq -> dir
        for (j in 0 until ny) put(left + w, top + j * h / ny)             // direita, cima -> baixo
        for (j in 0 until nx) put(left + w - j * w / nx, top + h)         // base, dir -> esq
        for (j in 0 until ny) put(left, top + h - j * h / ny)             // esquerda, baixo -> cima
        return out
    }

    /**
     * Arruma as peças soltas em anéis ao redor do tabuleiro (ordem embaralhada).
     * Blocos já montados (2+ peças) e peças travadas no tabuleiro não são movidos.
     * A rotação das peças é mantida.
     */
    fun arrangeAround(record: Boolean = true) {
        if (pieces.isEmpty()) return
        val rnd = Random()
        val lockedGroups = groups.filter { it.locked }
        val loose = groups.filter { !it.locked }
        val singles = loose.filter { it.pieces.size == 1 }.toMutableList()
        singles.shuffle(rnd)
        val blocks = loose.filter { it.pieces.size > 1 }
        val pad = cell * 0.25f
        val boxes = blocks.map { b ->
            val bb = bbox(b)
            floatArrayOf(bb[0] - pad, bb[1] - pad, bb[2] + pad, bb[3] + pad)
        }

        var next = 0
        for (k in 1..ringsTotal) {
            if (next >= singles.size) break
            val slots = ringSlots(k)
            val free = ArrayList<Int>()
            for (i in 0 until slots.size / 2) {
                val x = slots[i * 2] - cell / 2f
                val y = slots[i * 2 + 1] - cell / 2f
                if (boxes.none { x < it[2] && x + cell > it[0] && y < it[3] && y + cell > it[1] }) free.add(i)
            }
            val remaining = singles.size - next
            // último anel: espalha as peças que faltam de forma uniforme, em vez de encostar de um lado
            val take = if (remaining >= free.size) free
            else List(remaining) { free[(it.toLong() * free.size / remaining).toInt()] }
            for (i in take) {
                val p = singles[next++].pieces[0]
                p.x = slots[i * 2] - cell / 2f
                p.y = slots[i * 2 + 1] - cell / 2f
            }
        }
        // sobrou peça sem espaço (muitos blocos no caminho): espalha no que estiver livre
        for (j in next until singles.size) scatterGroup(singles[j], rnd)

        groups.clear()
        groups.addAll(lockedGroups)
        groups.addAll(singles)
        groups.addAll(blocks)
        if (record) recordSnapshot()
        invalidate()
    }

    // ---------------------------------------------------------------- gravação / vídeo

    /** Dados do puzzle para o renderizador do vídeo (null se ainda não está pronto). */
    fun replayAssets(): ReplayAssets? {
        val img = scaledImage ?: return null
        if (pieces.isEmpty()) return null
        return ReplayAssets(
            Array(pieces.size) { pieces[it].bmp }, img, cell, margin,
            boardX, boardY, boardW, boardH, worldW, worldH,
            tableColor, shade(tableColor, 0.78f), shade(tableColor, 0.55f), ghostAlpha
        )
    }

    fun flushRecording() {
        recorder?.flush()
    }

    private fun recordSnapshot() {
        val r = recorder ?: return
        val n = pieces.size
        val xs = FloatArray(n)
        val ys = FloatArray(n)
        val gid = IntArray(n)
        val lk = BooleanArray(n)
        val rt = IntArray(n)
        groups.forEachIndexed { gi, g ->
            for (p in g.pieces) {
                xs[p.index] = (p.x - boardX) / cell
                ys[p.index] = (p.y - boardY) / cell
                gid[p.index] = gi
                lk[p.index] = g.locked
                rt[p.index] = p.rot
            }
        }
        r.snapshot(xs, ys, gid, lk, rt)
    }

    private fun recordMove() {
        val a = dragAnchor ?: return
        recorder?.move((a.x - boardX) / cell, (a.y - boardY) / cell)
    }

    private fun recordUp(anchor: Piece) {
        val r = recorder ?: return
        val g = anchor.group
        val k = g.pieces.size
        val idx = IntArray(k)
        val xs = FloatArray(k)
        val ys = FloatArray(k)
        val rt = IntArray(k)
        val lk = BooleanArray(k) { g.locked }
        for ((j, p) in g.pieces.withIndex()) {
            idx[j] = p.index
            xs[j] = (p.x - boardX) / cell
            ys[j] = (p.y - boardY) / cell
            rt[j] = p.rot
        }
        r.up(idx, xs, ys, lk, rt)
    }

    /** Enquadra a mesa inteira na tela (zoom inicial). */
    fun fitToView() {
        if (width == 0 || height == 0 || worldW == 0f) return
        val s = min(width / worldW, height / worldH)
        fitScale = s
        minScale = s * 0.75f
        maxScale = s * 12f
        scale = s
        tx = (width - worldW * s) / 2f
        ty = (height - worldH * s) / 2f
        invalidate()
    }

    // ---------------------------------------------------------------- geração (thread de fundo)

    private fun build(src: Bitmap, rows: Int, cols: Int, seed: Long, shapeStyle: Int): Built {
        val n = rows * cols
        val srcCell = max(1, min(src.width / cols, src.height / rows))
        val mf = JigsawGeometry.marginFactor(shapeStyle)
        val side0 = 1.0 + 2 * mf
        var rc = sqrt(12_000_000.0 / (n * side0 * side0)).toInt().coerceIn(48, 256)
        if (rc > srcCell) rc = max(24, srcCell)
        val m = ceil(rc * mf).toInt()

        // recorta o centro da imagem para caber em células quadradas e reduz para o tamanho de render
        val cropW = srcCell * cols
        val cropH = srcCell * rows
        val left = (src.width - cropW) / 2
        val top = (src.height - cropH) / 2
        val scaled = Bitmap.createBitmap(cols * rc, rows * rc, Bitmap.Config.ARGB_8888)
        Canvas(scaled).drawBitmap(
            src,
            Rect(left, top, left + cropW, top + cropH),
            Rect(0, 0, cols * rc, rows * rc),
            Paint(Paint.FILTER_BITMAP_FLAG)
        )

        val geo = JigsawGeometry(rows, cols, rc.toFloat(), seed, shapeStyle)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = BitmapShader(scaled, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        }
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = max(1f, rc * 0.012f)
            strokeJoin = Paint.Join.ROUND
            color = Color.argb(90, 0, 0, 0)
        }
        val side = rc + 2 * m
        val bitmaps = Array(n) { i ->
            val r = i / cols
            val c = i % cols
            val bmp = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            canvas.translate((m - c * rc).toFloat(), (m - r * rc).toFloat())
            val path = geo.pathFor(r, c)
            canvas.drawPath(path, fill)
            canvas.drawPath(path, stroke)
            bmp
        }
        return Built(rows, cols, rc, m, scaled, bitmaps, geo)
    }

    // ---------------------------------------------------------------- instalação do resultado (UI)

    private fun install(b: Built, saved: JSONObject?) {
        rows = b.rows
        cols = b.cols
        cell = b.rc.toFloat()
        margin = b.margin.toFloat()
        scaledImage = b.scaled
        builtRef = b
        boardW = cols * cell
        boardH = rows * cell
        computeWorld(b.rows * b.cols)

        pieces = Array(rows * cols) { i ->
            val r = i / cols
            val c = i % cols
            Piece(r, c, i, r == 0 || c == 0 || r == rows - 1 || c == cols - 1, b.bitmaps[i])
        }
        groups.clear()
        completed = false

        val restored = saved != null && restore(saved)
        if (!restored) {
            groups.clear()
            val rnd = Random()
            for (p in pieces) {
                if (rotationMode) p.rot = rnd.nextInt(4)
                val g = Group()
                g.pieces.add(p)
                p.group = g
                groups.add(g)
            }
        }

        if (restored) for (g in groups.toList()) keepInWorld(g)
        else arrangeAround(record = false)

        recorder?.close()
        recorder = ReplayRecorder(ImageStore.recFile(context), append = restored)
        recordSnapshot()

        fitToView()
        notifyProgress()
        listener?.onReady()
        invalidate()
    }

    private fun restore(js: JSONObject): Boolean {
        try {
            val n = pieces.size
            val arr = js.getJSONArray("groups")
            val seen = BooleanArray(n)
            val xs = FloatArray(n)
            val ys = FloatArray(n)
            val rt = IntArray(n)
            val tmp = ArrayList<Group>()
            for (gi in 0 until arr.length()) {
                val go = arr.getJSONObject(gi)
                val g = Group(go.getBoolean("locked"))
                val ps = go.getJSONArray("p")
                for (k in 0 until ps.length()) {
                    val e = ps.getJSONArray(k)
                    val i = e.getInt(0)
                    if (i !in 0 until n || seen[i]) return false
                    seen[i] = true
                    xs[i] = boardX + e.getDouble(1).toFloat() * cell
                    ys[i] = boardY + e.getDouble(2).toFloat() * cell
                    rt[i] = e.optInt(3, 0) and 3
                    g.pieces.add(pieces[i])
                }
                tmp.add(g)
            }
            if (seen.any { !it }) return false
            for (g in tmp) for (p in g.pieces) {
                p.group = g
                p.x = xs[p.index]
                p.y = ys[p.index]
                p.rot = rt[p.index]
            }
            groups.addAll(tmp)
            return true
        } catch (e: Exception) {
            return false
        }
    }

    // ---------------------------------------------------------------- utilidades de grupo

    private fun translate(g: Group, dx: Float, dy: Float) {
        for (p in g.pieces) {
            p.x += dx
            p.y += dy
        }
    }

    private fun bbox(g: Group): FloatArray {
        var l = Float.MAX_VALUE
        var t = Float.MAX_VALUE
        var r = -Float.MAX_VALUE
        var b = -Float.MAX_VALUE
        for (p in g.pieces) {
            l = min(l, p.x)
            t = min(t, p.y)
            r = max(r, p.x + cell)
            b = max(b, p.y + cell)
        }
        return floatArrayOf(l, t, r, b)
    }

    private fun scatterGroup(g: Group, rnd: Random) {
        val bb = bbox(g)
        val w = bb[2] - bb[0]
        val h = bb[3] - bb[1]
        var nx = 0f
        var ny = 0f
        for (attempt in 0 until 40) {
            nx = rnd.nextFloat() * max(1f, worldW - w)
            ny = rnd.nextFloat() * max(1f, worldH - h)
            val overlapsBoard = nx < boardX + boardW && nx + w > boardX &&
                ny < boardY + boardH && ny + h > boardY
            if (!overlapsBoard) break
        }
        translate(g, nx - bb[0], ny - bb[1])
    }

    /** Mantém o grupo dentro da mesa. */
    private fun keepInWorld(g: Group) {
        val bb = bbox(g)
        var dx = 0f
        var dy = 0f
        if (bb[0] < 0f) dx = -bb[0] else if (bb[2] > worldW) dx = worldW - bb[2]
        if (bb[1] < 0f) dy = -bb[1] else if (bb[3] > worldH) dy = worldH - bb[3]
        if (dx != 0f || dy != 0f) translate(g, dx, dy)
    }

    /** Gira o grupo 90° no sentido horário em torno do centro da peça [pivot]. */
    private fun rotateGroup(g: Group, pivot: Piece) {
        val pcx = pivot.x + cell / 2f
        val pcy = pivot.y + cell / 2f
        for (p in g.pieces) {
            val dx = p.x + cell / 2f - pcx
            val dy = p.y + cell / 2f - pcy
            p.x = pcx + rotX(dx, dy, 1) - cell / 2f
            p.y = pcy + rotY(dx, dy, 1) - cell / 2f
            p.rot = (p.rot + 1) and 3
        }
        keepInWorld(g)
    }

    private fun isDimmed(g: Group) =
        edgesOnly && !g.locked && g.pieces.none { it.isEdge }

    // ---------------------------------------------------------------- encaixe

    private fun snapDistance(): Float {
        val byScreen = 24f * density / scale
        return min(max(cell * 0.2f, byScreen), cell * 0.45f)
    }

    private fun neighborsOf(p: Piece): List<Piece> {
        val out = ArrayList<Piece>(4)
        if (p.row > 0) out.add(pieces[(p.row - 1) * cols + p.col])
        if (p.row < rows - 1) out.add(pieces[(p.row + 1) * cols + p.col])
        if (p.col > 0) out.add(pieces[p.row * cols + p.col - 1])
        if (p.col < cols - 1) out.add(pieces[p.row * cols + p.col + 1])
        return out
    }

    private fun merge(a: Group, b: Group): Group {
        for (p in b.pieces) {
            p.group = a
            a.pieces.add(p)
        }
        if (b.locked) a.locked = true
        groups.remove(b)
        return a
    }

    /** Tenta encaixar o grupo no tabuleiro e nos vizinhos. Retorna true se algo encaixou. */
    private fun settle(start: Group): Boolean {
        val snap = snapDistance()
        var g = start
        var snapped = false
        var again = true
        while (again) {
            again = false

            // só encaixa no tabuleiro se estiver na orientação certa
            if (!g.locked && g.pieces[0].rot == 0) {
                for (p in g.pieces) {
                    val dx = boardX + p.col * cell - p.x
                    val dy = boardY + p.row * cell - p.y
                    if (abs(dx) <= snap && abs(dy) <= snap) {
                        translate(g, dx, dy)
                        g.locked = true
                        again = true
                        snapped = true
                        break
                    }
                }
                if (again) continue
            }

            search@ for (p in g.pieces) {
                for (q in neighborsOf(p)) {
                    if (q.group === g) continue
                    if (q.rot != p.rot) continue
                    // onde q deveria estar em relação a p, considerando a rotação do grupo
                    val vx = (q.col - p.col) * cell
                    val vy = (q.row - p.row) * cell
                    val ex = p.x + rotX(vx, vy, p.rot)
                    val ey = p.y + rotY(vx, vy, p.rot)
                    val dx = ex - q.x
                    val dy = ey - q.y
                    if (abs(dx) <= snap && abs(dy) <= snap) {
                        val other = q.group
                        if (other.locked && !g.locked) translate(g, -dx, -dy)
                        else if (!other.locked) translate(other, dx, dy)
                        g = merge(g, other)
                        again = true
                        snapped = true
                        break@search
                    }
                }
            }
        }
        return snapped
    }

    /** Se todas as peças estão unidas, endireita e trava tudo no tabuleiro. */
    private fun checkComplete(): Boolean {
        if (completed || groups.size != 1) return false
        val g = groups[0]
        for (p in g.pieces) {
            p.rot = 0
            p.x = boardX + p.col * cell
            p.y = boardY + p.row * cell
        }
        g.locked = true
        completed = true
        invalidate()
        return true
    }

    private fun notifyProgress() {
        val n = pieces.size
        val percent = if (n > 1) (n - groups.size) * 100 / (n - 1) else 0
        listener?.onProgress(percent, n)
    }

    // ---------------------------------------------------------------- desenho

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (worldW == 0f || oldw == 0 || oldh == 0 || fitScale <= 0f || scale <= 0f) {
            fitToView()
            return
        }
        // girou a tela / mudou o tamanho: mantém o ponto central e o zoom relativo
        val rel = scale / fitScale
        val cx = (oldw / 2f - tx) / scale
        val cy = (oldh / 2f - ty) / scale
        val s = min(w / worldW, h / worldH)
        fitScale = s
        minScale = s * 0.75f
        maxScale = s * 12f
        scale = (s * rel).coerceIn(minScale, maxScale)
        tx = w / 2f - cx * scale
        ty = h / 2f - cy * scale
        clampTranslation()
        invalidate()
    }

    private fun drawPiece(c: Canvas, p: Piece, dx: Float, dy: Float, paint: Paint) {
        val x = p.x - margin + dx
        val y = p.y - margin + dy
        if (p.rot == 0) {
            c.drawBitmap(p.bmp, x, y, paint)
        } else {
            c.save()
            c.rotate(p.rot * 90f, p.x + cell / 2f + dx, p.y + cell / 2f + dy)
            c.drawBitmap(p.bmp, x, y, paint)
            c.restore()
        }
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
        val img = scaledImage
        if (pieces.isEmpty() || img == null) {
            canvas.drawText(
                context.getString(R.string.generating),
                width / 2f, height / 2f, textPaint
            )
            return
        }

        canvas.save()
        canvas.translate(tx, ty)
        canvas.scale(scale, scale)

        canvas.drawRect(0f, 0f, worldW, worldH, tablePaint)
        canvas.drawRect(boardX, boardY, boardX + boardW, boardY + boardH, boardPaint)
        if (showGhost && ghostAlpha > 0) {
            canvas.drawBitmap(
                img, null,
                RectF(boardX, boardY, boardX + boardW, boardY + boardH), ghostPaint
            )
        }
        boardStroke.strokeWidth = 2f * density / scale
        canvas.drawRect(boardX, boardY, boardX + boardW, boardY + boardH, boardStroke)

        val vl = -tx / scale
        val vt = -ty / scale
        val vr = (width - tx) / scale
        val vb = (height - ty) / scale

        for (g in groups) if (g.locked) drawGroup(canvas, g, vl, vt, vr, vb)
        for (g in groups) if (!g.locked && g !== dragGroup) drawGroup(canvas, g, vl, vt, vr, vb)
        dragGroup?.let { g ->
            val off = cell * 0.06f
            for (p in g.pieces) drawPiece(canvas, p, off, off * 1.5f, shadowPaint)
            drawGroup(canvas, g, vl, vt, vr, vb)
        }
        canvas.restore()

        // aviso de "primeira batida" na borda: bata de novo para andar a tela
        if (armedSide >= 0) {
            if (SystemClock.uptimeMillis() < armedUntil) {
                val t = 6f * density
                when (armedSide) {
                    0 -> canvas.drawRect(0f, 0f, t, height.toFloat(), edgeGlow)
                    1 -> canvas.drawRect(0f, 0f, width.toFloat(), t, edgeGlow)
                    2 -> canvas.drawRect(width - t, 0f, width.toFloat(), height.toFloat(), edgeGlow)
                    else -> canvas.drawRect(0f, height - t, width.toFloat(), height.toFloat(), edgeGlow)
                }
            } else {
                armedSide = -1
            }
        }
    }

    private fun drawGroup(c: Canvas, g: Group, vl: Float, vt: Float, vr: Float, vb: Float) {
        piecePaint.alpha = if (isDimmed(g)) 45 else 255
        for (p in g.pieces) {
            if (p.x + cell + margin < vl || p.x - margin > vr ||
                p.y + cell + margin < vt || p.y - margin > vb
            ) continue
            if (g.locked && !p.plain) makePlain(p)
            drawPiece(c, p, 0f, 0f, piecePaint)
        }
    }

    // ---------------------------------------------------------------- toque

    private enum class Mode { NONE, DRAG, PAN }

    private var mode = Mode.NONE
    private var dragGroup: Group? = null
    private var activeId = -1
    private var lastX = 0f
    private var lastY = 0f
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L
    private var moved = false
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop.toFloat()

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            private var lfx = 0f
            private var lfy = 0f

            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                lfx = detector.focusX
                lfy = detector.focusY
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val ns = (scale * detector.scaleFactor).coerceIn(minScale, maxScale)
                val f = ns / scale
                tx = detector.focusX - (detector.focusX - tx) * f
                ty = detector.focusY - (detector.focusY - ty) * f
                tx += detector.focusX - lfx
                ty += detector.focusY - lfy
                lfx = detector.focusX
                lfy = detector.focusY
                scale = ns
                clampTranslation()
                invalidate()
                return true
            }
        })

    /** Limita o pan, mas deixa uma folga de ~20% da tela além da borda da mesa ("mais espaço em volta"). */
    private fun clampTranslation() {
        val slack = min(width, height) * 0.2f
        val sw = worldW * scale
        val sh = worldH * scale
        tx = if (sw + 2 * slack <= width) (width - sw) / 2f else tx.coerceIn(width - sw - slack, slack)
        ty = if (sh + 2 * slack <= height) (height - sh) / 2f else ty.coerceIn(height - sh - slack, slack)
    }

    private fun pieceAt(wx: Float, wy: Float): Piece? {
        for (gi in groups.indices.reversed()) {
            val g = groups[gi]
            if (g.locked || isDimmed(g)) continue
            for (p in g.pieces) {
                val dx = wx - (p.x + cell / 2f)
                val dy = wy - (p.y + cell / 2f)
                val inv = (4 - p.rot) and 3
                val lx = (rotX(dx, dy, inv) + cell / 2f + margin).toInt()
                val ly = (rotY(dx, dy, inv) + cell / 2f + margin).toInt()
                if (lx < 0 || ly < 0 || lx >= p.bmp.width || ly >= p.bmp.height) continue
                if (Color.alpha(p.bmp.getPixel(lx, ly)) > 40) return p
            }
        }
        return null
    }

    // ---- travar a tela ao segurar uma peça: só anda ao "bater" 2x na mesma borda

    private val wasInside = BooleanArray(4)   // 0 esq, 1 topo, 2 dir, 3 base
    private val lastHit = LongArray(4)
    private var armedSide = -1
    private var armedUntil = 0L
    private var panRemX = 0f
    private var panRemY = 0f
    private var panning = false

    private fun edgeFlags(x: Float, y: Float): BooleanArray {
        val thr = 36f * density
        return booleanArrayOf((x < thr), (y < thr), (x > width - thr), (y > height - thr))
    }

    /** Registra onde o dedo está, sem contar como batida (início do arrasto). */
    private fun primeEdges(x: Float, y: Float) {
        val f = edgeFlags(x, y)
        for (s in 0..3) { wasInside[s] = f[s]; lastHit[s] = 0L }
        armedSide = -1
    }

    private fun updateEdgeHits(x: Float, y: Float) {
        val f = edgeFlags(x, y)
        val now = SystemClock.uptimeMillis()
        for (s in 0..3) {
            if (f[s] && !wasInside[s]) {
                if (lastHit[s] != 0L && now - lastHit[s] <= 1500L) {
                    lastHit[s] = 0L
                    armedSide = -1
                    startPan(s)
                } else {
                    lastHit[s] = now
                    armedSide = s
                    armedUntil = now + 1500L
                    postInvalidateDelayed(1600L)
                }
            }
            wasInside[s] = f[s]
        }
    }

    private fun startPan(side: Int) {
        when (side) {
            0 -> panRemX += width * 0.5f
            1 -> panRemY += height * 0.5f
            2 -> panRemX -= width * 0.5f
            else -> panRemY -= height * 0.5f
        }
        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        if (!panning) {
            panning = true
            postOnAnimation(panStep)
        }
    }

    private val panStep = object : Runnable {
        override fun run() {
            val sx = if (abs(panRemX) < 2f) panRemX else panRemX * 0.25f
            val sy = if (abs(panRemY) < 2f) panRemY else panRemY * 0.25f
            val ox = tx
            val oy = ty
            tx += sx
            ty += sy
            clampTranslation()
            val rdx = tx - ox
            val rdy = ty - oy
            panRemX -= sx
            panRemY -= sy
            if (sx != 0f && rdx == 0f) panRemX = 0f // chegou no limite da mesa
            if (sy != 0f && rdy == 0f) panRemY = 0f
            // a peça segurada acompanha a tela e continua embaixo do dedo
            val g = dragGroup
            if (g != null && (rdx != 0f || rdy != 0f)) {
                translate(g, -rdx / scale, -rdy / scale)
                keepInWorld(g)
                recordMove()
            }
            invalidate()
            if (abs(panRemX) < 0.5f && abs(panRemY) < 0.5f) {
                panRemX = 0f
                panRemY = 0f
                panning = false
            } else {
                postOnAnimation(this)
            }
        }
    }

    private fun startDrag(g: Group, anchor: Piece, x: Float, y: Float) {
        groups.remove(g)
        groups.add(g)
        dragGroup = g
        dragAnchor = anchor
        recorder?.down(anchor.index)
        mode = Mode.DRAG
        primeEdges(x, y)
        invalidate()
    }

    /** [tap] = o dedo levantou sem arrastar: no modo de peças giradas, gira o grupo. */
    private fun endDrag(tap: Boolean = false) {
        val g = dragGroup
        val anchor = dragAnchor
        dragGroup = null
        dragAnchor = null
        removeCallbacks(panStep)
        panning = false
        panRemX = 0f
        panRemY = 0f
        armedSide = -1
        if (g != null) {
            if (tap && rotationMode && anchor != null && !g.locked) {
                rotateGroup(g, anchor)
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }
            if (settle(g)) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            val done = checkComplete()
            if (anchor != null) recordUp(anchor)
            notifyProgress()
            invalidate()
            if (done) {
                recorder?.close()
                recorder = null
                listener?.onCompleted()
            }
        }
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (pieces.isEmpty()) return true
        scaleDetector.onTouchEvent(ev)

        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                activeId = ev.getPointerId(0)
                lastX = ev.x
                lastY = ev.y
                downX = ev.x
                downY = ev.y
                downTime = ev.eventTime
                moved = false
                val p = pieceAt((ev.x - tx) / scale, (ev.y - ty) / scale)
                if (p != null) startDrag(p.group, p, ev.x, ev.y) else mode = Mode.PAN
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                endDrag()
                mode = Mode.NONE
            }

            MotionEvent.ACTION_MOVE -> {
                if (scaleDetector.isInProgress) return true
                val idx = ev.findPointerIndex(activeId)
                if (idx < 0) return true
                val x = ev.getX(idx)
                val y = ev.getY(idx)
                when (mode) {
                    Mode.DRAG -> {
                        val g = dragGroup
                        if (g != null) {
                            // pequeno tremor do dedo não move a peça (permite tocar para girar)
                            if (!moved) {
                                if (hypot(x - downX, y - downY) <= touchSlop) return true
                                moved = true
                            }
                            translate(g, (x - lastX) / scale, (y - lastY) / scale)
                            keepInWorld(g)
                            recordMove()
                            updateEdgeHits(x, y)
                        }
                    }
                    Mode.PAN -> {
                        tx += x - lastX
                        ty += y - lastY
                        clampTranslation()
                    }
                    Mode.NONE -> {}
                }
                lastX = x
                lastY = y
                invalidate()
            }

            MotionEvent.ACTION_POINTER_UP -> {
                val upIdx = ev.actionIndex
                if (ev.getPointerId(upIdx) == activeId) {
                    val newIdx = if (upIdx == 0) 1 else 0
                    activeId = ev.getPointerId(newIdx)
                }
                val idx = ev.findPointerIndex(activeId)
                if (idx >= 0) {
                    lastX = ev.getX(idx)
                    lastY = ev.getY(idx)
                }
                if (ev.pointerCount - 1 == 1) mode = Mode.PAN
            }

            MotionEvent.ACTION_UP -> {
                val tap = mode == Mode.DRAG && !moved && ev.eventTime - downTime < 400L
                endDrag(tap)
                mode = Mode.NONE
            }

            MotionEvent.ACTION_CANCEL -> {
                endDrag()
                mode = Mode.NONE
            }
        }
        return true
    }
}
