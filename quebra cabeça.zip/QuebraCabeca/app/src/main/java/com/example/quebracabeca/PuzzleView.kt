package com.example.quebracabeca

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import org.json.JSONArray
import org.json.JSONObject
import java.util.Random
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Mesa do quebra-cabeça: desenha o tabuleiro e as peças, trata arrastar peças/grupos,
 * pan e pinça (zoom), encaixe automático e detecção de conclusão.
 *
 * Coordenadas do "mundo" estão em pixels de renderização. A célula de uma peça tem [cell] de lado.
 */
class PuzzleView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    interface Listener {
        fun onReady()
        fun onProgress(percent: Int, total: Int)
        fun onCompleted()
    }

    var listener: Listener? = null

    var showGhost = true
        set(value) { field = value; invalidate() }

    var edgesOnly = false
        set(value) { field = value; invalidate() }

    val previewBitmap: Bitmap? get() = scaledImage
    val isReady: Boolean get() = pieces.isNotEmpty()

    // ---------------------------------------------------------------- modelo

    private class Piece(
        val row: Int,
        val col: Int,
        val index: Int,
        val isEdge: Boolean,
        val bmp: Bitmap
    ) {
        var x = 0f
        var y = 0f
        lateinit var group: Group
    }

    private class Group(var locked: Boolean = false) {
        val pieces = ArrayList<Piece>()
    }

    private class Built(
        val rows: Int,
        val cols: Int,
        val rc: Int,
        val margin: Int,
        val scaled: Bitmap,
        val bitmaps: Array<Bitmap>
    )

    private var rows = 0
    private var cols = 0
    private var cell = 0f
    private var margin = 0f
    private var seed = 0L
    private var style = JigsawGeometry.STYLE_IRREGULAR
    private var ringsTotal = 0
    private var pieces: Array<Piece> = emptyArray()
    private val groups = ArrayList<Group>()
    private var scaledImage: Bitmap? = null
    private var completed = false

    private var boardX = 0f
    private var boardY = 0f
    private var boardW = 0f
    private var boardH = 0f
    private var worldW = 0f
    private var worldH = 0f

    @Volatile
    private var loadToken = 0

    // gravação da montagem (para o vídeo)
    private var recorder: ReplayRecorder? = null
    private var dragAnchor: Piece? = null

    // ---------------------------------------------------------------- câmera

    private var scale = 1f
    private var tx = 0f
    private var ty = 0f
    private var minScale = 0.1f
    private var maxScale = 10f
    private val density = resources.displayMetrics.density

    // ---------------------------------------------------------------- pincéis

    private val bgPaint = Paint().apply { color = 0xFF1E2227.toInt() }
    private val tablePaint = Paint().apply { color = 0xFF353B45.toInt() }
    private val boardPaint = Paint().apply { color = 0xFF262B33.toInt() }
    private val boardStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0x66FFFFFF
    }
    private val ghostPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply { alpha = 46 }
    private val piecePaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val shadowPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
        colorFilter = PorterDuffColorFilter(Color.argb(120, 0, 0, 0), PorterDuff.Mode.SRC_IN)
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 16f * resources.displayMetrics.scaledDensity
    }

    // ---------------------------------------------------------------- entrada pública

    /**
     * Começa um puzzle novo (saved == null) ou restaura um salvo. A geração das peças
     * roda em segundo plano; [Listener.onReady] avisa quando terminar.
     */
    fun start(
        source: Bitmap,
        targetPieces: Int,
        saved: JSONObject?,
        newStyle: Int = JigsawGeometry.STYLE_IRREGULAR,
        newSeed: Long = System.nanoTime()
    ) {
        val token = ++loadToken
        recorder?.close()
        recorder = null
        pieces = emptyArray()
        groups.clear()
        completed = false
        invalidate()

        val savedRows = saved?.optInt("rows", 0) ?: 0
        val savedCols = saved?.optInt("cols", 0) ?: 0
        val useSaved = saved != null && savedRows >= 2 && savedCols >= 2
        val grid = if (useSaved) savedRows to savedCols
        else JigsawGeometry.grid(targetPieces, source.width, source.height)
        seed = if (useSaved) saved!!.optLong("seed", 1L) else newSeed
        style = if (useSaved) saved!!.optInt("style", JigsawGeometry.STYLE_IRREGULAR) else newStyle
        val useSeed = seed
        val useStyle = style

        Thread {
            val built = build(source, grid.first, grid.second, useSeed, useStyle)
            post {
                if (token == loadToken) install(built, if (useSaved) saved else null)
            }
        }.start()
    }

    fun saveState(): JSONObject? {
        if (pieces.isEmpty() || completed) return null
        val root = JSONObject()
        root.put("rows", rows)
        root.put("cols", cols)
        root.put("seed", seed)
        root.put("style", style)
        val arr = JSONArray()
        for (g in groups) {
            val go = JSONObject()
            go.put("locked", g.locked)
            val ps = JSONArray()
            for (p in g.pieces) {
                val e = JSONArray()
                e.put(p.index)
                e.put(((p.x - boardX) / cell).toDouble())
                e.put(((p.y - boardY) / cell).toDouble())
                ps.put(e)
            }
            go.put("p", ps)
            arr.put(go)
        }
        root.put("groups", arr)
        return root
    }

    // ---------------------------------------------------------------- arrumar ao redor

    private fun ringPitch() = cell * 1.3f
    private fun ringOffset(k: Int) = cell * 1.0f + (k - 1) * ringPitch()

    private fun ringSideCounts(k: Int): IntArray {
        val d = ringOffset(k)
        val nx = max(1, floor((boardW + 2 * d) / ringPitch()).toInt())
        val ny = max(1, floor((boardH + 2 * d) / ringPitch()).toInt())
        return intArrayOf(nx, ny)
    }

    private fun ringSlotCount(k: Int): Int {
        val c = ringSideCounts(k)
        return 2 * (c[0] + c[1])
    }

    /** Define o tamanho da mesa: anéis suficientes para todas as peças + 1 anel de folga. */
    private fun computeWorld(n: Int) {
        var k = 0
        var cap = 0
        while (cap < n) {
            k++
            cap += ringSlotCount(k)
        }
        ringsTotal = k + 1
        val edge = ringOffset(ringsTotal) + cell * 1.0f
        boardX = edge
        boardY = edge
        worldW = boardW + 2 * edge
        worldH = boardH + 2 * edge
    }

    /**
     * Centros (x,y) dos espaços do anel k, em volta do tabuleiro. Cada lado começa no seu canto
     * (sentido horário), então nenhum canto é duplicado e o espaçamento nunca fica menor que o passo.
     */
    private fun ringSlots(k: Int): FloatArray {
        val d = ringOffset(k)
        val left = boardX - d
        val top = boardY - d
        val w = boardW + 2 * d
        val h = boardH + 2 * d
        val c = ringSideCounts(k)
        val nx = c[0]
        val ny = c[1]
        val out = FloatArray(2 * (nx + ny) * 2)
        var i = 0
        fun put(x: Float, y: Float) { out[i++] = x; out[i++] = y }
        for (j in 0 until nx) put(left + j * w / nx, top)                 // topo, esq -> dir
        for (j in 0 until ny) put(left + w, top + j * h / ny)             // direita, cima -> baixo
        for (j in 0 until nx) put(left + w - j * w / nx, top + h)         // base, dir -> esq
        for (j in 0 until ny) put(left, top + h - j * h / ny)             // esquerda, baixo -> cima
        return out
    }

    /**
     * Arruma as peças soltas em anéis ao redor do tabuleiro (ordem embaralhada).
     * Blocos já montados (2+ peças) e peças travadas no tabuleiro não são movidos.
     */
    fun arrangeAround(record: Boolean = true) {
        if (pieces.isEmpty()) return
        val rnd = Random()
        val lockedGroups = groups.filter { it.locked }
        val loose = groups.filter { !it.locked }
        val singles = loose.filter { it.pieces.size == 1 }.toMutableList()
        singles.shuffle(rnd)
        val blocks = loose.filter { it.pieces.size > 1 }
        val pad = cell * 0.25f
        val boxes = blocks.map { b ->
            val bb = bbox(b)
            floatArrayOf(bb[0] - pad, bb[1] - pad, bb[2] + pad, bb[3] + pad)
        }

        var next = 0
        for (k in 1..ringsTotal) {
            if (next >= singles.size) break
            val slots = ringSlots(k)
            val free = ArrayList<Int>()
            for (i in 0 until slots.size / 2) {
                val x = slots[i * 2] - cell / 2f
                val y = slots[i * 2 + 1] - cell / 2f
                if (boxes.none { x < it[2] && x + cell > it[0] && y < it[3] && y + cell > it[1] }) free.add(i)
            }
            val remaining = singles.size - next
            // último anel: espalha as peças que faltam de forma uniforme, em vez de encostar de um lado
            val take = if (remaining >= free.size) free
            else List(remaining) { free[(it.toLong() * free.size / remaining).toInt()] }
            for (i in take) {
                val p = singles[next++].pieces[0]
                p.x = slots[i * 2] - cell / 2f
                p.y = slots[i * 2 + 1] - cell / 2f
            }
        }
        // sobrou peça sem espaço (muitos blocos no caminho): espalha no que estiver livre
        for (j in next until singles.size) scatterGroup(singles[j], rnd)

        groups.clear()
        groups.addAll(lockedGroups)
        groups.addAll(singles)
        groups.addAll(blocks)
        if (record) recordSnapshot()
        invalidate()
    }

    // ---------------------------------------------------------------- gravação / vídeo

    /** Dados do puzzle para o renderizador do vídeo (null se ainda não está pronto). */
    fun replayAssets(): ReplayAssets? {
        val img = scaledImage ?: return null
        if (pieces.isEmpty()) return null
        return ReplayAssets(
            Array(pieces.size) { pieces[it].bmp }, img, cell, margin,
            boardX, boardY, boardW, boardH, worldW, worldH
        )
    }

    fun flushRecording() {
        recorder?.flush()
    }

    private fun recordSnapshot() {
        val r = recorder ?: return
        val n = pieces.size
        val xs = FloatArray(n)
        val ys = FloatArray(n)
        val gid = IntArray(n)
        val lk = BooleanArray(n)
        groups.forEachIndexed { gi, g ->
            for (p in g.pieces) {
                xs[p.index] = (p.x - boardX) / cell
                ys[p.index] = (p.y - boardY) / cell
                gid[p.index] = gi
                lk[p.index] = g.locked
            }
        }
        r.snapshot(xs, ys, gid, lk)
    }

    private fun recordMove() {
        val a = dragAnchor ?: return
        recorder?.move((a.x - boardX) / cell, (a.y - boardY) / cell)
    }

    private fun recordUp(anchor: Piece) {
        val r = recorder ?: return
        val g = anchor.group
        val k = g.pieces.size
        val idx = IntArray(k)
        val xs = FloatArray(k)
        val ys = FloatArray(k)
        val lk = BooleanArray(k) { g.locked }
        for ((j, p) in g.pieces.withIndex()) {
            idx[j] = p.index
            xs[j] = (p.x - boardX) / cell
            ys[j] = (p.y - boardY) / cell
        }
        r.up(idx, xs, ys, lk)
    }

    fun fitToView() {
        if (width == 0 || height == 0 || worldW == 0f) return
        val s = min(width / worldW, height / worldH)
        minScale = s
        maxScale = s * 10f
        scale = s
        tx = (width - worldW * s) / 2f
        ty = (height - worldH * s) / 2f
        invalidate()
    }

    // ---------------------------------------------------------------- geração (thread de fundo)

    private fun build(src: Bitmap, rows: Int, cols: Int, seed: Long, shapeStyle: Int): Built {
        val n = rows * cols
        val srcCell = max(1, min(src.width / cols, src.height / rows))
        val mf = JigsawGeometry.marginFactor(shapeStyle)
        val side0 = 1.0 + 2 * mf
        var rc = sqrt(12_000_000.0 / (n * side0 * side0)).toInt().coerceIn(48, 256)
        if (rc > srcCell) rc = max(24, srcCell)
        val m = ceil(rc * mf).toInt()

        // recorta o centro da imagem para caber em células quadradas e reduz para o tamanho de render
        val cropW = srcCell * cols
        val cropH = srcCell * rows
        val left = (src.width - cropW) / 2
        val top = (src.height - cropH) / 2
        val scaled = Bitmap.createBitmap(cols * rc, rows * rc, Bitmap.Config.ARGB_8888)
        Canvas(scaled).drawBitmap(
            src,
            Rect(left, top, left + cropW, top + cropH),
            Rect(0, 0, cols * rc, rows * rc),
            Paint(Paint.FILTER_BITMAP_FLAG)
        )

        val geo = JigsawGeometry(rows, cols, rc.toFloat(), seed, shapeStyle)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = BitmapShader(scaled, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        }
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = max(1f, rc * 0.012f)
            strokeJoin = Paint.Join.ROUND
            color = Color.argb(90, 0, 0, 0)
        }
        val side = rc + 2 * m
        val bitmaps = Array(n) { i ->
            val r = i / cols
            val c = i % cols
            val bmp = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            canvas.translate((m - c * rc).toFloat(), (m - r * rc).toFloat())
            val path = geo.pathFor(r, c)
            canvas.drawPath(path, fill)
            canvas.drawPath(path, stroke)
            bmp
        }
        return Built(rows, cols, rc, m, scaled, bitmaps)
    }

    // ---------------------------------------------------------------- instalação do resultado (UI)

    private fun install(b: Built, saved: JSONObject?) {
        rows = b.rows
        cols = b.cols
        cell = b.rc.toFloat()
        margin = b.margin.toFloat()
        scaledImage = b.scaled
        boardW = cols * cell
        boardH = rows * cell
        computeWorld(b.rows * b.cols)

        pieces = Array(rows * cols) { i ->
            val r = i / cols
            val c = i % cols
            Piece(r, c, i, r == 0 || c == 0 || r == rows - 1 || c == cols - 1, b.bitmaps[i])
        }
        groups.clear()
        completed = false

        val restored = saved != null && restore(saved)
        if (!restored) {
            groups.clear()
            for (p in pieces) {
                val g = Group()
                g.pieces.add(p)
                p.group = g
                groups.add(g)
            }
        }

        if (restored) for (g in groups.toList()) keepInWorld(g)
        else arrangeAround(record = false)

        recorder?.close()
        recorder = ReplayRecorder(ImageStore.recFile(context), append = restored)
        recordSnapshot()

        fitToView()
        notifyProgress()
        listener?.onReady()
        invalidate()
    }

    private fun restore(js: JSONObject): Boolean {
        try {
            val n = pieces.size
            val arr = js.getJSONArray("groups")
            val seen = BooleanArray(n)
            val xs = FloatArray(n)
            val ys = FloatArray(n)
            val tmp = ArrayList<Group>()
            for (gi in 0 until arr.length()) {
                val go = arr.getJSONObject(gi)
                val g = Group(go.getBoolean("locked"))
                val ps = go.getJSONArray("p")
                for (k in 0 until ps.length()) {
                    val e = ps.getJSONArray(k)
                    val i = e.getInt(0)
                    if (i !in 0 until n || seen[i]) return false
                    seen[i] = true
                    xs[i] = boardX + e.getDouble(1).toFloat() * cell
                    ys[i] = boardY + e.getDouble(2).toFloat() * cell
                    g.pieces.add(pieces[i])
                }
                tmp.add(g)
            }
            if (seen.any { !it }) return false
            for (g in tmp) for (p in g.pieces) {
                p.group = g
                p.x = xs[p.index]
                p.y = ys[p.index]
            }
            groups.addAll(tmp)
            return true
        } catch (e: Exception) {
            return false
        }
    }

    // ---------------------------------------------------------------- utilidades de grupo

    private fun translate(g: Group, dx: Float, dy: Float) {
        for (p in g.pieces) {
            p.x += dx
            p.y += dy
        }
    }

    private fun bbox(g: Group): FloatArray {
        var l = Float.MAX_VALUE
        var t = Float.MAX_VALUE
        var r = -Float.MAX_VALUE
        var b = -Float.MAX_VALUE
        for (p in g.pieces) {
            l = min(l, p.x)
            t = min(t, p.y)
            r = max(r, p.x + cell)
            b = max(b, p.y + cell)
        }
        return floatArrayOf(l, t, r, b)
    }

    private fun scatterGroup(g: Group, rnd: Random) {
        val bb = bbox(g)
        val w = bb[2] - bb[0]
        val h = bb[3] - bb[1]
        var nx = 0f
        var ny = 0f
        for (attempt in 0 until 40) {
            nx = rnd.nextFloat() * max(1f, worldW - w)
            ny = rnd.nextFloat() * max(1f, worldH - h)
            val overlapsBoard = nx < boardX + boardW && nx + w > boardX &&
                ny < boardY + boardH && ny + h > boardY
            if (!overlapsBoard) break
        }
        translate(g, nx - bb[0], ny - bb[1])
    }

    /** Mantém o grupo dentro da mesa. */
    private fun keepInWorld(g: Group) {
        val bb = bbox(g)
        var dx = 0f
        var dy = 0f
        if (bb[0] < 0f) dx = -bb[0] else if (bb[2] > worldW) dx = worldW - bb[2]
        if (bb[1] < 0f) dy = -bb[1] else if (bb[3] > worldH) dy = worldH - bb[3]
        if (dx != 0f || dy != 0f) translate(g, dx, dy)
    }

    private fun isDimmed(g: Group) =
        edgesOnly && !g.locked && g.pieces.none { it.isEdge }

    // ---------------------------------------------------------------- encaixe

    private fun snapDistance(): Float {
        val byScreen = 24f * density / scale
        return min(max(cell * 0.2f, byScreen), cell * 0.45f)
    }

    private fun neighborsOf(p: Piece): List<Piece> {
        val out = ArrayList<Piece>(4)
        if (p.row > 0) out.add(pieces[(p.row - 1) * cols + p.col])
        if (p.row < rows - 1) out.add(pieces[(p.row + 1) * cols + p.col])
        if (p.col > 0) out.add(pieces[p.row * cols + p.col - 1])
        if (p.col < cols - 1) out.add(pieces[p.row * cols + p.col + 1])
        return out
    }

    private fun merge(a: Group, b: Group): Group {
        for (p in b.pieces) {
            p.group = a
            a.pieces.add(p)
        }
        if (b.locked) a.locked = true
        groups.remove(b)
        return a
    }

    /** Tenta encaixar o grupo no tabuleiro e nos vizinhos. Retorna true se algo encaixou. */
    private fun settle(start: Group): Boolean {
        val snap = snapDistance()
        var g = start
        var snapped = false
        var again = true
        while (again) {
            again = false

            if (!g.locked) {
                for (p in g.pieces) {
                    val dx = boardX + p.col * cell - p.x
                    val dy = boardY + p.row * cell - p.y
                    if (abs(dx) <= snap && abs(dy) <= snap) {
                        translate(g, dx, dy)
                        g.locked = true
                        again = true
                        snapped = true
                        break
                    }
                }
                if (again) continue
            }

            search@ for (p in g.pieces) {
                for (q in neighborsOf(p)) {
                    if (q.group === g) continue
                    val ex = p.x + (q.col - p.col) * cell
                    val ey = p.y + (q.row - p.row) * cell
                    val dx = ex - q.x
                    val dy = ey - q.y
                    if (abs(dx) <= snap && abs(dy) <= snap) {
                        val other = q.group
                        if (other.locked && !g.locked) translate(g, -dx, -dy)
                        else if (!other.locked) translate(other, dx, dy)
                        g = merge(g, other)
                        again = true
                        snapped = true
                        break@search
                    }
                }
            }
        }
        return snapped
    }

    /** Se todas as peças estão unidas, trava tudo no tabuleiro. O aviso é dado por quem chama. */
    private fun checkComplete(): Boolean {
        if (completed || groups.size != 1) return false
        val g = groups[0]
        val p0 = g.pieces[0]
        translate(g, boardX + p0.col * cell - p0.x, boardY + p0.row * cell - p0.y)
        g.locked = true
        completed = true
        invalidate()
        return true
    }

    private fun notifyProgress() {
        val n = pieces.size
        val percent = if (n > 1) (n - groups.size) * 100 / (n - 1) else 0
        listener?.onProgress(percent, n)
    }

    // ---------------------------------------------------------------- desenho

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        fitToView()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
        val img = scaledImage
        if (pieces.isEmpty() || img == null) {
            canvas.drawText(
                context.getString(R.string.generating),
                width / 2f, height / 2f, textPaint
            )
            return
        }

        canvas.save()
        canvas.translate(tx, ty)
        canvas.scale(scale, scale)

        canvas.drawRect(0f, 0f, worldW, worldH, tablePaint)
        canvas.drawRect(boardX, boardY, boardX + boardW, boardY + boardH, boardPaint)
        if (showGhost) {
            canvas.drawBitmap(
                img, null,
                RectF(boardX, boardY, boardX + boardW, boardY + boardH), ghostPaint
            )
        }
        boardStroke.strokeWidth = 2f * density / scale
        canvas.drawRect(boardX, boardY, boardX + boardW, boardY + boardH, boardStroke)

        val vl = -tx / scale
        val vt = -ty / scale
        val vr = (width - tx) / scale
        val vb = (height - ty) / scale

        for (g in groups) if (g.locked) drawGroup(canvas, g, vl, vt, vr, vb)
        for (g in groups) if (!g.locked && g !== dragGroup) drawGroup(canvas, g, vl, vt, vr, vb)
        dragGroup?.let { g ->
            val off = cell * 0.06f
            for (p in g.pieces) {
                canvas.drawBitmap(p.bmp, p.x - margin + off, p.y - margin + off * 1.5f, shadowPaint)
            }
            drawGroup(canvas, g, vl, vt, vr, vb)
        }
        canvas.restore()
    }

    private fun drawGroup(c: Canvas, g: Group, vl: Float, vt: Float, vr: Float, vb: Float) {
        piecePaint.alpha = if (isDimmed(g)) 45 else 255
        for (p in g.pieces) {
            if (p.x + cell + margin < vl || p.x - margin > vr ||
                p.y + cell + margin < vt || p.y - margin > vb
            ) continue
            c.drawBitmap(p.bmp, p.x - margin, p.y - margin, piecePaint)
        }
    }

    // ---------------------------------------------------------------- toque

    private enum class Mode { NONE, DRAG, PAN }

    private var mode = Mode.NONE
    private var dragGroup: Group? = null
    private var activeId = -1
    private var lastX = 0f
    private var lastY = 0f

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            private var lfx = 0f
            private var lfy = 0f

            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                lfx = detector.focusX
                lfy = detector.focusY
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val ns = (scale * detector.scaleFactor).coerceIn(minScale, maxScale)
                val f = ns / scale
                tx = detector.focusX - (detector.focusX - tx) * f
                ty = detector.focusY - (detector.focusY - ty) * f
                tx += detector.focusX - lfx
                ty += detector.focusY - lfy
                lfx = detector.focusX
                lfy = detector.focusY
                scale = ns
                clampTranslation()
                invalidate()
                return true
            }
        })

    private fun clampTranslation() {
        val sw = worldW * scale
        val sh = worldH * scale
        tx = if (sw <= width) (width - sw) / 2f else tx.coerceIn(width - sw, 0f)
        ty = if (sh <= height) (height - sh) / 2f else ty.coerceIn(height - sh, 0f)
    }

    private fun pieceAt(wx: Float, wy: Float): Piece? {
        for (gi in groups.indices.reversed()) {
            val g = groups[gi]
            if (g.locked || isDimmed(g)) continue
            for (p in g.pieces) {
                val lx = (wx - (p.x - margin)).toInt()
                val ly = (wy - (p.y - margin)).toInt()
                if (lx < 0 || ly < 0 || lx >= p.bmp.width || ly >= p.bmp.height) continue
                if (Color.alpha(p.bmp.getPixel(lx, ly)) > 40) return p
            }
        }
        return null
    }

    private fun startDrag(g: Group, anchor: Piece) {
        groups.remove(g)
        groups.add(g)
        dragGroup = g
        dragAnchor = anchor
        recorder?.down(anchor.index)
        mode = Mode.DRAG
        removeCallbacks(autoScroll)
        postOnAnimation(autoScroll)
        invalidate()
    }

    private fun endDrag() {
        val g = dragGroup
        val anchor = dragAnchor
        dragGroup = null
        dragAnchor = null
        removeCallbacks(autoScroll)
        if (g != null) {
            if (settle(g)) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            val done = checkComplete()
            if (anchor != null) recordUp(anchor)
            notifyProgress()
            invalidate()
            if (done) {
                recorder?.close()
                recorder = null
                listener?.onCompleted()
            }
        }
    }

    private val autoScroll = object : Runnable {
        override fun run() {
            val g = dragGroup
            if (mode != Mode.DRAG || g == null) return
            val edge = 48f * density
            val speed = 12f * density
            var sx = 0f
            var sy = 0f
            if (lastX < edge) sx = speed else if (lastX > width - edge) sx = -speed
            if (lastY < edge) sy = speed else if (lastY > height - edge) sy = -speed
            if (sx != 0f || sy != 0f) {
                val ox = tx
                val oy = ty
                tx += sx
                ty += sy
                clampTranslation()
                val rdx = tx - ox
                val rdy = ty - oy
                if (rdx != 0f || rdy != 0f) {
                    translate(g, -rdx / scale, -rdy / scale)
                    keepInWorld(g)
                    recordMove()
                    invalidate()
                }
            }
            postOnAnimation(this)
        }
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (pieces.isEmpty()) return true
        scaleDetector.onTouchEvent(ev)

        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                activeId = ev.getPointerId(0)
                lastX = ev.x
                lastY = ev.y
                val p = pieceAt((ev.x - tx) / scale, (ev.y - ty) / scale)
                if (p != null) startDrag(p.group, p) else mode = Mode.PAN
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                endDrag()
                mode = Mode.NONE
            }

            MotionEvent.ACTION_MOVE -> {
                if (scaleDetector.isInProgress) return true
                val idx = ev.findPointerIndex(activeId)
                if (idx < 0) return true
                val x = ev.getX(idx)
                val y = ev.getY(idx)
                val dx = x - lastX
                val dy = y - lastY
                when (mode) {
                    Mode.DRAG -> dragGroup?.let {
                        translate(it, dx / scale, dy / scale)
                        keepInWorld(it)
                        recordMove()
                    }
                    Mode.PAN -> {
                        tx += dx
                        ty += dy
                        clampTranslation()
                    }
                    Mode.NONE -> {}
                }
                lastX = x
                lastY = y
                invalidate()
            }

            MotionEvent.ACTION_POINTER_UP -> {
                val upIdx = ev.actionIndex
                if (ev.getPointerId(upIdx) == activeId) {
                    val newIdx = if (upIdx == 0) 1 else 0
                    activeId = ev.getPointerId(newIdx)
                }
                val idx = ev.findPointerIndex(activeId)
                if (idx >= 0) {
                    lastX = ev.getX(idx)
                    lastY = ev.getY(idx)
                }
                if (ev.pointerCount - 1 == 1) mode = Mode.PAN
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                endDrag()
                mode = Mode.NONE
            }
        }
        return true
    }
}
