package com.example.quebracabeca

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import java.io.File
import java.util.concurrent.Executors

/** Imagens livres: as ilustrações que vêm no app (sem direitos autorais) e a busca no Pexels. */
class ImagesActivity : AppCompatActivity() {

    private val files: List<String> by lazy {
        (assets.list("gallery") ?: emptyArray()).filter { it.endsWith(".jpg") }.sorted()
    }
    private val pool = Executors.newFixedThreadPool(2)

    private val pexels = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) done()
    }

    private class VH(v: View) : RecyclerView.ViewHolder(v) {
        val img: ImageView = v.findViewById(R.id.img)
        val credit: TextView = v.findViewById(R.id.credit)
    }

    private val adapter = object : RecyclerView.Adapter<VH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_image, parent, false))

        override fun getItemCount() = files.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val name = files[position]
            h.credit.visibility = View.GONE
            h.img.setImageDrawable(null)
            h.img.tag = name
            pool.execute {
                val bmp = try {
                    assets.open("gallery/$name").use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 4 }) }
                } catch (e: Exception) { null }
                runOnUiThread { if (h.img.tag == name) h.img.setImageBitmap(bmp) }
            }
            h.itemView.setOnClickListener { choose(name) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_images)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        findViewById<MaterialToolbar>(R.id.toolbar).apply {
            setNavigationIcon(R.drawable.ic_back)
            setNavigationOnClickListener { finish() }
        }
        findViewById<MaterialButton>(R.id.btn_pexels).setOnClickListener {
            pexels.launch(Intent(this, PexelsActivity::class.java))
        }
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = GridLayoutManager(this@ImagesActivity, 2)
            adapter = this@ImagesActivity.adapter
        }
    }

    private fun choose(name: String) {
        Toast.makeText(this, R.string.loading, Toast.LENGTH_SHORT).show()
        pool.execute {
            val ok = try {
                val f = File(cacheDir, "gallery_pick.jpg")
                assets.open("gallery/$name").use { i -> f.outputStream().use { i.copyTo(it) } }
                ImageStore.importPending(this, Uri.fromFile(f))
            } catch (e: Throwable) { false }
            runOnUiThread {
                if (ok) done() else Toast.makeText(this, R.string.load_error, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun done() {
        setResult(Activity.RESULT_OK)
        finish()
    }

    override fun onDestroy() {
        pool.shutdown()
        super.onDestroy()
    }
}
