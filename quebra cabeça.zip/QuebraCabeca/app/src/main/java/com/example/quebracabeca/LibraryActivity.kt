package com.example.quebracabeca

import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.progressindicator.LinearProgressIndicator

/** Biblioteca: todos os puzzles salvos no aparelho, com miniatura e progresso. */
class LibraryActivity : AppCompatActivity() {

    private lateinit var list: RecyclerView
    private lateinit var empty: View
    private var items: List<ImageStore.Entry> = emptyList()

    private val adapter = object : RecyclerView.Adapter<VH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_library, parent, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val e = items[position]
            val tf = ImageStore.thumbFile(this@LibraryActivity, e.id)
            h.thumb.setImageBitmap(if (tf.exists()) BitmapFactory.decodeFile(tf.path) else null)
            h.bar.setProgressCompat(e.percent, false)
            h.info.text = (if (e.completed)
                getString(R.string.library_done, formatTime(e.elapsed))
            else getString(R.string.library_item, e.count, e.percent)) +
                (if (ImageStore.hasVideo(this@LibraryActivity, e.id)) getString(R.string.library_has_video) else "")
            h.itemView.setOnClickListener { open(e) }
            h.itemView.setOnLongClickListener { confirmDelete(e); true }
        }
    }

    private class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.thumb)
        val bar: LinearProgressIndicator = v.findViewById(R.id.bar)
        val info: TextView = v.findViewById(R.id.info)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_library)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        findViewById<MaterialToolbar>(R.id.toolbar).apply {
            setNavigationIcon(R.drawable.ic_back)
            setNavigationOnClickListener { finish() }
        }
        list = findViewById(R.id.list)
        empty = findViewById(R.id.empty)
        list.layoutManager = GridLayoutManager(this, 2)
        list.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    private fun reload() {
        Thread {
            val l = ImageStore.list(this)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                items = l.filter { !it.completed }
                adapter.notifyDataSetChanged()
                empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
            }
        }.start()
    }

    private fun open(e: ImageStore.Entry) {
        if (e.completed) {
            val hasVideo = ImageStore.hasVideo(this, e.id)
            val labels = ArrayList<String>()
            if (hasVideo) labels.add(getString(R.string.library_watch))
            labels.add(getString(R.string.library_again))
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.library_again_title)
                .setItems(labels.toTypedArray()) { _, which ->
                    if (hasVideo && which == 0) {
                        startActivity(
                            Intent(this, VideoPlayerActivity::class.java)
                                .putExtra(VideoPlayerActivity.EXTRA_ID, e.id)
                        )
                    } else {
                        val n = ImageStore.replayFrom(this, e.id, System.nanoTime()) ?: return@setItems
                        launch(n, resume = false)
                    }
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        } else {
            ImageStore.currentId = e.id
            launch(e, resume = true)
        }
    }

    private fun launch(e: ImageStore.Entry, resume: Boolean) {
        startActivity(
            Intent(this, PuzzleActivity::class.java)
                .putExtra(PuzzleActivity.EXTRA_ID, e.id)
                .putExtra(PuzzleActivity.EXTRA_RESUME, resume)
                .putExtra(PuzzleActivity.EXTRA_COUNT, e.count)
                .putExtra(PuzzleActivity.EXTRA_STYLE, e.style)
                .putExtra(PuzzleActivity.EXTRA_SEED, e.seed)
                .putExtra(PuzzleActivity.EXTRA_ROTATION, e.rotation)
        )
    }

    private fun confirmDelete(e: ImageStore.Entry) {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.library_delete_title)
            .setMessage(R.string.library_delete_msg)
            .setPositiveButton(R.string.library_delete) { _, _ ->
                ImageStore.delete(this, e.id)
                reload()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun formatTime(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%02d:%02d", m, sec)
    }
}
