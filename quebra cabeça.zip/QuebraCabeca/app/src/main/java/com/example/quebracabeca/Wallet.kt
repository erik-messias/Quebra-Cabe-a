package com.example.quebracabeca

import android.content.Context
import android.graphics.Color

/** Item da loja: mesa (cor + padrão) ou decoração (emoji colocado na mesa). */
data class ShopItem(
    val id: String, val isTable: Boolean, val emoji: String, val name: String,
    val price: Int, val color: Int = 0, val pattern: Int = 0
)

object ShopCatalog {
    const val DEFAULT_TABLE = "table_default"
    const val MAX_DECOS = 8
    const val HINT_COST = 5

    val items = listOf(
        ShopItem(DEFAULT_TABLE, true, "🎨", "Mesa simples (cor à sua escolha)", 0),
        ShopItem("table_sand", true, "🏖️", "Areia", 60, Color.parseColor("#D8C39A"), 5),
        ShopItem("table_wood", true, "🪵", "Madeira", 50, Color.parseColor("#8B5E3C"), 1),
        ShopItem("table_felt", true, "🟩", "Feltro verde", 80, Color.parseColor("#2F6B4F"), 2),
        ShopItem("table_marble", true, "🤍", "Mármore", 120, Color.parseColor("#C9C6D2"), 3),
        ShopItem("table_stars", true, "🌌", "Noite estrelada", 200, Color.parseColor("#141B3C"), 4),
        ShopItem("deco_coffee", false, "☕", "Xícara de café", 20),
        ShopItem("deco_cookie", false, "🍪", "Biscoito", 20),
        ShopItem("deco_plant", false, "🪴", "Plantinha", 30),
        ShopItem("deco_flower", false, "🌸", "Flor", 30),
        ShopItem("deco_books", false, "📚", "Livros", 40),
        ShopItem("deco_candle", false, "🕯️", "Vela", 40),
        ShopItem("deco_teddy", false, "🧸", "Ursinho", 60),
        ShopItem("deco_cat", false, "🐱", "Gatinho", 100)
    )

    fun byId(id: String?) = items.firstOrNull { it.id == id }
}

/** Moedas e compras, guardadas nas preferências do app. */
object Wallet {
    private fun p(ctx: Context) = ctx.getSharedPreferences("puzzle_prefs", Context.MODE_PRIVATE)

    fun coins(ctx: Context): Int = p(ctx).getInt("coins", 15) // começa com 15 moedas

    fun add(ctx: Context, n: Int) {
        p(ctx).edit().putInt("coins", coins(ctx) + n).apply()
    }

    fun spend(ctx: Context, n: Int): Boolean {
        val c = coins(ctx)
        if (c < n) return false
        p(ctx).edit().putInt("coins", c - n).apply()
        return true
    }

    fun owned(ctx: Context): Set<String> =
        p(ctx).getStringSet("owned", emptySet()) ?: emptySet()

    fun isOwned(ctx: Context, it: ShopItem) = it.price == 0 || it.id in owned(ctx)

    fun buy(ctx: Context, it: ShopItem): Boolean {
        if (isOwned(ctx, it)) return true
        if (!spend(ctx, it.price)) return false
        p(ctx).edit().putStringSet("owned", HashSet(owned(ctx)) + it.id).apply()
        return true
    }

    fun equippedTable(ctx: Context): String =
        p(ctx).getString("table_item", ShopCatalog.DEFAULT_TABLE) ?: ShopCatalog.DEFAULT_TABLE

    fun setTable(ctx: Context, id: String) {
        p(ctx).edit().putString("table_item", id).apply()
    }

    fun equippedDecos(ctx: Context): List<String> =
        (p(ctx).getString("decos", "") ?: "").split(",").filter { it.isNotEmpty() }

    /** Põe/tira a decoração. Devolve false se já há decorações demais. */
    fun toggleDeco(ctx: Context, id: String): Boolean {
        val l = equippedDecos(ctx).toMutableList()
        if (id in l) l.remove(id) else {
            if (l.size >= ShopCatalog.MAX_DECOS) return false
            l.add(id)
        }
        p(ctx).edit().putString("decos", l.joinToString(",")).apply()
        return true
    }
}
