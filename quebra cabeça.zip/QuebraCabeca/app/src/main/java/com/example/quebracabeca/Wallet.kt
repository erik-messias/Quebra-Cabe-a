package com.example.quebracabeca

import android.content.Context
import android.graphics.Color

/** Item da loja: mesa (cor + padrão) ou decoração (desenho colocado na mesa). */
data class ShopItem(
    val id: String, val isTable: Boolean, val icon: Int, val name: String,
    val price: Int, val color: Int = 0, val pattern: Int = 0,
    val file: String? = null, val created: Long = 0L, val sales: Int = 0,
    val author: String = "", val cloudId: String = ""
)

object ShopCatalog {
    const val DEFAULT_TABLE = "table_default"
    const val MAX_DECOS = 8
    const val PET_CAT = "pet_cat"
    const val HINT_COST = 5

    val items = listOf(
        ShopItem(DEFAULT_TABLE, true, R.drawable.tbl_default, "Mesa simples (cor à sua escolha)", 0),
        ShopItem("table_sand", true, R.drawable.tbl_sand, "Areia", 60, Color.parseColor("#D8C39A"), 5),
        ShopItem("table_wood", true, R.drawable.tbl_wood, "Madeira", 50, Color.parseColor("#8B5E3C"), 1),
        ShopItem("table_felt", true, R.drawable.tbl_felt, "Feltro verde", 80, Color.parseColor("#2F6B4F"), 2),
        ShopItem("table_marble", true, R.drawable.tbl_marble, "Mármore", 120, Color.parseColor("#C9C6D2"), 3),
        ShopItem("table_desk", true, R.drawable.tbl_desk, "Mesa de estudo 3D", 300, Color.parseColor("#A9784B"), 6),
        ShopItem("table_stars", true, R.drawable.tbl_stars, "Noite estrelada", 200, Color.parseColor("#141B3C"), 4),
        ShopItem("deco_coffee", false, R.drawable.deco_coffee, "Xícara de café", 20),
        ShopItem("deco_cookie", false, R.drawable.deco_cookie, "Biscoito", 20),
        ShopItem("deco_plant", false, R.drawable.deco_plant, "Plantinha", 30),
        ShopItem("deco_flower", false, R.drawable.deco_flower, "Flor", 30),
        ShopItem("deco_books", false, R.drawable.deco_books, "Livros", 40),
        ShopItem("deco_candle", false, R.drawable.deco_candle, "Vela", 40),
        ShopItem("deco_teddy", false, R.drawable.deco_teddy, "Ursinho", 60),
        ShopItem("deco_cat", false, R.drawable.deco_cat, "Gatinho", 100),
        ShopItem("draw_torrada", false, R.drawable.draw_torrada, "Torradinha", 40),
        ShopItem("draw_gato_lingua", false, R.drawable.draw_gato_lingua, "Gato de língua", 50),
        ShopItem("draw_gato_chuva", false, R.drawable.draw_gato_chuva, "Gato da chuva", 50),
        ShopItem("draw_gato_deitado", false, R.drawable.draw_gato_deitado, "Gato deitado", 40),
        ShopItem("draw_bebe_olhudo", false, R.drawable.draw_bebe_olhudo, "Bebê olhudo", 60),
        ShopItem("draw_lontra", false, R.drawable.draw_lontra, "Lontrinha", 70),
        ShopItem("draw_sapo", false, R.drawable.draw_sapo, "Sapinho cogumelo", 70),
        ShopItem("draw_gato_feliz", false, R.drawable.draw_gato_feliz, "Gato feliz de fone", 80),
        ShopItem(PET_CAT, false, R.drawable.draw_gato_tchau, "Gatinho que passeia pela mesa", 150)
    )

    /** Decorações desenhadas pelo próprio usuário (registro local). */
    var customItems: List<ShopItem> = emptyList()
        private set

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("puzzle_prefs", Context.MODE_PRIVATE)

    fun loadCustom(ctx: Context) {
        val out = ArrayList<ShopItem>()
        try {
            val arr = org.json.JSONArray(prefs(ctx).getString("custom_decos", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val f = java.io.File(ctx.filesDir, "custom/${o.getString("id")}.png")
                if (f.exists()) out.add(ShopItem(o.getString("id"), false, 0, o.getString("name"), o.getInt("price"),
                    file = f.absolutePath, created = o.optLong("created"), sales = o.optInt("sales"),
                    author = o.optString("author"), cloudId = o.optString("cloud")))
            }
        } catch (_: Exception) {}
        customItems = out
    }

    fun addCustom(ctx: Context, name: String, price: Int, bmp: android.graphics.Bitmap): String {
        val id = "custom_" + System.currentTimeMillis()
        val dir = java.io.File(ctx.filesDir, "custom").apply { mkdirs() }
        java.io.FileOutputStream(java.io.File(dir, "$id.png")).use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
        val arr = try { org.json.JSONArray(prefs(ctx).getString("custom_decos", "[]")) } catch (_: Exception) { org.json.JSONArray() }
        arr.put(org.json.JSONObject().put("id", id).put("name", name).put("price", price).put("created", System.currentTimeMillis()).put("sales", 0))
        prefs(ctx).edit().putString("custom_decos", arr.toString()).apply()
        loadCustom(ctx)
        return id
    }

    fun setCloudId(ctx: Context, id: String, cloudId: String) {
        val arr = try { org.json.JSONArray(prefs(ctx).getString("custom_decos", "[]")) } catch (_: Exception) { return }
        for (i in 0 until arr.length()) if (arr.getJSONObject(i).getString("id") == id) arr.getJSONObject(i).put("cloud", cloudId)
        prefs(ctx).edit().putString("custom_decos", arr.toString()).apply()
        loadCustom(ctx)
    }

    /** Guarda no aparelho uma decoração comprada na comunidade. */
    fun addBought(ctx: Context, cloudId: String, name: String, price: Int, author: String, bmp: android.graphics.Bitmap): String {
        val id = "com_$cloudId"
        val dir = java.io.File(ctx.filesDir, "custom").apply { mkdirs() }
        java.io.FileOutputStream(java.io.File(dir, "$id.png")).use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
        val arr = try { org.json.JSONArray(prefs(ctx).getString("custom_decos", "[]")) } catch (_: Exception) { org.json.JSONArray() }
        var has = false
        for (i in 0 until arr.length()) if (arr.getJSONObject(i).getString("id") == id) has = true
        if (!has) arr.put(org.json.JSONObject().put("id", id).put("name", name).put("price", price).put("created", System.currentTimeMillis()).put("sales", 0).put("author", author).put("cloud", cloudId))
        prefs(ctx).edit().putString("custom_decos", arr.toString()).apply()
        loadCustom(ctx)
        return id
    }

    fun byId(id: String?) = items.firstOrNull { it.id == id } ?: customItems.firstOrNull { it.id == id }
}

/** Moedas e compras, guardadas nas preferências do app. */
object Wallet {
    private fun p(ctx: Context) = ctx.getSharedPreferences("puzzle_prefs", Context.MODE_PRIVATE)

    fun coins(ctx: Context): Int = p(ctx).getInt("coins", 15) // começa com 15 moedas

    /** Códigos promocionais de teste. Devolve as moedas dadas (0 se o código não existe). */
    fun redeem(ctx: Context, code: String): Int {
        val n = when (code.trim().lowercase()) { "mingau123" -> 1000; else -> 0 }
        if (n > 0) add(ctx, n)
        return n
    }

    fun add(ctx: Context, n: Int) {
        p(ctx).edit().putInt("coins", coins(ctx) + n).apply()
    }

    fun spend(ctx: Context, n: Int): Boolean {
        val c = coins(ctx)
        if (c < n) return false
        p(ctx).edit().putInt("coins", c - n).apply()
        return true
    }

    fun owned(ctx: Context): Set<String> =
        p(ctx).getStringSet("owned", emptySet()) ?: emptySet()

    fun isOwned(ctx: Context, it: ShopItem) = it.price == 0 || it.id in owned(ctx)

    fun buy(ctx: Context, it: ShopItem): Boolean {
        if (isOwned(ctx, it)) return true
        if (!spend(ctx, it.price)) return false
        p(ctx).edit().putStringSet("owned", HashSet(owned(ctx)) + it.id).apply()
        return true
    }

    /** Dá o item de graça (ex.: ao importar o próprio GIF) e o coloca na mesa. */
    fun grantAndEquip(ctx: Context, id: String) {
        p(ctx).edit().putStringSet("owned", HashSet(owned(ctx)) + id).apply()
        if (id !in equippedDecos(ctx)) toggleDeco(ctx, id)
    }

    fun equippedTable(ctx: Context): String =
        p(ctx).getString("table_item", ShopCatalog.DEFAULT_TABLE) ?: ShopCatalog.DEFAULT_TABLE

    fun setTable(ctx: Context, id: String) {
        p(ctx).edit().putString("table_item", id).apply()
    }

    fun equippedDecos(ctx: Context): List<String> =
        (p(ctx).getString("decos", "") ?: "").split(",").filter { it.isNotEmpty() }

    /** Põe/tira a decoração. Devolve false se já há decorações demais. */
    fun toggleDeco(ctx: Context, id: String): Boolean {
        val l = equippedDecos(ctx).toMutableList()
        if (id in l) l.remove(id) else {
            if (l.size >= ShopCatalog.MAX_DECOS) return false
            l.add(id)
        }
        p(ctx).edit().putString("decos", l.joinToString(",")).apply()
        return true
    }
}
