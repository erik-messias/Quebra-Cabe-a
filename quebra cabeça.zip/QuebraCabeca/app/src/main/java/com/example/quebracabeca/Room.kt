package com.example.quebracabeca

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.Executors

/** Salas para montar o puzzle junto com amigos (Firebase REST, consulta a cada ~1,5 s). */
object Room {
    class Joined(val count: Int, val style: Int, val seed: Long, val rotation: Boolean, val img: ByteArray, val state: JSONObject)
    class Msg(val key: String, val by: String, val groups: String)

    private val sender = Executors.newSingleThreadExecutor()

    fun newCode(): String {
        val abc = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val r = java.util.Random()
        return "A" + (1..4).map { abc[r.nextInt(abc.length)] }.joinToString("")
    }

    private fun jpegBytes(file: File): ByteArray {
        val opts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        android.graphics.BitmapFactory.decodeFile(file.absolutePath, opts)
        var sample = 1
        while (maxOf(opts.outWidth, opts.outHeight) / sample > 2000) sample *= 2
        var b = android.graphics.BitmapFactory.decodeFile(file.absolutePath, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })!!
        if (maxOf(b.width, b.height) > 1280) {
            val k = 1280f / maxOf(b.width, b.height)
            b = Bitmap.createScaledBitmap(b, (b.width * k).toInt(), (b.height * k).toInt(), true)
        }
        val o = ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.JPEG, 85, o)
        return o.toByteArray()
    }

    /** Cria a sala com a imagem e o estado atual. Devolve o código. */
    fun create(ctx: Context, image: File, state: JSONObject, count: Int): String {
        val code = newCode()
        val room = JSONObject()
            .put("host", Cloud.uid(ctx)).put("created", System.currentTimeMillis())
            .put("count", count).put("style", state.optInt("style")).put("seed", state.optLong("seed"))
            .put("rotation", state.optBoolean("rotation")).put("state", state.toString())
            .put("img", Base64.encodeToString(jpegBytes(image), Base64.NO_WRAP))
        Cloud.db(ctx, "PUT", "rooms/$code", room.toString())
        return code
    }

    fun join(ctx: Context, code: String): Joined? {
        val s = Cloud.db(ctx, "GET", "rooms/${code.uppercase()}")
        if (s == "null" || s.isBlank()) return null
        val o = JSONObject(s)
        return Joined(o.optInt("count", 48), o.optInt("style"), o.optLong("seed"), o.optBoolean("rotation"),
            Base64.decode(o.getString("img"), Base64.DEFAULT), JSONObject(o.getString("state")))
    }

    fun push(ctx: Context, code: String, groups: String) {
        val body = JSONObject().put("by", Cloud.uid(ctx)).put("g", groups).put("t", System.currentTimeMillis()).toString()
        sender.execute { try { Cloud.db(ctx, "POST", "rooms/$code/moves", body) } catch (_: Throwable) {} }
    }

    /** Mensagens depois de [after] (null = todas), em ordem. */
    fun poll(ctx: Context, code: String, after: String?): List<Msg> {
        val extra = "orderBy=%22\$key%22" + (if (after != null) "&startAt=%22$after%22" else "")
        val s = Cloud.db(ctx, "GET", "rooms/$code/moves", null, extra)
        if (s == "null" || s.isBlank()) return emptyList()
        val o = JSONObject(s)
        return o.keys().asSequence().sorted().filter { it != after }.mapNotNull { k ->
            o.optJSONObject(k)?.let { Msg(k, it.optString("by"), it.optString("g")) }
        }.toList()
    }
}
