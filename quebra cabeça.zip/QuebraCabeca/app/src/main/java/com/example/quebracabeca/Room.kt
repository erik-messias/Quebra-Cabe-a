package com.example.quebracabeca

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.Executors

/** Salas para montar o puzzle junto com amigos (Firebase REST, consulta a cada ~1,5 s). */
object Room {
    class Joined(val count: Int, val style: Int, val seed: Long, val rotation: Boolean, val img: ByteArray, val state: JSONObject)
    class Msg(val key: String, val by: String, val groups: String)

    private val sender = Executors.newSingleThreadExecutor()

    fun newCode(prefix: Char = 'A'): String {
        val abc = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val r = java.util.Random()
        return prefix.toString() + (1..4).map { abc[r.nextInt(abc.length)] }.joinToString("")
    }

    private fun jpegBytes(file: File): ByteArray {
        val opts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        android.graphics.BitmapFactory.decodeFile(file.absolutePath, opts)
        var sample = 1
        while (maxOf(opts.outWidth, opts.outHeight) / sample > 2000) sample *= 2
        var b = android.graphics.BitmapFactory.decodeFile(file.absolutePath, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })!!
        if (maxOf(b.width, b.height) > 1280) {
            val k = 1280f / maxOf(b.width, b.height)
            b = Bitmap.createScaledBitmap(b, (b.width * k).toInt(), (b.height * k).toInt(), true)
        }
        val o = ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.JPEG, 85, o)
        return o.toByteArray()
    }

    /** Cria a sala com a imagem e o estado atual. Devolve o código. */
    fun create(ctx: Context, image: File, state: JSONObject, count: Int): String {
        val cross = state.optInt("geo", 1) == 2 && !state.optBoolean("rotation")
        val code = newCode(if (cross) 'X' else 'A')
        val room = JSONObject()
            .put("host", Cloud.uid(ctx)).put("created", System.currentTimeMillis())
            .put("count", count).put("style", state.optInt("style")).put("seed", state.optLong("seed") and 0xFFFFFFFFL)
            .put("rows", state.optInt("rows")).put("cols", state.optInt("cols"))
            .put("rotation", state.optBoolean("rotation")).put("state", state.toString())
            .put("img", Base64.encodeToString(jpegBytes(image), Base64.NO_WRAP))
        Cloud.db(ctx, "PUT", "rooms/$code", room.toString())
        return code
    }

    fun join(ctx: Context, code: String): Joined? {
        val s = Cloud.db(ctx, "GET", "rooms/${code.uppercase()}")
        if (s == "null" || s.isBlank()) return null
        val o = JSONObject(s)
        val raw = o.getString("state").trim()
        val st = if (raw.startsWith("[")) JSONObject().put("rows", o.optInt("rows")).put("cols", o.optInt("cols"))
            .put("seed", o.optLong("seed")).put("style", o.optInt("style")).put("rotation", false).put("geo", 2)
            .put("groups", org.json.JSONArray(raw)) else JSONObject(raw)
        return Joined(o.optInt("count", 48), o.optInt("style"), o.optLong("seed"), o.optBoolean("rotation", o.optBoolean("rotate")),
            Base64.decode(o.getString("img"), Base64.DEFAULT), st)
    }

    fun push(ctx: Context, code: String, groups: String) {
        val body = JSONObject().put("by", Cloud.uid(ctx)).put("g", groups).put("t", System.currentTimeMillis()).toString()
        sender.execute { try { Cloud.db(ctx, "POST", "rooms/$code/moves", body) } catch (_: Throwable) {} }
    }

    private val liveSender = Executors.newSingleThreadExecutor()
    private val livePending = java.util.concurrent.atomic.AtomicReference<String?>(null)

    /** Envia a posição da peça segurada (só o valor mais recente importa). */
    fun livePut(ctx: Context, code: String, body: String) {
        livePending.set(body)
        liveSender.execute {
            val b = livePending.getAndSet(null) ?: return@execute
            try { Cloud.db(ctx, "PUT", "rooms/$code/live/${Cloud.uid(ctx)}", b) } catch (_: Throwable) {}
        }
    }

    /** Abre o fluxo em tempo real (SSE) de rooms/CODE/live e chama [onState] a cada mudança. Bloqueia até [running] ficar falso. */
    fun liveStream(ctx: Context, code: String, running: () -> Boolean, onState: (Map<String, JSONObject>) -> Unit) {
        while (running()) {
            var conn: java.net.HttpURLConnection? = null
            try {
                val tok = Cloud.token(ctx)
                val url = "https://quebra-cabeca-d14c9-default-rtdb.firebaseio.com/rooms/$code/live.json" + (if (tok.isEmpty()) "" else "?auth=$tok")
                conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                conn.setRequestProperty("Accept", "text/event-stream")
                conn.connectTimeout = 12000; conn.readTimeout = 0
                val state = HashMap<String, JSONObject>()
                var ev = ""
                conn.inputStream.bufferedReader().use { rd ->
                    while (running()) {
                        val line = rd.readLine() ?: break
                        if (line.startsWith("event:")) ev = line.substring(6).trim()
                        else if (line.startsWith("data:") && (ev == "put" || ev == "patch")) {
                            val d = try { JSONObject(line.substring(5).trim()) } catch (_: Exception) { continue }
                            val path = d.optString("path", "/")
                            val data = d.opt("data")
                            if (path == "/") {
                                if (ev == "put") state.clear()
                                (data as? JSONObject)?.let { o -> for (k in o.keys()) { val x = o.optJSONObject(k); if (x == null) state.remove(k) else state[k] = x } }
                            } else {
                                val k = path.split("/").getOrNull(1) ?: continue
                                val x = data as? JSONObject
                                if (x == null) state.remove(k) else state[k] = x
                            }
                            onState(HashMap(state))
                        }
                    }
                }
            } catch (_: Throwable) {
            } finally { try { conn?.disconnect() } catch (_: Throwable) {} }
            if (running()) try { Thread.sleep(1000) } catch (_: InterruptedException) { return }
        }
    }

    /** Mensagens depois de [after] (null = todas), em ordem. */
    fun poll(ctx: Context, code: String, after: String?): List<Msg> {
        val extra = "orderBy=%22\$key%22" + (if (after != null) "&startAt=%22$after%22" else "")
        val s = Cloud.db(ctx, "GET", "rooms/$code/moves", null, extra)
        if (s == "null" || s.isBlank()) return emptyList()
        val o = JSONObject(s)
        return o.keys().asSequence().sorted().filter { it != after }.mapNotNull { k ->
            o.optJSONObject(k)?.let { Msg(k, it.optString("by"), it.optString("g")) }
        }.toList()
    }
}
